<?php
/**
 * Plugin Name: WX Core — Engine
 * Plugin URI: https://woodex.interior/wx-core
 * Description: Engine plugin for WX Master theme — CPTs, builder adapters (Elementor, WPBakery registration only, Oxygen, ACF), skins import/export, plugin layer wx-plugins.json, MCP bridges, WhatsApp live chat. Original code, no paid plugins bundled. Requires WX Master theme.
 * Version: 1.0.0
 * Author: Woodex Interior — WX Engine
 * Author URI: https://woodex.interior
 * License: GPL-2.0-or-later
 * Text Domain: wx-core
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.1
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

define('WX_CORE_VERSION', '1.0.0');
define('WX_CORE_DIR', plugin_dir_path(__FILE__));
define('WX_CORE_URI', plugin_dir_url(__FILE__));

require_once WX_CORE_DIR . 'includes/class-wx-core-cpt.php';
require_once WX_CORE_DIR . 'includes/class-wx-core-builder.php';
require_once WX_CORE_DIR . 'includes/class-wx-core-elementor.php';
require_once WX_CORE_DIR . 'includes/class-wx-core-acf.php';
require_once WX_CORE_DIR . 'includes/class-wx-core-skins.php';
require_once WX_CORE_DIR . 'includes/class-wx-core-plugins.php';
require_once WX_CORE_DIR . 'includes/class-wx-core-mcp.php';
require_once WX_CORE_DIR . 'includes/class-wx-core-live.php';

add_action('plugins_loaded', 'wx_core_init');
function wx_core_init(): void {
    load_plugin_textdomain('wx-core', false, dirname(plugin_basename(__FILE__)) . '/languages');
    WX_Core_CPT::instance();
    WX_Core_Builder::instance();
    WX_Core_Elementor::instance();
    WX_Core_ACF::instance();
    WX_Core_Skins::instance();
    WX_Core_Plugins::instance();
    WX_Core_MCP::instance();
    WX_Core_Live::instance();
}

register_activation_hook(__FILE__, function() {
    // Flush rewrite for CPTs
    (new WX_Core_CPT())->register_cpts();
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function() {
    flush_rewrite_rules();
});
