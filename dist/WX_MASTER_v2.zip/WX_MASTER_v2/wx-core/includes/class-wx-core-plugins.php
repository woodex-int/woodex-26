<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
class WX_Core_Plugins {
    private static ?self $instance = null;
    public static function instance(): self { if (null===self::$instance) self::$instance=new self(); return self::$instance; }
    public function __construct() {
        add_action('admin_init', [$this,'maybe_install']);
    }
    public function get_catalogue(): array {
        $file = get_template_directory() . '/wx-plugins.json';
        if (!file_exists($file)) $file = WX_CORE_DIR . '../wx-master/wx-plugins.json';
        if (file_exists($file)) {
            $data = json_decode((string)file_get_contents($file), true);
            if (is_array($data)) return $data;
        }
        return [];
    }
    public function maybe_install(): void {
        // Placeholder for auto-install of brand_default plugins
    }
    public function import_plugin_designs(string $skin_slug): void {
        $skin_dir = get_template_directory() . '/assets/skins/' . $skin_slug;
        $designs_dir = $skin_dir . '/plugin-designs';
        if (!is_dir($designs_dir)) return;
        foreach (glob($designs_dir.'/*.json') as $file) {
            $plugin = basename($file,'.json');
            $data = json_decode((string)file_get_contents($file), true);
            if (!is_array($data)) continue;
            // Import logic per plugin — simplified, original
            update_option('wx_plugin_design_'.$plugin.'_'.$skin_slug, $data);
        }
    }
}
