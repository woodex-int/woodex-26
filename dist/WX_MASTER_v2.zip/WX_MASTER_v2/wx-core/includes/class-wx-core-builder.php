<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
class WX_Core_Builder {
    private static ?self $instance = null;
    public static function instance(): self { if (null===self::$instance) self::$instance=new self(); return self::$instance; }
    public function __construct() { add_action('wp_head', [$this,'output_styles']); }
    public function output_styles(): void {
        echo '<style id="wx-core-builder">.wx-template-header{position:sticky;top:0;z-index:100}</style>';
    }
    public static function render_header(string $slug=''): void {
        $slug = sanitize_title($slug);
        $post = get_page_by_path($slug, OBJECT, 'wx_template');
        if ($post) echo apply_filters('the_content', $post->post_content);
        else get_template_part('template-parts/header/base');
    }
    public static function render_footer(string $slug=''): void {
        $slug = sanitize_title($slug);
        $post = get_page_by_path($slug, OBJECT, 'wx_template');
        if ($post) echo apply_filters('the_content', $post->post_content);
        else get_template_part('template-parts/footer/base');
    }
}
