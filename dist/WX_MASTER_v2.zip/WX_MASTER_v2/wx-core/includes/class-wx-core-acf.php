<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
class WX_Core_ACF {
    private static ?self $instance = null;
    public static function instance(): self { if (null===self::$instance) self::$instance=new self(); return self::$instance; }
    public function __construct() {
        add_action('init', [$this,'register_acf_blocks']);
    }
    public function register_acf_blocks(): void {
        if (!function_exists('acf_register_block_type')) return;
        $blocks = [
            ['name'=>'wx-hero-slider','title'=>'WX Hero Slider','render_template'=>WX_CORE_DIR.'templates/blocks/hero-slider.php'],
            ['name'=>'wx-cine','title'=>'WX Cine Hero','render_template'=>WX_CORE_DIR.'templates/blocks/cine.php'],
            ['name'=>'wx-brief-form','title'=>'WX Brief Form','render_template'=>WX_CORE_DIR.'templates/blocks/brief-form.php'],
            ['name'=>'wx-ticker','title'=>'WX Ticker','render_template'=>WX_CORE_DIR.'templates/blocks/ticker.php'],
            ['name'=>'wx-gates','title'=>'WX Process Gates','render_template'=>WX_CORE_DIR.'templates/blocks/gates.php'],
        ];
        foreach ($blocks as $block) {
            acf_register_block_type([
                'name'=>$block['name'],
                'title'=>esc_html($block['title']),
                'render_template'=>$block['render_template'],
                'category'=>'formatting',
                'icon'=>'admin-comments',
                'keywords'=>['woodex','wx'],
            ]);
        }
    }
    // Flexible content layouts for Raw HTML+ACF mode
    public static function get_flexible_layouts(): array {
        return [
            'hero_slider' => ['label'=>'Hero Slider','fields'=>['slides','labels']],
            'cine_hero' => ['label'=>'Cine Hero','fields'=>['title','eyebrow','image','height']],
            'ticker' => ['label'=>'Ticker','fields'=>['items']],
            'gates' => ['label'=>'Process Gates','fields'=>['gates']],
            'custom_html' => ['label'=>'Custom HTML/CSS/JS','fields'=>['html','css','js']],
        ];
    }
}
