<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
class WX_Core_Skins {
    private static ?self $instance = null;
    public static function instance(): self { if (null===self::$instance) self::$instance=new self(); return self::$instance; }
    public function __construct() {
        add_action('admin_menu', [$this,'add_page'], 20);
        add_action('wp_ajax_wx_core_apply_skin', [$this,'ajax_apply']);
    }
    public function get_skins(): array {
        $skins = [];
        $dir = get_template_directory() . '/assets/skins';
        if (!is_dir($dir)) $dir = WX_CORE_DIR . '../wx-master/assets/skins';
        if (!is_dir($dir)) return $skins;
        foreach (glob($dir.'/*', GLOB_ONLYDIR) as $path) {
            $slug = basename($path);
            $preset = $path.'/preset.json';
            if (file_exists($preset)) {
                $data = json_decode((string)file_get_contents($preset), true);
                if (is_array($data)) { $data['slug']=$slug; $data['path']=$path; $skins[$slug]=$data; }
            }
        }
        return $skins;
    }
    public function add_page(): void {
        add_submenu_page('tools.php', esc_html__('WX Skins Import/Export','wx-core'), esc_html__('WX Skins','wx-core'), 'manage_options', 'wx-core-skins', [$this,'render']);
    }
    public function render(): void {
        if (!current_user_can('manage_options')) return;
        $skins = $this->get_skins();
        echo '<div class="wrap"><h1>WX Core — Skins Import/Export</h1><p>One-click export: preset.json + kits + acf-json + plugin-designs + content.xml</p><ul>';
        foreach ($skins as $slug=>$skin) echo '<li>'.esc_html($skin['name']??$slug).' ('.esc_html($slug).') — <button class="button wx-core-apply" data-skin="'.esc_attr($slug).'">Apply</button></li>';
        echo '</ul></div>';
    }
    public function ajax_apply(): void {
        check_ajax_referer('wx-admin-nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Forbidden');
        $slug = sanitize_text_field($_POST['skin']??'');
        update_option('wx_current_skin',$slug);
        wp_send_json_success('Applied '.$slug);
    }
}
