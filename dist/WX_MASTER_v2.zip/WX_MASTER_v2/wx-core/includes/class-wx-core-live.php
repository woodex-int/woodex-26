<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
class WX_Core_Live {
    private static ?self $instance = null;
    public static function instance(): self { if (null===self::$instance) self::$instance=new self(); return self::$instance; }
    public function __construct() {
        add_action('rest_api_init', [$this,'register']);
        add_action('admin_menu', [$this,'add_page']);
    }
    public function register(): void {
        register_rest_route('wx-live/v1','/send',['methods'=>'POST','callback'=>[$this,'send'],'permission_callback'=>[$this,'can_write']]);
        register_rest_route('wx-live/v1','/receive',['methods'=>'POST','callback'=>[$this,'receive'],'permission_callback'=>[$this,'can_write']]);
        register_rest_route('wx-live/v1','/threads',['methods'=>'GET','callback'=>[$this,'threads'],'permission_callback'=>[$this,'can_read']]);
    }
    public function can_read(): bool { return current_user_can('read'); }
    public function can_write(): bool { return current_user_can('manage_options'); }
    public function add_page(): void {
        add_options_page(esc_html__('WX WhatsApp Live','wx-core'), esc_html__('WX Live','wx-core'), 'manage_options', 'wx-live', [$this,'render']);
    }
    public function render(): void {
        if (!current_user_can('manage_options')) return;
        $opts = get_option('wx_live_settings', []);
        ?>
        <div class="wrap">
            <h1>WX Live — WhatsApp Business Cloud API</h1>
            <form method="post" action="options.php">
                <?php settings_fields('wx_live_settings'); ?>
                <table class="form-table">
                    <tr><th>Phone Number ID</th><td><input type="text" name="wx_live_settings[phone_id]" value="<?php echo esc_attr($opts['phone_id']??''); ?>" class="regular-text"></td></tr>
                    <tr><th>Access Token</th><td><input type="password" name="wx_live_settings[token]" value="<?php echo esc_attr($opts['token']??''); ?>" class="regular-text"></td></tr>
                    <tr><th>Webhook Secret</th><td><input type="text" name="wx_live_settings[webhook_secret]" value="<?php echo esc_attr($opts['webhook_secret']??''); ?>" class="regular-text"></td></tr>
                    <tr><th>Business Hours</th><td><input type="text" name="wx_live_settings[hours]" value="<?php echo esc_attr($opts['hours']??'10:00-20:00'); ?>" class="regular-text"><p>Auto-responder outside hours</p></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
            <h2>REST Endpoints</h2>
            <p><code>/wp-json/wx-live/v1/send</code> — forwards to WhatsApp Cloud API<br><code>/wp-json/wx-live/v1/receive</code> — webhook for incoming<br><code>/wp-json/wx-live/v1/threads</code> — list threads</p>
        </div>
        <?php
    }
    public function send(\WP_REST_Request $req): \WP_REST_Response {
        $to = sanitize_text_field($req->get_param('to')??'');
        $message = sanitize_text_field($req->get_param('message')??'');
        if (empty($to) || empty($message)) return rest_ensure_response(new \WP_Error('missing','to and message required'));
        $opts = get_option('wx_live_settings', []);
        if (empty($opts['phone_id']) || empty($opts['token'])) return rest_ensure_response(new \WP_Error('no_creds','WhatsApp credentials not set'));
        // Store transcript
        $threads = get_option('wx_live_threads', []);
        $threads[] = ['to'=>$to,'message'=>$message,'time'=>time(),'direction'=>'out'];
        update_option('wx_live_threads', $threads);
        // Real API call would go here — simplified for scaffold, original
        // wp_remote_post("https://graph.facebook.com/v19.0/{$opts['phone_id']}/messages", [...])
        return rest_ensure_response(['success'=>true,'to'=>$to,'message'=>$message,'note'=>'Scaffold: transcript stored, real API call in P5']);
    }
    public function receive(\WP_REST_Request $req): \WP_REST_Response {
        $data = $req->get_json_params();
        $threads = get_option('wx_live_threads', []);
        $threads[] = ['data'=>$data,'time'=>time(),'direction'=>'in'];
        update_option('wx_live_threads', $threads);
        return rest_ensure_response(['success'=>true]);
    }
    public function threads(): \WP_REST_Response {
        $threads = get_option('wx_live_threads', []);
        return rest_ensure_response($threads);
    }
}
