<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
class WX_Core_CPT {
    private static ?self $instance = null;
    public static function instance(): self { if (null===self::$instance) self::$instance=new self(); return self::$instance; }
    public function __construct() { add_action('init', [$this,'register_cpts']); }
    public function register_cpts(): void {
        register_post_type('wx_template', [
            'labels'=>['name'=>esc_html__('WX Templates','wx-core'),'singular_name'=>esc_html__('Template','wx-core')],
            'public'=>false,'show_ui'=>true,'show_in_menu'=>true,'menu_icon'=>'dashicons-layout',
            'supports'=>['title','editor','thumbnail'],'show_in_rest'=>true,
        ]);
        register_taxonomy('wx_template_type','wx_template',[
            'labels'=>['name'=>esc_html__('Template Types','wx-core')],
            'public'=>false,'show_ui'=>true,'hierarchical'=>true,'show_in_rest'=>true,
        ]);
        register_post_type('wx_portfolio', [
            'labels'=>['name'=>esc_html__('Portfolio','wx-core')],
            'public'=>true,'has_archive'=>true,'rewrite'=>['slug'=>'portfolio'],
            'supports'=>['title','editor','thumbnail','excerpt'],'show_in_rest'=>true,'menu_icon'=>'dashicons-portfolio',
        ]);
        register_post_type('wx_service', [
            'labels'=>['name'=>esc_html__('Services','wx-core')],
            'public'=>true,'has_archive'=>true,'rewrite'=>['slug'=>'services'],
            'supports'=>['title','editor','thumbnail','excerpt'],'show_in_rest'=>true,'menu_icon'=>'dashicons-admin-tools',
        ]);
    }
}
