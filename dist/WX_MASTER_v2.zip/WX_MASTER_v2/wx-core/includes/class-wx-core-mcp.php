<?php
/**
 * WX Core MCP — REST namespace wx-agent/v1 (Phase B)
 * Original, no paid bundles, security: rate-limit, log to wx_agent_log CPT, never expose tokens
 * Inventory: themes, plugins, templates, skins, headers/footers, blocks, CPTs, users count
 *
 * @package wx-core
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_Core_MCP {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    public function __construct() {
        add_action('init', [$this, 'register_log_cpt']);
        add_action('rest_api_init', [$this, 'register']);
        add_action('admin_menu', [$this, 'add_page'], 20);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_ajax_wx_download_claude_config', [$this, 'download_claude_config']);
    }

    public function register_log_cpt(): void {
        register_post_type('wx_agent_log', [
            'labels' => ['name'=>esc_html__('WX Agent Log','wx-core')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'tools.php',
            'supports' => ['title','editor'],
        ]);
    }

    public function register_settings(): void {
        register_setting('wx_agent_settings', 'wx_agent_allow_non_https');
        register_setting('wx_agent_settings', 'wx_agent_rate_limit');
        register_setting('wx_agent_settings', 'wx_agent_token');
    }

    public function register(): void {
        register_rest_route('wx-agent/v1', '/inspect-site/', [
            'methods' => 'GET',
            'callback' => [$this, 'inspect_site'],
            'permission_callback' => [$this, 'can_read'],
        ]);
        register_rest_route('wx-agent/v1', '/skins/', [
            'methods' => 'GET',
            'callback' => [$this, 'list_skins'],
            'permission_callback' => [$this, 'can_read'],
        ]);
        register_rest_route('wx-agent/v1', '/apply-preset/', [
            'methods' => 'POST',
            'callback' => [$this, 'apply_preset'],
            'permission_callback' => [$this, 'can_write'],
        ]);
        register_rest_route('wx-agent/v1', '/import-html-section/', [
            'methods' => 'POST',
            'callback' => [$this, 'import_html'],
            'permission_callback' => [$this, 'can_write'],
        ]);
        register_rest_route('wx-agent/v1', '/convert-html/', [
            'methods' => 'POST',
            'callback' => [$this, 'convert_html'],
            'permission_callback' => [$this, 'can_write'],
        ]);
        register_rest_route('wx-agent/v1', '/elements/', [
            'methods' => 'GET',
            'callback' => [$this, 'list_elements'],
            'permission_callback' => [$this, 'can_read'],
        ]);
        register_rest_route('wx-agent/v1', '/render-preview/', [
            'methods' => 'POST',
            'callback' => [$this, 'render_preview'],
            'permission_callback' => [$this, 'can_write'],
        ]);
    }

    public function can_read(): bool {
        return is_user_logged_in() && current_user_can('read');
    }

    public function can_write(\WP_REST_Request $request): bool {
        if (!$this->check_rate_limit()) return false;
        $nonce = $request->get_header('X-WP-Nonce') ?? $request->get_param('_wpnonce') ?? '';
        if (!empty($nonce) && !wp_verify_nonce($nonce, 'wp_rest')) return false;
        if (!current_user_can('manage_options')) {
            if (!$this->is_app_password() && !$this->is_agent_token($request)) return false;
            if (!current_user_can('manage_options')) return false;
        }
        return true;
    }

    private function is_app_password(): bool {
        return is_user_logged_in() && !empty($_SERVER['PHP_AUTH_USER']);
    }

    private function is_agent_token(\WP_REST_Request $request): bool {
        $custom = $request->get_header('X-WX-Agent-Token') ?? $request->get_param('agent_token') ?? '';
        if (!empty($custom)) {
            $stored = get_option('wx_agent_token', '');
            if (!empty($stored) && hash_equals($stored, $custom)) return true;
        }
        $auth = $request->get_header('Authorization') ?? '';
        if (!empty($auth) && current_user_can('manage_options')) return true;
        return false;
    }

    private function check_rate_limit(): bool {
        $limit = (int) get_option('wx_agent_rate_limit', 10);
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $key = 'wx_rate_' . md5($ip);
        $data = get_transient($key);
        if (false === $data) {
            set_transient($key, ['count'=>1,'time'=>time()], 60);
            return true;
        }
        if (time() - $data['time'] > 60) {
            set_transient($key, ['count'=>1,'time'=>time()], 60);
            return true;
        }
        if ($data['count'] >= $limit) return false;
        $data['count']++;
        set_transient($key, $data, 60);
        return true;
    }

    private function log_mutation(string $action, array $payload): void {
        $actor_id = get_current_user_id();
        $actor = get_userdata($actor_id);
        $actor_name = $actor ? $actor->user_login : 'unknown';
        $clean = $payload;
        unset($clean['token'], $clean['agent_token'], $clean['Authorization'], $clean['password']);
        $hash = hash('sha256', wp_json_encode($clean));
        wp_insert_post([
            'post_type' => 'wx_agent_log',
            'post_title' => sprintf('%s by %s', $action, $actor_name),
            'post_content' => wp_json_encode(['action'=>$action,'actor'=>$actor_name,'hash'=>$hash], JSON_PRETTY_PRINT),
            'post_status' => 'publish',
            'meta_input' => ['_wx_action'=>$action,'_wx_actor'=>$actor_name,'_wx_hash'=>$hash],
        ]);
    }

    public function inspect_site(): \WP_REST_Response {
        $themes = [];
        foreach (wp_get_themes() as $slug => $theme) {
            $themes[] = ['slug'=>$slug,'name'=>$theme->get('Name'),'version'=>$theme->get('Version')];
        }
        $plugins = [];
        foreach (get_plugins() as $file => $data) {
            $plugins[] = ['file'=>$file,'name'=>$data['Name'],'version'=>$data['Version'],'active'=>is_plugin_active($file)];
        }
        $templates = get_posts(['post_type'=>'wx_template','posts_per_page'=>-1]);
        $headers = [];
        $footers = [];
        $blocks = [];
        foreach ($templates as $t) {
            $terms = wp_get_post_terms($t->ID, 'wx_template_type', ['fields'=>'slugs']);
            $type = $terms[0] ?? 'unknown';
            $item = ['ID'=>$t->ID,'title'=>$t->post_title,'type'=>$type];
            if ('header' === $type) $headers[] = $item;
            elseif ('footer' === $type) $footers[] = $item;
            else $blocks[] = $item;
        }
        $skins = (new WX_Core_Skins())->get_skins();
        $cpts = [];
        foreach (get_post_types(['public'=>true], 'objects') as $cpt) {
            $cpts[] = ['name'=>$cpt->name,'count'=>wp_count_posts($cpt->name)->publish ?? 0];
        }
        $users = count_users();

        return rest_ensure_response([
            'site' => ['name'=>get_bloginfo('name'),'url'=>home_url(),'wp_version'=>get_bloginfo('version')],
            'themes' => $themes,
            'plugins' => $plugins,
            'templates' => ['headers'=>$headers,'footers'=>$footers,'blocks'=>$blocks],
            'skins' => array_map(function($s){ unset($s['path']); return $s; }, $skins),
            'cpts' => $cpts,
            'users' => ['total'=>$users['total_users'] ?? 0],
        ]);
    }

    public function list_skins(): \WP_REST_Response {
        $skins = (new WX_Core_Skins())->get_skins();
        $clean = array_map(function($s){ unset($s['path']); return $s; }, $skins);
        return rest_ensure_response($clean);
    }

    public function apply_preset(\WP_REST_Request $req): \WP_REST_Response {
        $slug = sanitize_text_field($req->get_param('skin') ?? '');
        $this->log_mutation('apply-preset', ['skin'=>$slug]);
        if (empty($slug)) return rest_ensure_response(new \WP_Error('no_skin','No skin',['status'=>400]));
        update_option('wx_current_skin', $slug);
        return rest_ensure_response(['success'=>true,'skin'=>$slug]);
    }

    public function import_html(\WP_REST_Request $req): \WP_REST_Response {
        $html = $req->get_param('html') ?? '';
        $title = sanitize_text_field($req->get_param('title') ?? 'Imported');
        $this->log_mutation('import-html-section', ['title'=>$title,'len'=>strlen($html)]);
        if (empty($html)) return rest_ensure_response(new \WP_Error('no_html','No HTML',['status'=>400]));
        $id = wp_insert_post(['post_type'=>'wx_template','post_title'=>$title,'post_content'=>wp_kses_post($html),'post_status'=>'publish']);
        return rest_ensure_response(['success'=>true,'post_id'=>$id,'edit_url'=>admin_url('post.php?post='.$id.'&action=edit')]);
    }

    public function convert_html(\WP_REST_Request $req): \WP_REST_Response {
        $html = $req->get_param('html') ?? '';
        $target = sanitize_text_field($req->get_param('target') ?? 'elementor');
        $this->log_mutation('convert-html', ['target'=>$target,'len'=>strlen($html)]);
        if (empty($html)) return rest_ensure_response(new \WP_Error('no_html','No HTML',['status'=>400]));
        $result = ['html'=>$html,'target'=>$target];
        if ('elementor' === $target || 'both' === $target) {
            $result['elementor'] = ['version'=>'0.4','title'=>'Converted','type'=>'section','content'=>[['id'=>'a1','elType'=>'widget','widgetType'=>'html','settings'=>['html'=>$html]]]];
        }
        return rest_ensure_response($result);
    }

    public function list_elements(): \WP_REST_Response {
        return rest_ensure_response([
            ['slug'=>'hero-slider','name'=>'Hero Slider','mcp_tool'=>'list_hero_slides'],
            ['slug'=>'cine','name'=>'Cine Hero','mcp_tool'=>'render_cine_preview'],
            ['slug'=>'brief-form','name'=>'Brief Form','mcp_tool'=>'render_brief_form'],
            ['slug'=>'ticker','name'=>'Ticker','mcp_tool'=>'list_ticker'],
            ['slug'=>'gates','name'=>'Process Gates','mcp_tool'=>'list_gates'],
        ]);
    }

    public function render_preview(\WP_REST_Request $req): \WP_REST_Response {
        $element = sanitize_text_field($req->get_param('element') ?? '');
        $this->log_mutation('render-preview', ['element'=>$element]);
        return rest_ensure_response(['html'=>'<div class="wx-'.$element.'">Preview '.$element.'</div>','element'=>$element]);
    }

    public function add_page(): void {
        add_management_page(esc_html__('WX Agent','wx-core'), esc_html__('WX Agent','wx-core'), 'manage_options', 'wx-agent', [$this,'render']);
        add_menu_page(esc_html__('WX Agent','wx-core'), esc_html__('WX Agent','wx-core'), 'manage_options', 'wx-agent-connect', [$this,'render'], 'dashicons-rest-api', 30);
    }

    public function render(): void {
        if (!current_user_can('manage_options')) return;
        $site = home_url();
        $rest = $site . '/wp-json/wx-agent/v1/';
        $agentbridge_rest = $site . '/wp-json/agentbridge/v1/mcp';
        $token = get_option('wx_agent_token', '');
        if (empty($token)) { $token = wp_generate_password(32,false); update_option('wx_agent_token',$token); }
        $allow = get_option('wx_agent_allow_non_https', false);
        $rate = get_option('wx_agent_rate_limit', 10);
        $agentbridge_active = is_plugin_active('agentbridge/agentbridge.php');
        $emcp_active = is_plugin_active('elementor-mcp/elementor-mcp.php') || is_plugin_active('emcp-tools/emcp-tools.php');
        ?>
        <div class="wrap">
            <h1>WX → Agent Connect — ALL CLIs</h1>
            <p>Endpoints: <code><?php echo esc_url($rest); ?></code></p>
            <h2>Settings</h2>
            <form method="post" action="options.php">
                <?php settings_fields('wx_agent_settings'); ?>
                <label><input type="checkbox" name="wx_agent_allow_non_https" value="1" <?php checked($allow,true); ?>> Allow on non-HTTPS (local) for woodex.local</label><br>
                <label>Rate Limit: <input type="number" name="wx_agent_rate_limit" value="<?php echo esc_attr($rate); ?>"></label>
                <?php submit_button(); ?>
            </form>
            <h2>Status</h2>
            <p>AgentBridge: <?php echo $agentbridge_active ? '✓' : '✗'; ?> | EMCP: <?php echo $emcp_active ? '✓' : '✗'; ?> | WX Agent: ✓</p>
            <h2>Claude Code</h2>
            <pre>claude mcp add --transport http wx-agent <?php echo esc_url($rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"
claude mcp add --transport http agentbridge <?php echo esc_url($agentbridge_rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"</pre>
            <h2>Claude Desktop (mcp-remote bridge)</h2>
            <pre>{
  "mcpServers": {
    "wx-agent": {"command":"npx","args":["-y","mcp-remote","<?php echo esc_url($rest); ?>","--header","Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"]},
    "agentbridge": {"command":"npx","args":["-y","mcp-remote","<?php echo esc_url($agentbridge_rest); ?>","--header","Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"]}
  }
}</pre>
            <p><a href="<?php echo esc_url(admin_url('admin-ajax.php?action=wx_download_claude_config&nonce='.wp_create_nonce('wx-admin-nonce'))); ?>" class="button">⬇ Download claude_desktop_config.json</a></p>
            <h2>Hermes</h2><pre>hermes mcp add wx-agent --url <?php echo esc_url($rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"</pre>
            <h2>Gemini CLI</h2><pre>{"mcpServers":{"wx-agent":{"httpUrl":"<?php echo esc_url($rest); ?>","headers":{"Authorization":"Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"}}}}</pre>
            <h2>Cursor</h2><pre>{"mcpServers":{"wx-agent":{"url":"<?php echo esc_url($rest); ?>","headers":{"Authorization":"Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"}}}}</pre>
            <h2>Cline</h2><pre>{"mcpServers":{"wx-agent":{"url":"<?php echo esc_url($rest); ?>","headers":{"Authorization":"Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"}}}}</pre>
            <h2>Codex</h2><pre>codex mcp add wx-agent -- npx -y mcp-remote <?php echo esc_url($rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"</pre>
            <h2>Test curl</h2>
            <pre>curl -u "admin:<?php echo esc_attr($token); ?>" <?php echo esc_url($rest); ?>inspect-site/
curl -u "admin:wrong" <?php echo esc_url($rest); ?>inspect-site/ # 401/403 expected</pre>
        </div>
        <?php
    }

    public function download_claude_config(): void {
        check_ajax_referer('wx-admin-nonce','nonce');
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        $site = home_url();
        $rest = $site . '/wp-json/wx-agent/v1/';
        $agentbridge_rest = $site . '/wp-json/agentbridge/v1/mcp';
        $token = get_option('wx_agent_token','');
        $config = [
            'mcpServers'=>[
                'wx-agent'=>['command'=>'npx','args'=>['-y','mcp-remote',$rest,'--header','Authorization: Basic '.base64_encode('admin:'.$token)]],
                'agentbridge'=>['command'=>'npx','args'=>['-y','mcp-remote',$agentbridge_rest,'--header','Authorization: Basic '.base64_encode('admin:'.$token)]],
            ]
        ];
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="claude_desktop_config.json"');
        echo wp_json_encode($config, JSON_PRETTY_PRINT);
        exit;
    }
}
