<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
class WX_Core_Elementor {
    private static ?self $instance = null;
    public static function instance(): self { if (null===self::$instance) self::$instance=new self(); return self::$instance; }
    public function __construct() { add_action('elementor/widgets/register', [$this,'register_widgets']); }
    public function register_widgets($manager): void {
        // Register WX elements as Elementor widgets — original, no copy
        $widgets = ['hero-slider','cine','brief-form','ticker','gates'];
        foreach ($widgets as $w) {
            $file = WX_CORE_DIR . 'includes/widgets/class-wx-'.$w.'.php';
            if (file_exists($file)) {
                require_once $file;
                $class = 'WX_' . str_replace('-','_', ucwords($w,'-')) . '_Widget';
                if (class_exists($class)) $manager->register(new $class());
            }
        }
    }
}
