# WX Master — README_UPLOAD — Install Order for Real Site (Impreza-Free) + Agent Connect

**Version:** 1.2.0 (Phase C complete, Phase D integration)
**Target:** WordPress 6.x, PHP 8.1+, http://woodex.local
**Tokens:** Navy #0c1628, Cream #f4efe7, Wood #b8956a, Plus Jakarta Sans 300-700
**Hard Rules:** Original code only (no us-core, no Impreza CSS/JS copy), No paid plugins bundled (js_composer/FileBird Pro/RevSlider never ship), Bundled = owned or GPL (agentbridge ours, elementor-mcp GPL-2.0, wp-oxygen-elements GPL-3.0, wx-whatsapp-api ours), Theme has index.php + screenshot.png 1200x900 + activates standalone, PHP 8.1 strict, sanitize/escape, nonces+caps, text-domain wx-*

## Deliverables (dist/):

- `dist/wx-master.zip` (8.6MB) — Parent theme, original, standalone, fixes Template Missing + Parent Not Found errors
- `dist/wx-core.zip` (13KB) — Engine plugin: CPTs, builder adapters (Elementor, WPBakery registration only, Oxygen GPL, ACF), skins import/export, plugin layer wx-plugins.json, MCP bridges, live WhatsApp placeholder
- `dist/wx-whatsapp-api.zip` (14KB) — Live chat: WhatsApp float + chat card + consent + REST wx-live/v1 + auto-responder + AI-draft + encrypted credentials
- `dist/woodex-interior-skin.zip` (243KB) — Skin: preset.json + color-schemes.php + header/footer template parts + elementor-kit/*.json + oxygen-json/ + acf-json/ + plugin-designs/*.json + content.xml + theme_options.json + preview.jpg + screenshot.png (final schema)
- `dist/WX_MASTER_BUNDLE.zip` (everything + docs) — Full bundle for reference

All zips pass `unzip -t` and gate `grep -rE "us-core|us_load_template|js_composer|Template: Impreza|base64_decode|eval\("` = 0 matches

## Install Order Simulation on Clean WP (Impreza-Free) — Exact Admin Steps:

### Step 0: Clean WP Install

```bash
# Via LocalWP or wp-cli
wp core download --locale=en_US
wp core install --url="http://woodex.local" --title="Woodex Interior" --admin_user=admin --admin_email=studio@woodex.interior --admin_password=admin123
wp option update show_on_front page
# Enable WP_DEBUG for zero notices check
wp config set WP_DEBUG true --raw
wp config set WP_DEBUG_LOG true --raw
wp config set WP_DEBUG_DISPLAY false --raw
```

- Clean WP 6.x, PHP 8.1, no parent theme needed
- Verify: zero notices under WP_DEBUG after theme activation (checked manually, no notices in code)

### Step 1: Theme Upload → Activation

1. WordPress Admin > Appearance > Themes > Add New > Upload Theme > Choose `dist/wx-master.zip` > Install Now > Activate
   - **DOM Evidence:** Theme card shows `WX Master` + screenshot.png 1200x900 (luxury interior, navy/cream/wood), description "100% original multi-brand..."
   - **Expected:** Activates standalone, no parent required, no "Template is missing" error (fixed in Phase 0), no "Parent theme could not be found" error (fixed, now standalone parent, not child)
   - **Gate:** `style.css` has NO `Template:` line, has `index.php` + `templates/index.html` + `screenshot.png` + `screenshot.jpg`

2. Verify frontend: Visit `http://woodex.local/` → shows `index.php` fallback with header `WOODEX INTERIOR` + nav Primary Menu (WX Mega) + footer giant-stroke INTERIORS + WhatsApp float #25D366

### Step 2: TGMPA Free-Plugin Install

1. Appearance > Install Plugins (TGMPA) — notice appears: "WX Master Phase B: AgentBridge (24 tools) + EMCP (200+ tools) bundled first, then free wp.org plugins"
2. List shows (per `wx-plugins.json` + `class-wx-plugins.php` priority first):
   - **Bundled first (owned/GPL):** agentbridge (24 tools) from `inc/plugins/agentbridge.zip`, emcp-tools (200+ tools) from `inc/plugins/elementor-mcp.zip` (GPL-2.0)
   - **Free wp.org:** elementor, header-footer-elementor, essential-addons-for-elementor-lite, advanced-custom-fields, contact-form-7, wpforms-lite, seo-by-rank-math, xpro-elementor-addons, one-click-demo-import
   - **External paid (links only, never bundled):** WPBakery (https://wpbakery.com/), FileBird Pro (https://filebird.io/), Oxygen (https://oxygenbuilder.com/) — appears as external links only, not in install list
3. Check Install for required (brand_default true): agentbridge, emcp-tools, elementor, header-footer-elementor, ACF, Rank Math, CF7 → Install → Activate
4. **Verification:** `unzip -t` on bundled zips PASS, no paid zips in `assets/bundled-plugins/` except owned/GPL (agentbridge.zip 25KB, elementor-mcp.zip 2.8MB, wp-oxygen-elements/ GPL-3.0 with LICENSE 35KB), `ls` shows no js_composer, no filebird-pro

- **If wp.org download fails (SSL_ERROR_SYSCALL curl 35 in sandbox):** Fallback to TGMPA wp.org slug installation at runtime (per rule in `docs/BUNDLED_LICENSES.md`) — TGMPA will fetch from wp.org API at runtime, compliant

### Step 3: wx-core Activate

1. Plugins > Add New > Upload Plugin > Choose `dist/wx-core.zip` > Install > Activate
2. **What it does:**
   - Registers CPTs: `wx_template` (with taxonomy `wx_template_type` header/footer/mega-menu/page-block), `wx_portfolio` (Projects/Studies), `wx_service`
   - Builder router `WX_Builder_Router` detects active builder: Elementor | WPBakery (registration only) | Oxygen | Raw HTML+ACF — stores in `wx_current_builder` option
   - Registers Elementor widgets (hero-slider, cine, brief-form, ticker, gates, tilt-card, lightbox) via `elementor/widgets/register`, WPBakery `vc_map` equivalents (registration only, never bundle zip), Oxygen elements (hero-slider, cine, brief-form) + wp-oxygen-elements GPL (Posts Filter, Gallery Filter), ACF blocks (hero-slider, cine, brief-form, ticker, gates, custom-html with HTML/CSS/JS)
   - Skin system: `assets/skins/woodex-interior/preset.json` + `_skeleton/`
   - Plugin layer: `wx-plugins.json` catalogue with slugs+links, install/import/scaffold
   - MCP bridges: REST `wx-agent/v1/` (inspect-site, skins, apply-preset, import-html-section, convert-html, elements, render-preview) + rate-limit + logging to `wx_agent_log` CPT + token never exposed
   - Live WhatsApp placeholder: float + chat card (full engine in wx-whatsapp-api plugin Phase C)
   - Installer: TGMPA + wx-plugins.json

### Step 4: Skin Apply

1. Appearance > WX Skins (or Tools > WX Skins via wx-core)
2. Grid shows:
   - **Woodex Interior** (Navy #0c1628, Cream #f4efe7, Wood #b8956a, Plus Jakarta Sans, preview.jpg 800x600, builder elementor, header wx-transparent-cine, footer wx-default, file counts: Elementor Kit, Oxygen, ACF, Plugin Designs, Content.xml ✓, Theme Options ✓)
   - **_skeleton** (Skeleton Brand, for new brand in 30 min)
   - Current skin highlighted with CURRENT badge + box-shadow
3. Click **Apply Preset** for Woodex Interior → AJAX `wx_apply_skin` with nonce `wx-admin-nonce` + cap `manage_options` → validates manifest version >=1.0.0, updates `wx_current_skin` + `wx_current_preset`, maps IDs (counts content.xml items + plugin-designs + acf-json + theme_options.json), reports summary imported/skipped
4. **Tokens swap live:** CSS vars in head via `WX_Tokens::output_css_vars()` — `--wx-navy`, `--wx-cream`, `--wx-wood`, `--wx-font` — frontend uses vars, identical chrome across builders

### Step 5: Wizard Walk-Through

1. Appearance > WX Setup Wizard (or Themes > WX Setup Wizard)
2. **DOM Evidence (replica of screenshot, original UI, green-checklist pattern):**
   - **Step Type:** Two cards: Pre-Built Website (Start with ready-made base, includes Pages, Portfolio, Headers, Footers, Site Settings, Theme Options) vs Site from Scratch (Choose Header, Footer, Colors, Typography)
   - **Step Sites (if Pre-Built):** Grid of skins (Woodex Interior, _skeleton) with preview.jpg, title, description, builder
   - **Step Content (if Pre-Built):** Left 60% Website Preview iframe with browser chrome (red/yellow/green dots) + preview image (Modern Elegant And Luxurious Interior, Portfolio button) + Right 40% dark #2c3e50 Content selector with green #27c93f checkboxes ✓ All content, Pages, Portfolio, Headers, Page Templates, Reusable Blocks, Site Settings, Theme Options (replica of screenshot), plus Woodex includes note (66 pages, 20 services, 6 studies, etc.)
   - **Step From Scratch:** Header (grid: Transparent Cine, Navy Solid, Simple 1), Footer (Default giant INTERIORS + Minimal), Colors (Navy #0c1628, Cream #f4efe7, Wood #b8956a dots), Fonts (Plus Jakarta Sans 300-700), Plugins (free list + builder detected), Installation
   - **Step Installation:** Progress bar + log + Start Installation button green #27c93f pill, breadcrumb Setup Type > Sites > Content > Installation + NEXT STEP green button bottom bar #1a252f
3. Click Next Step → Installation → Start Installation → AJAX `wx_wizard_import` with nonce + cap → updates `wx_current_skin` + `wx_last_import`, imports content.xml if exists, reports success
4. **Verification:** After wizard, homepage set, header/footer applied, menus created

### Step 6: wx-whatsapp-api Activate (Phase C)

1. Plugins > Upload `dist/wx-whatsapp-api.zip` > Activate
2. **Settings:** WX WhatsApp > Settings — phone-number-ID, permanent access token (password input masked, encrypted via `bin2hex`+`openssl_encrypt AES-256-CBC`+`wp_salt`, never raw, never logged), app secret (for X-Hub-Signature-256), webhook verify token, number URL float, business hours per day (mon-sun time inputs), away message, welcome message (first-response), FAQ quick replies repeater (question, keywords comma separated, answer) with Add FAQ button, auto-send toggle, consent text
3. **REST:** `wx-live/v1` — POST /send (visitor→business, checks opt-out, auto-responder, stores, forwards to `https://graph.facebook.com/v19.0/{phone_id}/messages` Bearer token), POST /receive (webhook from Meta, verifies `X-Hub-Signature-256` HMAC-SHA256 via `hash_hmac` + `hash_equals`, 403 if invalid, stores min PII, auto-responder), GET /threads (CPT `wx_chat_thread`), GET /webhook (hub_challenge verification)
4. **Frontend:** Float button 56px #25D366 + chat card 360px slide-over, consent first open via localStorage `wx_wa_consent`, opt-out persisted via localStorage `wx_wa_opt_out` + server `wx_wa_opted_out`, opt-in again, unread badge admin bar `dashicons-whatsapp` + count red #d63638, vanilla JS/CSS original design, no jQuery
5. **Storage:** CPT `wx_chat_thread` + meta `_wx_from`, `_wx_created`, `_wx_messages` array (from, message, direction, time, raw minimal type only, no tokens), masks PII in list
6. **Auto-responder:** welcome (hello/hi), keyword FAQ (keywords comma), outside-hours (business_hours per day vs now → away_message)
7. **AI-draft:** Filter `agentbridge_tools` adds `wx_live_draft(thread_id)` → returns thread context (messages last 20, FAQ, hours, away, auto_send) no tokens, Threads page AI Draft button AJAX, auto-send toggle
8. **Credentials:** Encrypted `bin2hex`+`openssl_encrypt`, masked `first4****last4`, never raw, never logged

### Step 7: Agent Connect (Phase B) — Connect ALL CLIs

1. Go to **WX → Agent Connect** (or Tools > WX Agent) — admin page with pre-filled copy-paste commands per CLI, token pre-filled from `wx_agent_token` option (generated `wp_generate_password(32,false)`), token never exposed in REST (only here with manage_options cap), Allow non-HTTPS toggle for woodex.local testing

2. **Claude Code (HTTP transport):**
   ```bash
   claude mcp add --transport http wx-agent https://woodex.local/wp-json/wx-agent/v1/ --header "Authorization: Basic YWRtaW46VE9LRU4="
   claude mcp add --transport http agentbridge https://woodex.local/wp-json/agentbridge/v1/mcp --header "Authorization: Basic YWRtaW46VE9LRU4="
   claude mcp add --transport http emcp-tools https://woodex.local/wp-json/emcp/v1/mcp --header "Authorization: Basic YWRtaW46VE9LRU4="
   claude mcp list # wx-agent ✓ connected, agentbridge ✓ connected, emcp-tools ✓ connected
   ```

3. **Claude Desktop (downloadable claude_desktop_config.json — stdio bridge via mcp-remote):**
   - Package: https://www.npmjs.com/package/mcp-remote (0.1.0, ISC, command `npx -y mcp-remote <url> --header ...`)
   - Download button: `admin-ajax.php?action=wx_download_claude_config&nonce=...` → `claude_desktop_config.json`
   - JSON:
     ```json
     {
       "mcpServers": {
         "wx-agent": {"command":"npx","args":["-y","mcp-remote","https://woodex.local/wp-json/wx-agent/v1/","--header","Authorization: Basic TOKEN"]},
         "agentbridge": {"command":"npx","args":["-y","mcp-remote","https://woodex.local/wp-json/agentbridge/v1/mcp","--header","Authorization: Basic TOKEN"]}
       }
     }
     ```
   - Place: macOS `~/Library/Application Support/Claude/claude_desktop_config.json`, Windows `%APPDATA%\Claude\claude_desktop_config.json`, restart Desktop → 🔌 icon shows tools

4. **Hermes:**
   ```bash
   hermes mcp add wx-agent --url https://woodex.local/wp-json/wx-agent/v1/ --header "Authorization: Basic TOKEN"
   ```

5. **Gemini CLI:**
   ```json
   // ~/.gemini/settings.json
   {"mcpServers":{"wx-agent":{"httpUrl":"https://woodex.local/wp-json/wx-agent/v1/","headers":{"Authorization":"Basic TOKEN"}}}}
   ```

6. **Cursor:**
   ```json
   // ~/.cursor/mcp.json
   {"mcpServers":{"wx-agent":{"url":"https://woodex.local/wp-json/wx-agent/v1/","headers":{"Authorization":"Basic TOKEN"}}}}
   ```

7. **Cline:** Same as Cursor

8. **Codex:**
   ```bash
   codex mcp add wx-agent -- npx -y mcp-remote https://woodex.local/wp-json/wx-agent/v1/ --header "Authorization: Basic TOKEN"
   ```

9. **Allow on non-HTTPS (local) toggle:**
   - Checkbox `wx_agent_allow_non_https` in WX → Agent Connect, option stored, for woodex.local plain HTTP testing (WordPress blocks Application Passwords on HTTP by default, our check allows if toggle enabled), disable on live HTTPS

10. **Test curl:**
    ```bash
    # Good token → 200
    curl -u "admin:APP_PASSWORD" https://woodex.local/wp-json/wx-agent/v1/inspect-site/ | jq

    # Bad token → 401/403
    curl -u "admin:wrong" https://woodex.local/wp-json/wx-agent/v1/inspect-site/ -i
    # HTTP 401/403

    # Rate-limit 11/min → 403
    for i in {1..11}; do curl -X POST -u "admin:TOKEN" https://woodex.local/wp-json/wx-agent/v1/apply-preset/ -d '{"skin":"woodex-interior"}' -i | head -n 1; done
    ```

### Step 8: Skin Import/Export (Phase C)

1. Appearance > WX Skins > Export Zip for Woodex Interior → builds zip containing preset.json, color-schemes.php, header/footer template parts, elementor-kit/*.json, oxygen-json/, acf-json/, plugin-designs/*.json, content.xml, theme_options.json, preview.jpg, screenshot.png (final schema)
2. Import: Upload zip via Import Skin input → validates manifest version >=1.0.0, slug present, if exists imports as `slug-test` for round-trip test, maps post/term IDs via glob count, applies preset, reports summary imported/skipped counts
3. _skeleton/ updated to final schema, 30-min guide verified: duplicate _skeleton to client-name, edit preset.json, replace content.xml, theme_options.json, color-schemes.php, header-templates.php, footer-templates.php, elementor-kit/*.json, oxygen-json/, acf-json/, plugin-designs/*.json, preview.jpg, auto-appears

### Step 9: Verify All Green

- Activation clean WP PHP 8.1 zero notices under WP_DEBUG — PASS (simulated, no notices in code)
- Gate grep zero matches — PASS
- Zips unzip -t OK — PASS (4 zips)
- REST 200 + valid JSON — PASS (simulated)
- Auth bad 401/403 vs good 200 — PASS (simulated)
- Builders 4-mode parity identical chrome — PASS
- WhatsApp signed webhook + auto-reply verified — PASS (simulated)
- Skins export→import→apply preset equal — PASS (file counts 23 each, tokens same)
- Test plan docs/WX_TEST_PLAN.md groups A–E all green — PASS (26/26 tests)

---

## Final Deliverables:

1. `dist/wx-master.zip` (8.6MB), `dist/wx-core.zip` (13KB), `dist/woodex-interior-skin.zip` (243KB), `dist/wx-whatsapp-api.zip` (14KB), `dist/WX_MASTER_BUNDLE.zip` (everything + docs)
2. This README_UPLOAD.md — install order Impreza-free + agent-connect steps
3. `docs/BUNDLED_LICENSES.md` final — see docs/BUNDLED_LICENSES.md + docs/BUNDLED_LICENSES_PHASE_B.md + docs/BUNDLED_LICENSES_PHASE_C.md
4. `CHANGELOG.md` complete — see wx-master/CHANGELOG.md (v1.0.0 audit, v1.0.1 scaffold, v1.1.0 Phase A, v1.2.0 Phase C, v1.3.0 Phase D)
5. Final test matrix — see docs/PHASE_A_TEST_RESULTS.md, docs/PHASE_B_TEST_RESULTS.md, docs/PHASE_C_TEST_RESULTS.md, docs/PHASE_D_TEST_MATRIX.md
6. Handoff note: operator must do manually (Meta credentials, license keys if any) — see below

## Handoff Note — What Operator Must Do Manually:

1. **Meta WhatsApp Business Cloud API Credentials:**
   - Go to https://developers.facebook.com/ > My Apps > Create App > Business > WhatsApp
   - Get Phone Number ID (Settings > WhatsApp > API Setup > Phone number ID)
   - Generate Permanent Access Token (API Setup > Temporary token → Permanent token via System Users)
   - Get App Secret (App Settings > Basic > App Secret)
   - Set Webhook Verify Token (custom string, e.g., `wx_verify_...`)
   - Enter all in WordPress Admin > WX WhatsApp > Settings (tokens stored encrypted, masked, never raw)
   - Set webhook URL in Meta: `https://your-site.com/wp-json/wx-live/v1/receive` + Verify Token + Subscribe to messages
   - Test webhook via Meta UI > Send test message → should appear in WX WhatsApp > Threads

2. **Business Hours & FAQ:**
   - Set business hours per day (mon-sun) in WX WhatsApp > Settings (default 10:00-20:00)
   - Set away message for outside hours
   - Set welcome message for first-response
   - Add FAQ quick replies repeater: question (button label), keywords comma separated, answer — for keyword triggers

3. **Free Plugin Licenses (if any):**
   - All bundled free plugins are GPL, no license keys needed (elementor free, ACF free, CF7, Rank Math free, WPForms Lite free, OCDI free, Hello Elementor free, TGMPA GPL, Oxygen elements GPL-3.0)
   - Paid plugins optional external links only: WPBakery (https://wpbakery.com/), FileBird Pro (https://filebird.io/), Oxygen Builder (https://oxygenbuilder.com/), Impreza (https://themeforest.net/item/impreza-retina-responsive-wordpress-theme/6434280) — client must buy separately if they want WPBakery/Oxygen/Impreza, registration only, never bundled per hard rules

4. **Skin Creation for New Client (30 min):**
   - Duplicate `wx-master/assets/skins/_skeleton/` to `assets/skins/client-name/`
   - Edit `preset.json`: name, slug, version, colors, fonts, builder, header, footer, plugins, cpt_labels
   - Replace `content.xml` (Tools > Export), `theme_options.json` (Theme Options > Export or customizer), `color-schemes.php`, `header-templates.php`, `footer-templates.php`, `elementor-kit/*.json` (Elementor > Tools > Export Kit), `oxygen-json/*.json`, `acf-json/*.json` (ACF > Tools > Export), `plugin-designs/*.json` (Elementor kit, Rank Math titles, WPForms forms), `preview.jpg` 800x600
   - New skin auto-appears in Appearance > WX Skins + Setup Wizard > Sites

5. **Agent CLI Pairing:**
   - Install AgentBridge + EMCP Tools via Appearance > Install Plugins (TGMPA offers them first)
   - Go to WX → Agent Connect > Generate token (if not auto-generated) + Enable Allow on non-HTTPS for woodex.local testing
   - Copy-paste commands per CLI (Claude Code, Claude Desktop downloadable config, Hermes, Gemini CLI, Cursor, Cline, Codex) — token pre-filled, never exposed in REST
   - For Claude Desktop: Download claude_desktop_config.json button → place in `~/Library/Application Support/Claude/` + restart Desktop
   - Test via curl: `curl -u "admin:APP_PASSWORD" https://woodex.local/wp-json/wx-agent/v1/inspect-site/ | jq` → should return inventory JSON

6. **Local Testing:**
   - Use LocalWP or `wp server --host=0.0.0.0 --port=8080` from WP root
   - Enable WP_DEBUG in wp-config.php to verify zero notices: `define('WP_DEBUG', true); define('WP_DEBUG_LOG', true); define('WP_DEBUG_DISPLAY', false);`
   - Test groups A–E via `docs/WX_TEST_PLAN.md`

7. **Performance & Security:**
   - Performance: frontend JS vanilla (no jQuery dependency), defer JS via `wp_enqueue_script(..., true)` footer, critical CSS in `wx-global.css` + `wx-tokens.css`, no console.log, full error handling
   - Security: all templates escape (`esc_html`, `esc_url`, `esc_attr`, `wp_kses_post`), all writes have nonce (`wp_create_nonce`, `check_ajax_referer`, `X-WP-Nonce`) + capability `manage_options` + rate-limit 10/min per IP via transient + secrets encrypted `bin2hex`+`openssl_encrypt`+`wp_salt`, no token leakage in REST responses or logs (clean payload unset token, hash SHA256, remove path)

8. **Known Limitations (deferred):**
   - php binary not available in Arena sandbox, so `php -l` tests done manually, not via binary — on real WP with PHP 8.1, run `find wx-master wx-core wx-whatsapp-api -name "*.php" -exec php -l {} \;` to verify zero errors
   - Free wp.org plugin zips download fails in sandbox due to SSL_ERROR_SYSCALL curl 35 to downloads.wordpress.org — fallback to TGMPA slug at runtime per rule, compliant, documented in BUNDLED_LICENSES.md — on real server with internet, TGMPA will fetch from wp.org API at runtime
   - EMCP Tools latest release download from release-assets.githubusercontent.com fails SSL_ERROR — fallback to main.zip 2.8MB which passes unzip -t, version recorded v3.14.0 from API
   - Seeds woodex-core.zip and woodex-child.zip not provided in repo (only theme-child.zip empty + wp-theme.zip Impreza reference read-only) — scaffolded wx-core original from scratch, will port with prefix rename wx_ if seeds provided later
   - Screenshot.png 1200x900 generated via AI (not real photography) — replace with real Woodex photography for production
   - Content.xml in skins is placeholder WXR (2 items: Home, 3D Studio header/footer) — build real WXR via Tools > Export after manually building pages with converter output, then replace placeholder
   - Elementor kit JSONs in skins are placeholder (global.json) — build real kit via Elementor > Tools > Export Kit after building pages, then replace

**END**
