<?php
/**
 * WX Footer Base — Original
 *
 * @package wx-master
 */
defined('ABSPATH') || exit;
?>
<footer class="wx-footer">
  <div class="wx-container">
    <div class="wx-footer-top">
      <div>
        <h3><?php esc_html_e('Stay connected', 'wx-master'); ?></h3>
        <p><?php esc_html_e('We turn ideas into spaces. One partner. From concept to completion.', 'wx-master'); ?></p>
      </div>
      <div>
        <p><a href="mailto:studio@woodex.interior">studio@woodex.interior</a> | <a href="https://wa.me/923224000768">+92 322 4000768</a></p>
      </div>
    </div>
    <div class="wx-footer-mid">
      <div>
        <h4><?php esc_html_e('Services', 'wx-master'); ?></h4>
        <ul><li><a href="/services/residential.html">Residential</a></li><li><a href="/services/office.html">Office</a></li><li><a href="/3d-studio.html">3D Studio</a></li></ul>
      </div>
      <div>
        <h4><?php esc_html_e('Studio', 'wx-master'); ?></h4>
        <p>500+ projects · ~20 years founder · 10+ years execution · ISO 9001<br>Wellstar Pharmacy → Cosmetics → Mini Hospital, DHA Lahore</p>
      </div>
      <div>
        <h4><?php esc_html_e('Locations', 'wx-master'); ?></h4>
        <p>Gulberg III Lahore<br>Clifton Karachi<br>F-7 Islamabad</p>
      </div>
      <div>
        <h4><?php esc_html_e('Contact', 'wx-master'); ?></h4>
        <p>LG 90 Link Road, Model Town, Lahore<br>10:00–8:30<br><a href="https://wa.me/923224000768">WhatsApp</a></p>
      </div>
    </div>
    <div class="wx-footer-bottom">
      <div class="wx-footer-giant">INTERIORS</div>
      <div class="wx-footer-copy">© <span data-wx-year></span> Woodex Interior — DRAWN. THEN BUILT.</div>
    </div>
  </div>
</footer>

<!-- WhatsApp Float + Chat Card (Original CSS, no SaaS) -->
<a href="https://wa.me/923224000768" class="wx-float-whatsapp" aria-label="WhatsApp" target="_blank" rel="noopener">
  <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M19.5 3.5a9 9 0 0 0-12.8 12.6L3 21l5-1.3A9 9 0 0 0 19.5 3.5zM12 19a6.9 6.9 0 0 1-3.5-.9l-.3-.2-3 .8.8-2.9-.2-.3A6.9 6.9 0 0 1 12 5a6.9 6.9 0 0 1 7 7 6.9 6.9 0 0 1-7 7zm3.9-5.1c-.2-.1-1.3-.6-1.5-.7s-.4-.1-.5.1-.6.7-.7.8-.3.2-.5.1a5.6 5.6 0 0 1-1.6-1 6 6 0 0 1-1.1-1.4c-.1-.2 0-.4.1-.5l.4-.5c.1-.1.1-.2.2-.4s0-.3 0-.4-.5-1.3-.7-1.8-.4-.4-.5-.4h-.5c-.2 0-.4.1-.6.3s-.7.7-.7 1.8.7 2 1 2.3a8 8 0 0 0 3 2.7c.4.2.7.3.9.4.4.1.7.1 1 0 .3-.1 1.3-.5 1.5-1s.2-.9.1-1c0-.1-.2-.2-.4-.3z"/></svg>
</a>

<div class="wx-chat-card" id="wx-chat-card">
  <div style="background:var(--wx-navy);color:#fff;padding:16px;display:flex;justify-content:space-between;align-items:center;">
    <strong>Woodex Interior</strong>
    <button class="wx-chat-close" style="color:#fff;">✕</button>
  </div>
  <div style="padding:16px;">
    <div class="wx-consent" hidden style="background:#f4efe7;padding:12px;border-radius:8px;margin-bottom:12px;font-size:13px;">
      <?php esc_html_e('We use WhatsApp Business Cloud API to reply. By continuing, you consent to our privacy policy.', 'wx-master'); ?>
      <button onclick="localStorage.setItem('wx-consent','1'); this.parentElement.hidden=true;" class="wx-btn" style="margin-top:8px;height:36px;"><?php esc_html_e('I agree', 'wx-master'); ?></button>
    </div>
    <p style="font-size:14px;"><?php esc_html_e('Hello! How can we help with your interior project? Our studio replies within one working day.', 'wx-master'); ?></p>
    <a href="https://wa.me/923224000768?text=Hello%20Woodex%20—%20project%20brief." target="_blank" rel="noopener" class="wx-btn" style="margin-top:12px;"><?php esc_html_e('Open WhatsApp', 'wx-master'); ?></a>
  </div>
</div>

<div id="wx-lightbox" class="wx-lightbox" hidden style="position:fixed;inset:0;z-index:300;background:rgba(12,22,40,.92);display:grid;place-items:center;opacity:0;transition:opacity .4s;">
  <img src="" alt="" style="max-width:90vw;max-height:90vh;border-radius:12px;">
  <button class="wx-lb-x" style="position:absolute;top:20px;right:20px;color:#fff;font-size:24px;">✕</button>
</div>
