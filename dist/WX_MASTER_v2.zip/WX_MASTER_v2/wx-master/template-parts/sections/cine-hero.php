<?php defined('ABSPATH') || exit;
$title = $args['title'] ?? 'See it. Understand it. Build it.';
$eyebrow = $args['eyebrow'] ?? '3D Studio';
$image = $args['image'] ?? '';
$height = $args['height'] ?? 'full';
$cls = $height === 'short' ? 'wx-cine-hero is-short' : 'wx-cine-hero';
?>
<div class="<?php echo esc_attr($cls); ?>">
  <?php if($image): ?><img src="<?php echo esc_url($image); ?>" alt=""><?php endif; ?>
  <div class="wx-cine-content">
    <?php if($eyebrow): ?><div class="wx-eyebrow"><?php echo esc_html($eyebrow); ?></div><?php endif; ?>
    <h1><?php echo esc_html($title); ?></h1>
  </div>
</div>
