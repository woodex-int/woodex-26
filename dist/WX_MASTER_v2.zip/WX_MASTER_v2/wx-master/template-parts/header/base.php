<?php
/**
 * WX Header Base — Original fallback
 *
 * @package wx-master
 */
defined('ABSPATH') || exit;
?>
<header class="wx-header" id="wx-header">
  <div class="wx-header-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="wx-logo">
      <?php if (has_custom_logo()): ?>
        <?php the_custom_logo(); ?>
      <?php else: ?>
        <span>WOODEX</span><small>INTERIOR</small>
      <?php endif; ?>
    </a>
    <nav aria-label="<?php esc_attr_e('Primary', 'wx-master'); ?>">
      <?php
      wp_nav_menu([
        'theme_location' => 'primary',
        'container' => false,
        'menu_class' => 'wx-nav',
        'fallback_cb' => function() {
          echo '<ul class="wx-nav"><li><a href="/">'.esc_html__('Home','wx-master').'</a></li><li><a href="/services.html">'.esc_html__('Services','wx-master').'</a></li><li><a href="/3d-studio.html">'.esc_html__('3D Studio','wx-master').'</a></li></ul>';
        },
      ]);
      ?>
    </nav>
    <a href="<?php echo esc_url(home_url('/start-your-project.html')); ?>" class="wx-btn">
      <span class="wx-btn-label"><?php esc_html_e('Start your project', 'wx-master'); ?></span>
      <span class="wx-btn-icon">→</span>
    </a>
    <button class="wx-menu-toggle" aria-label="<?php esc_attr_e('Open menu', 'wx-master'); ?>"><span></span><span></span><span></span></button>
  </div>
</header>
