<?php defined('ABSPATH') || exit; ?>
<div class="wx-mega-group" data-group="interior-design">
  <h4>Interior Design</h4>
  <ul class="wx-mega-list">
    <li><a href="/services/commercial.html">Commercial</a></li>
    <li><a href="/services/residential.html">Residential</a></li>
    <li><a href="/services/office.html">Office & Corporate</a></li>
    <li><a href="/services/retail.html">Retail & Shop</a></li>
    <li><a href="/services/shops.html">Brand Shop & Outlet</a></li>
  </ul>
</div>
