<?php defined('ABSPATH') || exit; ?>
<div class="wx-mega-group is-highlight" data-group="studio">
  <h4>Studio</h4>
  <div class="wx-mega-highlight">
    <small>Proof Engine</small>
    <h3>3D Studio — See it. Understand it. Build it.</h3>
    <p>You are not approving a plan. You are approving a room.</p>
    <a href="/3d-studio.html" class="wx-btn wx-btn-light">Explore 3D Studio</a>
  </div>
</div>
