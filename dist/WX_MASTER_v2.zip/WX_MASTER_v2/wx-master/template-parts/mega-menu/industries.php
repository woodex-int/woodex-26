<?php defined('ABSPATH') || exit; ?>
<div class="wx-mega-group" data-group="industries">
  <h4>Industries</h4>
  <ul class="wx-mega-list">
    <li><a href="/services/restaurant.html">Restaurant Interior</a></li>
    <li><a href="/services/cafe.html">Café Interior</a></li>
  </ul>
</div>
