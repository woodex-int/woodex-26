<?php
/**
 * WX Sidebar — Original
 *
 * @package wx-master
 */
defined('ABSPATH') || exit;
if (!is_active_sidebar('sidebar-1')) return;
?>
<aside id="secondary" class="widget-area wx-sidebar">
<?php dynamic_sidebar('sidebar-1'); ?>
</aside>
