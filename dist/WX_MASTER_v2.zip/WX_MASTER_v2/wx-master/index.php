<?php
/**
 * WX Master — Main Template (Required for standalone activation)
 * Original code, no third-party core, no Impreza dependency
 * 
 * @package wx-master
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

get_header();
?>

<main id="primary" class="site-main wx-main">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('wx-article'); ?>>
                <header class="wx-article-header">
                    <h1 class="wx-article-title"><?php the_title(); ?></h1>
                </header>
                <div class="wx-article-content">
                    <?php the_content(); ?>
                </div>
            </article>
            <?php
        endwhile;
        the_posts_pagination([
            'prev_text' => esc_html__('Previous', 'wx-master'),
            'next_text' => esc_html__('Next', 'wx-master'),
        ]);
    else :
        ?>
        <section class="wx-no-results">
            <h1><?php esc_html_e('Nothing found', 'wx-master'); ?></h1>
            <p><?php esc_html_e('It seems we can\'t find what you\'re looking for.', 'wx-master'); ?></p>
            <?php get_search_form(); ?>
        </section>
        <?php
    endif;
    ?>
</main>

<?php
get_sidebar();
get_footer();
