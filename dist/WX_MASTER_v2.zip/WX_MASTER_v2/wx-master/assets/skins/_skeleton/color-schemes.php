<?php
return [
  'skeleton' => [
    'title' => 'Skeleton — Navy / Cream / Wood',
    'values' => [
      'color_content_primary' => '#0c1628',
      'color_content_secondary' => '#b8956a',
    ]
  ]
];
