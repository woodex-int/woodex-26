# _skeleton — New Brand in 30 min

1. Duplicate this folder to `../client-name/`
2. Edit `preset.json`: name, slug, colors, fonts, builder, header, footer, plugins
3. Replace `content.xml` (WP export), `plugin-designs/*.json` (Elementor kits, forms, SEO), `acf-json/` (ACF fields), `preview.jpg` (800x600)
4. New skin auto-appears in Appearance > WX Skins + Setup Wizard > Sites

Checklist:
- preset.json edited
- preview.jpg 800x600
- content.xml present
- plugin-designs/ with elementor kit, forms, seo
- acf-json/ with flexible layouts
- Tested import
