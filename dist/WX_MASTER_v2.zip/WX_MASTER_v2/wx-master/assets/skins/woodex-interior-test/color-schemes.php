<?php
return [
  'woodex-interior' => [
    'title' => 'Woodex Interior — Navy / Cream / Wood',
    'values' => [
      'color_content_primary' => '#0c1628',
      'color_content_secondary' => '#b8956a',
      'color_content_bg' => '#ffffff',
      'color_content_bg_alt' => '#f4efe7',
    ]
  ]
];
