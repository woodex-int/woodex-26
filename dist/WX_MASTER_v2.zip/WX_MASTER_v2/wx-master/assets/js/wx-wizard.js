/**
 * WX Wizard — Vanilla JS, no jQuery
 */
(() => {
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];

  let currentStep = 'type';
  let selectedType = null;
  let selectedSkin = null;

  const showStep = (step) => {
    $$('.wx-wizard-step').forEach(el => el.hidden = el.dataset.step !== step);
    currentStep = step;
    // Update nav
    $$('.wx-wizard-nav [data-nav]').forEach(el => {
      el.classList.toggle('is-active', el.dataset.nav === step || (step.startsWith('scratch-') && el.dataset.nav === step));
      if (el.dataset.nav === 'content' && step === 'content') el.style.color = '#27c93f';
    });
  };

  $$('.wx-type-card').forEach(card => {
    card.addEventListener('click', () => {
      selectedType = card.dataset.type;
      $$('.wx-type-card').forEach(c => c.style.borderColor = '#ddd');
      card.style.borderColor = '#0c1628';
      if (selectedType === 'prebuilt') showStep('sites');
      else showStep('scratch-header');
    });
  });

  $$('.wx-site-card').forEach(card => {
    card.addEventListener('click', () => {
      selectedSkin = card.dataset.skin;
      $$('.wx-site-card').forEach(c => c.classList.remove('is-selected'));
      card.classList.add('is-selected');
      const nameEl = $('#wx-wizard-demo-name');
      if (nameEl) nameEl.textContent = card.querySelector('h3')?.textContent || selectedSkin;
      showStep('content');
    });
  });

  $('#wx-next-step')?.addEventListener('click', () => {
    if (currentStep === 'type') {
      if (!selectedType) { alert('Select setup type'); return; }
      if (selectedType === 'prebuilt') showStep('sites');
      else showStep('scratch-header');
    } else if (currentStep === 'sites') {
      if (!selectedSkin) { alert('Select a site'); return; }
      showStep('content');
    } else if (currentStep === 'content') {
      showStep('installation');
      const skinNameEl = $('#wx-install-skin-name');
      if (skinNameEl) skinNameEl.textContent = selectedSkin || 'Woodex Interior';
    } else if (currentStep.startsWith('scratch-')) {
      const order = ['scratch-header','scratch-footer','scratch-colors','scratch-fonts','scratch-plugins','installation'];
      const idx = order.indexOf(currentStep);
      if (idx >=0 && idx < order.length-1) showStep(order[idx+1]);
    }
  });

  $('#wx-start-install')?.addEventListener('click', () => {
    const bar = $('#wx-progress-bar');
    const log = $('#wx-install-log');
    if (!bar || !log) return;
    let progress = 0;
    const contentChecks = [...document.querySelectorAll('.wx-content-options input[type=checkbox]:checked')].map(cb => cb.value);
    log.innerHTML = 'Starting installation for '+ (selectedSkin||'woodex-interior') + '...<br>Content: '+contentChecks.join(', ');
    
    const interval = setInterval(() => {
      progress += 10;
      bar.style.width = progress + '%';
      if (progress >= 100) {
        clearInterval(interval);
        log.innerHTML += '<br><strong style="color:green;">✓ Installation complete! Go to site.</strong>';
        // AJAX import
        if (window.wxWizard) {
          fetch(wxWizard.ajax_url, {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:new URLSearchParams({action:'wx_wizard_import', skin:selectedSkin||'woodex-interior', content:contentChecks, nonce:wxWizard.nonce})
          }).then(r=>r.json()).then(res=>{ log.innerHTML += '<br>Server: '+JSON.stringify(res); });
        }
      }
    }, 300);
  });

  // Checkbox UI toggle (green checklist)
  document.querySelectorAll('.wx-content-options label').forEach(label => {
    label.addEventListener('click', (e) => {
      const cb = label.querySelector('input[type=checkbox]');
      const icon = label.querySelector('.wx-check');
      if (!cb || !icon) return;
      // Toggle after click (since hidden checkbox)
      setTimeout(() => {
        const checked = cb.checked;
        icon.style.background = checked ? '#27c93f' : 'rgba(255,255,255,0.2)';
        icon.textContent = checked ? '✓' : '';
      }, 10);
    });
  });
})();
