/**
 * WX Admin — Original
 */
jQuery(function($){
  'use strict';
  $(document).on('click', '.wx-apply-skin', function(){
    const skin = $(this).data('skin');
    if(!window.confirm('Apply skin '+skin+'?')) return;
    const $btn = $(this);
    $btn.prop('disabled', true).text('Applying...');
    $.post(ajaxurl, {
      action:'wx_apply_skin',
      skin:skin,
      nonce: (window.wxAdmin && wxAdmin.nonce) ? wxAdmin.nonce : ''
    }, function(res){
      const $log = $('#wx-skin-log');
      if($log.length) $log.show().html('<pre>'+JSON.stringify(res,null,2)+'</pre>');
      $btn.prop('disabled', false).text('Apply');
      if(res && res.success) window.location.reload();
    });
  });
});
