/**
 * WX Frontend — Original, no console.log in prod, strict
 * Ported motion from static js/app.js but rewritten original
 */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  const header = $('.wx-header');
  let lastY = 0;
  const onScroll = () => {
    const y = window.scrollY;
    if (!header) return;
    header.classList.toggle('scrolled', y > 40);
    const mobile = window.matchMedia('(max-width: 820px)').matches;
    const menuOpen = header.classList.contains('is-menu');
    if (!mobile && !menuOpen && y > 280 && y > lastY) header.classList.add('hidden');
    else header.classList.remove('hidden');
    lastY = y;
  };
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  const toggle = $('.wx-menu-toggle');
  const nav = $('.wx-nav');
  const setMenu = (open) => {
    toggle?.classList.toggle('is-open', open);
    header?.classList.toggle('is-menu', open);
    if (nav) nav.style.display = open ? 'flex' : '';
    document.body.style.overflow = open ? 'hidden' : '';
  };
  toggle?.addEventListener('click', () => setMenu(!header?.classList.contains('is-menu')));

  $$('[data-wx-anim]').forEach(el => {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          obs.unobserve(e.target);
        }
      });
    }, {threshold:0.06, rootMargin:'0px 0px -8% 0px'});
    obs.observe(el);
  });

  $$('[data-wx-tilt]').forEach(card => {
    const face = card.querySelector('[data-wx-tilt-face]') || card;
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      face.style.transform = `perspective(900px) rotateY(${x*8}deg) rotateX(${-y*8}deg)`;
    });
    card.addEventListener('mouseleave', () => { face.style.transform = ''; });
  });

  const lb = $('#wx-lightbox');
  if (lb) {
    const lbImg = lb.querySelector('img');
    const close = () => { lb.classList.remove('is-open'); lb.hidden = true; document.body.style.overflow=''; };
    $$('.wx-lb-src').forEach(img => {
      img.addEventListener('click', () => {
        lb.hidden = false;
        if (lbImg) {
          lbImg.src = img.currentSrc || img.src;
          lbImg.alt = img.alt || '';
        }
        requestAnimationFrame(() => lb.classList.add('is-open'));
        document.body.style.overflow='hidden';
      });
    });
    lb.querySelector('.wx-lb-x')?.addEventListener('click', close);
    lb.addEventListener('click', (e)=>{ if(e.target===lb) close(); });
  }

  const cine = $$('.wx-cine-slide');
  if (cine.length > 1 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    let ci=0;
    setInterval(()=>{ cine[ci].classList.remove('is-on'); ci=(ci+1)%cine.length; cine[ci].classList.add('is-on'); }, 7200);
  }

  $$('[data-wx-year]').forEach(el => { el.textContent = new Date().getFullYear().toString(); });

  const floatBtn = $('.wx-float-whatsapp');
  const chatCard = $('.wx-chat-card');
  floatBtn?.addEventListener('click', () => {
    chatCard?.classList.toggle('is-open');
    if (chatCard?.classList.contains('is-open') && !localStorage.getItem('wx-consent')) {
      const consent = chatCard.querySelector('.wx-consent');
      if (consent) consent.hidden = false;
    }
  });
  $('.wx-chat-close')?.addEventListener('click', () => chatCard?.classList.remove('is-open'));
})();
