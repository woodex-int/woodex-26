<?php
/**
 * WX Master Footer — Original
 *
 * @package wx-master
 */
defined('ABSPATH') || exit;
get_template_part('template-parts/footer/base');
wp_footer();
?>
</body>
</html>
