<?php
/**
 * WX Builder — Header/Footer/Mega Menu builder, original, multi-builder
 * Works with ALL modes: Elementor | WPBakery | Oxygen | Raw HTML+ACF
 * CPT wx_template + display rules + fallbacks
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_Builder {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_filter('walker_nav_menu_start_el', [$this, 'mega_menu_support'], 10, 4);
        add_action('wp_head', [$this, 'header_fallback_css']);
    }

    /**
     * Mega menu support — adds mega container for items with has-mega class
     */
    public function mega_menu_support(string $item_output, \WP_Post $item, int $depth, \stdClass $args): string {
        $classes = $item->classes ?? [];
        if (in_array('has-mega', (array) $classes, true) && 0 === $depth) {
            $group = sanitize_title($item->title);
            $template = WX_MASTER_DIR . '/template-parts/mega-menu/' . $group . '.php';
            if (file_exists($template)) {
                ob_start();
                include $template;
                $mega = ob_get_clean();
                $item_output .= '<div class="wx-mega"><div class="wx-mega-inner">' . $mega . '</div></div>';
            }
        }
        return $item_output;
    }

    public function header_fallback_css(): void {
        ?>
        <style id="wx-builder-fallback">
        .wx-mega{position:absolute;top:calc(100% + 18px);left:50%;transform:translateX(-50%) translateY(18px) scale(.97);width:min(980px,92vw);background:#fff;color:#12151c;border-radius:20px;padding:18px 20px 20px;box-shadow:0 24px 60px rgba(11,20,38,.16);opacity:0;visibility:hidden;pointer-events:none;transition:opacity .48s var(--wx-ease, ease),transform .52s var(--wx-ease, ease),visibility .48s;z-index:80}
        .has-mega:hover .wx-mega,.has-mega:focus-within .wx-mega{opacity:1;visibility:visible;pointer-events:auto;transform:translateX(-50%) translateY(0) scale(1)}
        .wx-mega-inner{display:grid;grid-template-columns:repeat(5,1fr);gap:24px}
        @media(max-width:820px){.wx-mega{position:static;transform:none;width:100%;box-shadow:none;border-radius:0}.wx-mega-inner{grid-template-columns:1fr}}
        </style>
        <?php
    }

    /**
     * Get header templates for wizard
     *
     * @return array
     */
    public static function get_header_templates(): array {
        $skins = WX_Skins::instance()->get_skins();
        $templates = [];
        foreach ($skins as $slug => $skin) {
            $file = WX_MASTER_SKINS_DIR . '/' . $slug . '/header-templates.php';
            if (file_exists($file)) {
                $data = include $file;
                if (is_array($data)) {
                    foreach ($data as $key => $val) {
                        $templates[$key] = $val;
                    }
                }
            }
        }
        // Default Woodex headers (original)
        $templates['wx-transparent-cine'] = [
            'title' => 'Woodex Transparent Cine',
            'type' => 'header',
            'preview' => WX_MASTER_SKINS_URI . '/woodex-interior/preview-header-transparent.jpg',
        ];
        $templates['wx-navy-solid'] = [
            'title' => 'Woodex Navy Solid',
            'type' => 'header',
            'preview' => WX_MASTER_SKINS_URI . '/woodex-interior/preview-header-navy.jpg',
        ];
        return $templates;
    }

    public static function get_footer_templates(): array {
        return [
            'wx-default' => ['title'=>'Woodex Default — Stay connected + giant INTERIORS','type'=>'footer'],
            'wx-minimal' => ['title'=>'Woodex Minimal','type'=>'footer'],
        ];
    }
}
