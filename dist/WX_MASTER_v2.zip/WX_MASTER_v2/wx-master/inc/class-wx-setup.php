<?php
/**
 * WX Setup — Original scaffold, no third-party core
 * Phase 0
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_Setup {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_action('init', [$this, 'register_menus']);
        add_filter('body_class', [$this, 'body_classes']);
    }
    public function register_menus(): void {
        // Menus already registered in functions.php, placeholder for future
    }
    /**
     * Add body classes for skin and light-page detection
     *
     * @param array $classes
     * @return array
     */
    public function body_classes(array $classes): array {
        $skin = get_option('wx_current_skin', 'woodex-interior');
        $classes[] = 'wx-skin-' . sanitize_html_class($skin);
        $classes[] = 'wx-master';
        if (is_page(['about','projects','contact','insights','locations','faq','careers'])) {
            $classes[] = 'light-page';
        }
        return $classes;
    }
}
