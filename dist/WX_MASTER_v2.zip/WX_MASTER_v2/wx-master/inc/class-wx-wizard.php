<?php
/**
 * WX Wizard — Setup Wizard Replica (Original UI, green-checklist)
 * Steps: Type → Sites → Installation (plus Header/Footer/Colors/Fonts/Plugins for From Scratch)
 * Original code, no Impreza copy, vanilla JS
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_Wizard {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_action('admin_menu', [$this, 'add_page'], 30);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('wp_ajax_wx_wizard_import', [$this, 'ajax_import']);
    }

    public function add_page(): void {
        add_theme_page(
            esc_html__('WX Setup Wizard', 'wx-master'),
            esc_html__('WX Setup Wizard', 'wx-master'),
            'manage_options',
            'wx-setup-wizard',
            [$this, 'render']
        );
    }

    public function enqueue(string $hook): void {
        if (str_contains($hook, 'wx-setup-wizard')) {
            wp_enqueue_style('wx-wizard', WX_MASTER_URI . '/assets/css/wx-wizard.css', [], WX_MASTER_VERSION);
            wp_enqueue_script('wx-wizard', WX_MASTER_URI . '/assets/js/wx-wizard.js', [], WX_MASTER_VERSION, true);
            wp_localize_script('wx-wizard', 'wxWizard', [
                'ajax_url' => esc_url(admin_url('admin-ajax.php')),
                'nonce' => wp_create_nonce('wx-wizard-nonce'),
                'i18n' => [
                    'next' => esc_html__('Next Step', 'wx-master'),
                    'install' => esc_html__('Start Installation', 'wx-master'),
                ],
            ]);
        }
    }

    public function render(): void {
        if (!current_user_can('manage_options')) return;
        $skins = WX_Skins::instance()->get_skins();
        $current_builder = (new WX_Builder_Router())->detect_builder();
        ?>
        <div class="wx-wizard-wrap">
            <div class="wx-wizard-header">
                <h1>WX Master Setup Wizard</h1>
                <p>Original replica — Type → Sites → Installation — green-checklist pattern</p>
            </div>

            <!-- Step 1: Setup Type -->
            <div class="wx-wizard-step is-active" data-step="type">
                <h2>Setup Type</h2>
                <div class="wx-setup-type-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
                    <div class="wx-type-card" data-type="prebuilt" style="border:2px solid #0c1628;border-radius:16px;padding:24px;cursor:pointer;background:#fff;">
                        <h3>Pre-Built Website</h3>
                        <p>Start with a ready-made website base. Import Woodex Interior or Interior Designer demo.</p>
                        <ul><li>Pages</li><li>Portfolio</li><li>Headers</li><li>Footers</li><li>Site Settings</li><li>Theme Options</li></ul>
                    </div>
                    <div class="wx-type-card" data-type="scratch" style="border:1px solid #ddd;border-radius:16px;padding:24px;cursor:pointer;background:#fff;">
                        <h3>Site from Scratch</h3>
                        <p>Choose Header, Footer, Colors, and Typography. Select</p>
                        <ul><li>Header</li><li>Footer</li><li>Colors</li><li>Fonts</li><li>Plugins</li></ul>
                    </div>
                </div>
            </div>

            <!-- Step 2: Sites (Prebuilt) -->
            <div class="wx-wizard-step" data-step="sites" hidden>
                <h2>Select Site</h2>
                <div class="wx-sites-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;">
                    <?php foreach ($skins as $slug => $skin): ?>
                    <div class="wx-site-card" data-skin="<?php echo esc_attr($slug); ?>" style="border:1px solid #ddd;border-radius:12px;overflow:hidden;cursor:pointer;background:#fff;">
                        <?php if (!empty($skin['preview_url'])): ?>
                        <img src="<?php echo esc_url($skin['preview_url']); ?>" alt="" style="width:100%;height:200px;object-fit:cover;">
                        <?php else: ?>
                        <div style="height:200px;background:#0c1628;display:grid;place-items:center;color:#f4efe7;"><?php echo esc_html($skin['name'] ?? $slug); ?></div>
                        <?php endif; ?>
                        <div style="padding:16px;">
                            <h3><?php echo esc_html($skin['name'] ?? $slug); ?></h3>
                            <p style="color:#6a6560;font-size:13px;"><?php echo esc_html($skin['description'] ?? ''); ?></p>
                            <small>Builder: <?php echo esc_html($skin['builder'] ?? 'raw'); ?></small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Step 3: Content (Prebuilt) — Green Checklist Replica -->
            <div class="wx-wizard-step" data-step="content" hidden>
                <div style="display:flex;gap:0;min-height:600px;border-radius:12px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,0.08);">
                    <!-- Left: Website Preview -->
                    <div style="flex:1.2;background:#fff;padding:20px;">
                        <div style="background:#f5f5f5;border-radius:12px;overflow:hidden;">
                            <div style="background:#e8e8e8;padding:8px 12px;display:flex;gap:6px;">
                                <span style="width:12px;height:12px;border-radius:50%;background:#ff5f56;display:inline-block;"></span>
                                <span style="width:12px;height:12px;border-radius:50%;background:#ffbd2e;display:inline-block;"></span>
                                <span style="width:12px;height:12px;border-radius:50%;background:#27c93f;display:inline-block;"></span>
                                <span style="flex:1;text-align:center;font-size:12px;color:#666;">Website Preview</span>
                            </div>
                            <div id="wx-wizard-preview" style="height:500px;display:grid;place-items:center;padding:40px;">
                                <div>
                                    <h2 style="font-size:2.5rem;font-weight:600;line-height:1.1;max-width:12ch;">Modern Elegant And Luxurious Interior</h2>
                                    <p style="color:#6a6560;max-width:36ch;">Individual approach to the design of private apartments and public areas</p>
                                    <button style="border:1px solid #121212;padding:8px 20px;margin-top:20px;background:#fff;">Portfolio</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Right: Content Selector Green Checklist -->
                    <div style="flex:0.8;background:#2c3e50;color:#fff;padding:32px;">
                        <h2 style="color:#fff;">Select Content of the "<span id="wx-wizard-demo-name" style="text-decoration:underline;">Interior Designer</span>" Pre-Built Website</h2>
                        <p style="color:rgba(255,255,255,.6);font-size:13px;">The images used in live demos will be replaced by placeholders due to copyright/license reasons.</p>
                        <div class="wx-content-options" style="display:flex;flex-direction:column;gap:12px;margin-top:20px;">
                            <label style="display:flex;align-items:center;gap:10px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;">✓</span><input type="checkbox" value="all" checked hidden> <strong>All content</strong></label>
                            <div style="margin-left:28px;display:flex;flex-direction:column;gap:10px;">
                                <label style="display:flex;align-items:center;gap:10px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;font-size:12px;">✓</span><input type="checkbox" value="pages" checked hidden> Pages</label>
                                <label style="display:flex;align-items:center;gap:10px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;font-size:12px;">✓</span><input type="checkbox" value="portfolio" checked hidden> Portfolio</label>
                                <label style="display:flex;align-items:center;gap:10px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;font-size:12px;">✓</span><input type="checkbox" value="headers" checked hidden> Headers</label>
                                <label style="display:flex;align-items:center;gap:10px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;font-size:12px;">✓</span><input type="checkbox" value="page_templates" checked hidden> Page Templates</label>
                                <label style="display:flex;align-items:center;gap:10px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;font-size:12px;">✓</span><input type="checkbox" value="reusable_blocks" checked hidden> Reusable Blocks</label>
                            </div>
                            <label style="display:flex;align-items:center;gap:10px;margin-top:8px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;font-size:12px;">✓</span><input type="checkbox" value="site_settings" checked hidden> Site Settings</label>
                            <label style="display:flex;align-items:center;gap:10px;"><span class="wx-check" style="width:20px;height:20px;background:#27c93f;border-radius:4px;display:grid;place-items:center;color:#fff;font-size:12px;">✓</span><input type="checkbox" value="theme_options" checked hidden> Theme Options</label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 4: From Scratch Steps -->
            <div class="wx-wizard-step" data-step="scratch-header" hidden>
                <h2>Choose Header</h2>
                <p>Select from header-templates — transparent-cine, navy-solid, etc.</p>
                <div class="wx-headers-grid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;">
                    <div class="wx-header-card" style="border:1px solid #ddd;border-radius:8px;padding:16px;">Transparent Cine</div>
                    <div class="wx-header-card" style="border:1px solid #ddd;border-radius:8px;padding:16px;">Navy Solid</div>
                    <div class="wx-header-card" style="border:1px solid #ddd;border-radius:8px;padding:16px;">Simple 1</div>
                </div>
            </div>

            <div class="wx-wizard-step" data-step="scratch-footer" hidden>
                <h2>Choose Footer</h2>
                <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:16px;">
                    <div style="border:1px solid #ddd;border-radius:8px;padding:16px;">Default — Stay connected + giant INTERIORS</div>
                    <div style="border:1px solid #ddd;border-radius:8px;padding:16px;">Minimal</div>
                </div>
            </div>

            <div class="wx-wizard-step" data-step="scratch-colors" hidden>
                <h2>Choose Colors</h2>
                <div style="display:flex;gap:12px;">
                    <div style="width:60px;height:60px;background:#0c1628;border-radius:50%;" title="Navy #0c1628"></div>
                    <div style="width:60px;height:60px;background:#f4efe7;border-radius:50%;" title="Cream #f4efe7"></div>
                    <div style="width:60px;height:60px;background:#b8956a;border-radius:50%;" title="Wood #b8956a"></div>
                </div>
            </div>

            <div class="wx-wizard-step" data-step="scratch-fonts" hidden>
                <h2>Choose Fonts</h2>
                <p>Plus Jakarta Sans 300-700 (Woodex), Inter, etc.</p>
            </div>

            <div class="wx-wizard-step" data-step="scratch-plugins" hidden>
                <h2>Choose Plugins</h2>
                <p>Free wp.org only — Elementor, ACF, CF7, Rank Math, WPForms Lite, OCDI. Paid as external links.</p>
                <p>Current builder detected: <strong><?php echo esc_html($current_builder); ?></strong></p>
            </div>

            <!-- Step Final: Installation -->
            <div class="wx-wizard-step" data-step="installation" hidden>
                <h2>Installation</h2>
                <div id="wx-install-progress" style="background:#f4efe7;padding:20px;border-radius:8px;">
                    <p>Ready to install <span id="wx-install-skin-name">Woodex Interior</span></p>
                    <div style="background:#ddd;height:8px;border-radius:4px;overflow:hidden;"><div id="wx-progress-bar" style="width:0%;height:100%;background:#0c1628;transition:width .4s;"></div></div>
                    <div id="wx-install-log" style="margin-top:16px;font-size:13px;color:#6a6560;"></div>
                </div>
                <button id="wx-start-install" class="button button-primary" style="margin-top:20px;background:#27c93f;border-color:#27c93f;border-radius:999px;padding:10px 28px;">Start Installation</button>
            </div>

            <!-- Nav -->
            <div class="wx-wizard-nav" style="background:#1a252f;padding:12px 24px;display:flex;justify-content:space-between;align-items:center;color:rgba(255,255,255,.6);margin-top:24px;border-radius:8px;">
                <div style="display:flex;gap:8px;align-items:center;">
                    <span data-nav="type" class="is-active">Setup Type</span><span>›</span><span data-nav="sites">Sites</span><span>›</span><span data-nav="content" style="color:#27c93f;">Content</span><span>›</span><span data-nav="installation">Installation</span>
                </div>
                <button id="wx-next-step" class="button button-primary" style="background:#27c93f;border-color:#27c93f;border-radius:999px;">Next Step</button>
            </div>
        </div>
        <?php
    }

    public function ajax_import(): void {
        check_ajax_referer('wx-wizard-nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Forbidden');

        $skin = sanitize_text_field($_POST['skin'] ?? '');
        $content = $_POST['content'] ?? [];

        if (empty($skin)) wp_send_json_error('No skin');

        // Simulate import — original logic
        update_option('wx_current_skin', $skin);
        update_option('wx_last_import', ['skin'=>$skin,'content'=>$content,'time'=>time()]);

        // If content.xml exists, import via OCDI or WP Import
        $skin_path = WX_MASTER_SKINS_DIR . '/' . $skin;
        $content_file = $skin_path . '/content.xml';
        if (file_exists($content_file)) {
            // Placeholder for real import — in Phase A we just record
        }

        wp_send_json_success(['message'=>'Imported '.$skin, 'skin'=>$skin, 'content'=>$content]);
    }
}
