<?php
/**
 * WX Tokens — Design tokens for Woodex and skins
 * Original, no third-party copy
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_Tokens {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_action('wp_head', [$this, 'output_css_vars'], 5);
    }

    /**
     * Get current skin tokens
     *
     * @return array
     */
    public function get_tokens(): array {
        $skin = get_option('wx_current_skin', 'woodex-interior');
        $preset_file = WX_MASTER_SKINS_DIR . '/' . $skin . '/preset.json';
        if (file_exists($preset_file)) {
            $json = json_decode((string) file_get_contents($preset_file), true);
            if (is_array($json) && isset($json['colors'])) {
                return $json;
            }
        }
        // Default Woodex tokens
        return [
            'colors' => [
                'navy' => '#0c1628',
                'navy2' => '#121e34',
                'card' => '#152033',
                'cream' => '#f4efe7',
                'ink' => '#12151c',
                'wood' => '#b8956a',
                'muted' => '#6a6560',
                'white' => '#ffffff',
            ],
            'fonts' => [
                'primary' => 'Plus Jakarta Sans',
                'weights' => [300,400,500,600,700],
            ],
            'radius' => [
                'large' => '24px',
                'medium' => '16px',
                'small' => '12px',
                'pill' => '999px',
            ],
            'ease' => 'cubic-bezier(0.22, 1, 0.36, 1)',
        ];
    }

    /**
     * Output CSS variables in head
     */
    public function output_css_vars(): void {
        $tokens = $this->get_tokens();
        $colors = $tokens['colors'] ?? [];
        $fonts = $tokens['fonts'] ?? [];
        ?>
        <style id="wx-tokens-vars">
        :root{
            --wx-navy: <?php echo esc_html($colors['navy'] ?? '#0c1628'); ?>;
            --wx-navy-2: <?php echo esc_html($colors['navy2'] ?? '#121e34'); ?>;
            --wx-card: <?php echo esc_html($colors['card'] ?? '#152033'); ?>;
            --wx-cream: <?php echo esc_html($colors['cream'] ?? '#f4efe7'); ?>;
            --wx-ink: <?php echo esc_html($colors['ink'] ?? '#12151c'); ?>;
            --wx-wood: <?php echo esc_html($colors['wood'] ?? '#b8956a'); ?>;
            --wx-muted: <?php echo esc_html($colors['muted'] ?? '#6a6560'); ?>;
            --wx-font: "<?php echo esc_html($fonts['primary'] ?? 'Plus Jakarta Sans'); ?>", sans-serif;
            --wx-ease: <?php echo esc_html($tokens['ease'] ?? 'cubic-bezier(0.22, 1, 0.36, 1)'); ?>;
        }
        </style>
        <?php
    }
}
