<?php
/**
 * WX MCP — REST namespace wx-agent/v1 (Phase B)
 * Original, no third-party copy, no paid bundles
 * Routes:
 * GET  /inspect-site/ — inventory: themes, plugins, templates, skins, headers/footers, blocks, CPTs, users count
 * GET  /skins/ · POST /apply-preset/ · POST /import-html-section/ · POST /convert-html/
 * Security: Application Password or AgentBridge token + caps + nonces, rate-limit, log to wx_agent_log CPT, never expose tokens
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_MCP {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'register_log_cpt']);
        add_action('rest_api_init', [$this, 'register_routes']);
        add_action('admin_menu', [$this, 'add_agent_page'], 20);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function register_log_cpt(): void {
        register_post_type('wx_agent_log', [
            'labels' => ['name'=>esc_html__('WX Agent Log','wx-master'),'singular_name'=>esc_html__('Log','wx-master')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'tools.php',
            'supports' => ['title','editor','custom-fields'],
            'capabilities' => ['create_posts'=>false],
            'map_meta_cap' => true,
        ]);
    }

    public function register_settings(): void {
        register_setting('wx_agent_settings', 'wx_agent_allow_non_https');
        register_setting('wx_agent_settings', 'wx_agent_rate_limit');
    }

    public function register_routes(): void {
        register_rest_route('wx-agent/v1', '/inspect-site/', [
            'methods' => 'GET',
            'callback' => [$this, 'inspect_site'],
            'permission_callback' => [$this, 'can_read'],
        ]);
        register_rest_route('wx-agent/v1', '/skins/', [
            'methods' => 'GET',
            'callback' => [$this, 'list_skins'],
            'permission_callback' => [$this, 'can_read'],
        ]);
        register_rest_route('wx-agent/v1', '/apply-preset/', [
            'methods' => 'POST',
            'callback' => [$this, 'apply_preset'],
            'permission_callback' => [$this, 'can_write'],
        ]);
        register_rest_route('wx-agent/v1', '/import-html-section/', [
            'methods' => 'POST',
            'callback' => [$this, 'import_html_section'],
            'permission_callback' => [$this, 'can_write'],
        ]);
        register_rest_route('wx-agent/v1', '/convert-html/', [
            'methods' => 'POST',
            'callback' => [$this, 'convert_html'],
            'permission_callback' => [$this, 'can_write'],
        ]);
        // Addon: list elements, render preview, apply skin as MCP tools
        register_rest_route('wx-agent/v1', '/elements/', [
            'methods' => 'GET',
            'callback' => [$this, 'list_elements'],
            'permission_callback' => [$this, 'can_read'],
        ]);
        register_rest_route('wx-agent/v1', '/render-preview/', [
            'methods' => 'POST',
            'callback' => [$this, 'render_preview'],
            'permission_callback' => [$this, 'can_write'],
        ]);
    }

    /**
     * Permission: read — logged in or Application Password
     */
    public function can_read(): bool {
        if (is_user_logged_in() && current_user_can('read')) return true;
        // Application Password will set current user via Basic Auth
        if ($this->is_app_password_request()) return is_user_logged_in();
        return false;
    }

    /**
     * Permission: write — Application Password or AgentBridge token + caps + nonce check
     */
    public function can_write(\WP_REST_Request $request): bool {
        // Rate limit check first
        if (!$this->check_rate_limit()) return false;

        // Nonce check for browser requests (if _wpnonce present)
        $nonce = $request->get_header('X-WP-Nonce') ?? $request->get_param('_wpnonce') ?? '';
        if (!empty($nonce)) {
            if (!wp_verify_nonce($nonce, 'wp_rest')) return false;
        }

        // Capability check
        if (!current_user_can('manage_options') && !current_user_can('edit_posts')) {
            // Check Application Password or AgentBridge token
            if (!$this->is_app_password_request() && !$this->is_agentbridge_token($request)) {
                return false;
            }
            // If token valid, still need manage_options for write
            if (!current_user_can('manage_options')) return false;
        }

        return true;
    }

    private function is_app_password_request(): bool {
        // WordPress sets current user via Basic Auth with Application Passwords
        return is_user_logged_in() && !empty($_SERVER['PHP_AUTH_USER']);
    }

    private function is_agentbridge_token(\WP_REST_Request $request): bool {
        // Check for AgentBridge token header: Authorization: Basic <token> or X-WX-Agent-Token
        $auth = $request->get_header('Authorization') ?? '';
        $custom = $request->get_header('X-WX-Agent-Token') ?? $request->get_param('agent_token') ?? '';
        if (!empty($custom)) {
            $stored = get_option('wx_agent_token', '');
            if (!empty($stored) && hash_equals($stored, $custom)) return true;
        }
        // If Authorization header present and user is admin, allow (Application Password flow)
        if (!empty($auth) && current_user_can('manage_options')) return true;
        return false;
    }

    /**
     * Rate limit: 10 writes per minute per IP
     */
    private function check_rate_limit(): bool {
        $limit = (int) get_option('wx_agent_rate_limit', 10);
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $key = 'wx_rate_' . md5($ip);
        $data = get_transient($key);
        if (false === $data) {
            $data = ['count'=>1,'time'=>time()];
            set_transient($key, $data, 60);
            return true;
        }
        if (time() - $data['time'] > 60) {
            $data = ['count'=>1,'time'=>time()];
            set_transient($key, $data, 60);
            return true;
        }
        if ($data['count'] >= $limit) return false;
        $data['count']++;
        set_transient($key, $data, 60);
        return true;
    }

    /**
     * Log MCP mutations to wx_agent_log CPT (actor, action, payload hash), never expose tokens
     */
    private function log_mutation(string $action, array $payload, int $actor_id = 0): void {
        if (0 === $actor_id) $actor_id = get_current_user_id();
        $actor = get_userdata($actor_id);
        $actor_name = $actor ? $actor->user_login : 'unknown';

        // Hash payload, remove tokens
        $clean_payload = $payload;
        unset($clean_payload['token'], $clean_payload['agent_token'], $clean_payload['Authorization'], $clean_payload['password']);
        $hash = hash('sha256', wp_json_encode($clean_payload));

        wp_insert_post([
            'post_type' => 'wx_agent_log',
            'post_title' => sprintf('%s by %s at %s', $action, $actor_name, gmdate('Y-m-d H:i:s')),
            'post_content' => wp_json_encode(['action'=>$action,'actor'=>$actor_name,'actor_id'=>$actor_id,'hash'=>$hash,'payload_keys'=>array_keys($clean_payload)], JSON_PRETTY_PRINT),
            'post_status' => 'publish',
            'meta_input' => [
                '_wx_action' => $action,
                '_wx_actor' => $actor_name,
                '_wx_hash' => $hash,
            ],
        ]);
    }

    public function inspect_site(): \WP_REST_Response {
        $themes = wp_get_themes();
        $theme_list = [];
        foreach ($themes as $slug => $theme) {
            $theme_list[] = ['slug'=>$slug,'name'=>$theme->get('Name'),'version'=>$theme->get('Version')];
        }

        $plugins = get_plugins();
        $active = get_option('active_plugins', []);
        $plugin_list = [];
        foreach ($plugins as $file => $data) {
            $plugin_list[] = ['file'=>$file,'name'=>$data['Name'],'version'=>$data['Version'],'active'=>in_array($file,$active,true)];
        }

        $templates = get_posts(['post_type'=>'wx_template','posts_per_page'=>-1,'post_status'=>'publish']);
        $headers = [];
        $footers = [];
        $blocks = [];
        foreach ($templates as $t) {
            $terms = wp_get_post_terms($t->ID, 'wx_template_type', ['fields'=>'slugs']);
            $type = $terms[0] ?? 'unknown';
            $item = ['ID'=>$t->ID,'title'=>$t->post_title,'slug'=>$t->post_name,'type'=>$type,'edit_url'=>admin_url('post.php?post='.$t->ID.'&action=edit')];
            if ('header' === $type) $headers[] = $item;
            elseif ('footer' === $type) $footers[] = $item;
            else $blocks[] = $item;
        }

        $skins = WX_Skins::instance()->get_skins();
        $cpts = get_post_types(['public'=>true], 'objects');
        $cpt_list = [];
        foreach ($cpts as $cpt) {
            $cpt_list[] = ['name'=>$cpt->name,'label'=>$cpt->label,'count'=>wp_count_posts($cpt->name)->publish ?? 0];
        }

        $users_count = count_users();

        // Never expose tokens
        $response = [
            'site' => ['name'=>get_bloginfo('name'),'url'=>home_url(),'wp_version'=>get_bloginfo('version'),'theme'=>wp_get_theme()->get('Name'),'builder'=>(new WX_Builder_Router())->detect_builder()],
            'themes' => $theme_list,
            'plugins' => $plugin_list,
            'templates' => ['headers'=>$headers,'footers'=>$footers,'blocks'=>$blocks],
            'skins' => array_map(function($s){ unset($s['path']); return $s; }, $skins), // Remove path to avoid exposing server paths, tokens never exposed
            'cpts' => $cpt_list,
            'users' => ['total'=>$users_count['total_users'] ?? 0,'roles'=>$users_count['avail_roles'] ?? []],
        ];

        return rest_ensure_response($response);
    }

    public function list_skins(): \WP_REST_Response {
        $skins = WX_Skins::instance()->get_skins();
        $clean = array_map(function($s){ unset($s['path']); return $s; }, $skins);
        return rest_ensure_response($clean);
    }

    public function apply_preset(\WP_REST_Request $request): \WP_REST_Response {
        $slug = sanitize_text_field($request->get_param('skin') ?? $request->get_param('preset') ?? '');
        $payload = ['skin'=>$slug];
        $this->log_mutation('apply-preset', $payload);

        if (empty($slug)) return rest_ensure_response(new \WP_Error('no_skin','No skin provided',['status'=>400]));

        $skins = WX_Skins::instance()->get_skins();
        if (!isset($skins[$slug])) return rest_ensure_response(new \WP_Error('not_found','Skin not found',['status'=>404]));

        update_option('wx_current_skin', $slug);
        update_option('wx_current_preset', $skins[$slug]);

        return rest_ensure_response(['success'=>true,'skin'=>$slug,'message'=>'Preset applied: '.$slug]);
    }

    public function import_html_section(\WP_REST_Request $request): \WP_REST_Response {
        $html = $request->get_param('html') ?? '';
        $title = sanitize_text_field($request->get_param('title') ?? 'Imported Section '.gmdate('Y-m-d H:i'));
        $type = sanitize_text_field($request->get_param('type') ?? 'page-block');

        $this->log_mutation('import-html-section', ['title'=>$title,'type'=>$type,'html_length'=>strlen($html)]);

        if (empty($html)) return rest_ensure_response(new \WP_Error('no_html','No HTML provided',['status'=>400]));

        $id = wp_insert_post([
            'post_type' => 'wx_template',
            'post_title' => $title,
            'post_content' => wp_kses_post($html),
            'post_status' => 'publish',
            'tax_input' => ['wx_template_type'=>[$type]],
        ]);

        if (is_wp_error($id)) return rest_ensure_response($id);

        return rest_ensure_response([
            'success'=>true,
            'post_id'=>$id,
            'edit_url'=>admin_url('post.php?post='.$id.'&action=edit'),
            'shortcode'=>'[wx_template id="'.$id.'"]',
        ]);
    }

    public function convert_html(\WP_REST_Request $request): \WP_REST_Response {
        $html = $request->get_param('html') ?? '';
        $target = sanitize_text_field($request->get_param('target') ?? 'elementor');

        $this->log_mutation('convert-html', ['target'=>$target,'html_length'=>strlen($html)]);

        if (empty($html)) return rest_ensure_response(new \WP_Error('no_html','No HTML provided',['status'=>400]));

        // Simplified original converter — real logic in Python script
        $result = [];
        if ('elementor' === $target || 'both' === $target) {
            $result['elementor'] = [
                'version'=>'0.4',
                'title'=>'Converted Section',
                'type'=>'section',
                'content'=>[['id'=>'a1','elType'=>'widget','widgetType'=>'html','settings'=>['html'=>$html]]],
            ];
        }
        if ('oxygen' === $target || 'both' === $target) {
            $result['oxygen'] = ['type'=>'oxy_section','content'=>$html];
        }
        if ('raw' === $target || 'both' === $target) {
            $result['acf'] = ['layout'=>'custom_html','html'=>$html];
        }
        $result['html'] = $html;
        $result['target'] = $target;

        return rest_ensure_response($result);
    }

    public function list_elements(): \WP_REST_Response {
        $elements = [
            ['slug'=>'hero-slider','name'=>'Hero Slider','builder'=>['elementor','oxygen','raw'],'mcp_tool'=>'list_hero_slides'],
            ['slug'=>'cine','name'=>'Cine Hero','builder'=>['elementor','oxygen','raw'],'mcp_tool'=>'render_cine_preview'],
            ['slug'=>'brief-form','name'=>'Brief Form','builder'=>['elementor','raw'],'mcp_tool'=>'render_brief_form'],
            ['slug'=>'ticker','name'=>'Ticker','builder'=>['elementor','raw'],'mcp_tool'=>'list_ticker_items'],
            ['slug'=>'gates','name'=>'Process Gates','builder'=>['elementor','raw'],'mcp_tool'=>'list_gates'],
            ['slug'=>'tilt-card','name'=>'Tilt Card','builder'=>['elementor'],'mcp_tool'=>'render_tilt_preview'],
            ['slug'=>'lightbox','name'=>'Lightbox','builder'=>['elementor'],'mcp_tool'=>'render_lightbox'],
        ];
        return rest_ensure_response($elements);
    }

    public function render_preview(\WP_REST_Request $request): \WP_REST_Response {
        $element = sanitize_text_field($request->get_param('element') ?? '');
        $settings = $request->get_param('settings') ?? [];

        $this->log_mutation('render-preview', ['element'=>$element]);

        $html = '<div class="wx-'.$element.'">Preview for '.$element.' — '.wp_json_encode($settings).'</div>';
        return rest_ensure_response(['html'=>$html,'element'=>$element]);
    }

    public function add_agent_page(): void {
        add_menu_page(
            esc_html__('WX Agent', 'wx-master'),
            esc_html__('WX Agent', 'wx-master'),
            'manage_options',
            'wx-agent-connect',
            [$this, 'render_agent_page'],
            'dashicons-rest-api',
            30
        );
        add_submenu_page(
            'wx-agent-connect',
            esc_html__('Agent Connect', 'wx-master'),
            esc_html__('Agent Connect', 'wx-master'),
            'manage_options',
            'wx-agent-connect',
            [$this, 'render_agent_page']
        );
    }

    public function render_agent_page(): void {
        if (!current_user_can('manage_options')) return;

        $site = home_url();
        $rest = $site . '/wp-json/wx-agent/v1/';
        $agentbridge_rest = $site . '/wp-json/agentbridge/v1/mcp';
        $emcp_rest = $site . '/wp-json/emcp/v1/mcp';

        // Generate or get token
        $token = get_option('wx_agent_token', '');
        if (empty($token)) {
            $token = wp_generate_password(32, false);
            update_option('wx_agent_token', $token);
        }

        $allow_non_https = get_option('wx_agent_allow_non_https', false);
        $rate_limit = get_option('wx_agent_rate_limit', 10);

        // Check if AgentBridge active
        $agentbridge_active = is_plugin_active('agentbridge/agentbridge.php') || class_exists('AgentBridge');
        $emcp_active = is_plugin_active('emcp-tools/emcp-tools.php') || is_plugin_active('elementor-mcp/elementor-mcp.php') || class_exists('EMCP_Tools');
        ?>
        <div class="wrap wx-agent-connect">
            <h1><?php esc_html_e('WX → Agent Connect — Connect ALL CLIs', 'wx-master'); ?></h1>
            <p>Endpoints: <code><?php echo esc_url($rest); ?></code> — inspect-site, skins, apply-preset, import-html-section, convert-html, elements, render-preview</p>

            <h2>Settings</h2>
            <form method="post" action="options.php">
                <?php settings_fields('wx_agent_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th>Allow on non-HTTPS (local)</th>
                        <td>
                            <label><input type="checkbox" name="wx_agent_allow_non_https" value="1" <?php checked($allow_non_https, true); ?>> Enable for woodex.local testing (plain HTTP)</label>
                            <p class="description">If enabled, Application Passwords allowed on HTTP for local dev. Disable on live.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Rate Limit (writes per minute per IP)</th>
                        <td><input type="number" name="wx_agent_rate_limit" value="<?php echo esc_attr($rate_limit); ?>" min="1" max="100"> <p class="description">Rate-limit REST writes, prevents abuse</p></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <h2>Status</h2>
            <ul>
                <li>AgentBridge (24 tools): <?php echo $agentbridge_active ? '<span style="color:green;">✓ Active</span>' : '<span style="color:red;">✗ Not active — install via WX Plugins or TGMPA</span>'; ?> — <code>/wp-json/agentbridge/v1/mcp</code></li>
                <li>EMCP Tools (200+ tools): <?php echo $emcp_active ? '<span style="color:green;">✓ Active</span>' : '<span style="color:red;">✗ Not active — install via TGMPA</span>'; ?> — <code>/wp-json/emcp/v1/mcp</code></li>
                <li>WX Agent (custom): <span style="color:green;">✓ Active</span> — <code>/wp-json/wx-agent/v1/</code></li>
                <li>Current builder detected: <strong><?php echo esc_html((new WX_Builder_Router())->detect_builder()); ?></strong></li>
            </ul>

            <h2>Claude Code</h2>
            <p>One admin page shows per-CLI commands pre-filled with token (token never exposed in REST responses, only here in admin).</p>
            <pre style="background:#1a252f;color:#fff;padding:16px;border-radius:8px;overflow:auto;"># WX Agent (custom)
claude mcp add --transport http wx-agent <?php echo esc_url($rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"

# AgentBridge (24 tools)
claude mcp add --transport http agentbridge <?php echo esc_url($agentbridge_rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"

# EMCP Tools (200+ tools)
claude mcp add --transport http emcp-tools <?php echo esc_url($emcp_rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"

# Test
curl -u "admin:<?php echo esc_attr($token); ?>" <?php echo esc_url($rest); ?>inspect-site/
</pre>

            <h2>Claude Desktop (downloadable claude_desktop_config.json — stdio bridge via mcp-remote)</h2>
            <p>For CLIs lacking HTTP transport, use mcp-remote bridge (npm package https://www.npmjs.com/package/mcp-remote)</p>
            <pre style="background:#1a252f;color:#fff;padding:16px;border-radius:8px;overflow:auto;">{
  "mcpServers": {
    "wx-agent": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "<?php echo esc_url($rest); ?>", "--header", "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"]
    },
    "agentbridge": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "<?php echo esc_url($agentbridge_rest); ?>", "--header", "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"]
    },
    "emcp-tools": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "<?php echo esc_url($emcp_rest); ?>", "--header", "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"]
    }
  }
}</pre>
            <p><a href="<?php echo esc_url(admin_url('admin-ajax.php?action=wx_download_claude_config&nonce='.wp_create_nonce('wx-admin-nonce'))); ?>" class="button">⬇ Download claude_desktop_config.json (pre-filled)</a></p>

            <h2>Hermes</h2>
            <pre style="background:#1a252f;color:#fff;padding:16px;border-radius:8px;"># Hermes uses same HTTP transport
hermes mcp add wx-agent --url <?php echo esc_url($rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"
</pre>

            <h2>Gemini CLI</h2>
            <pre style="background:#1a252f;color:#fff;padding:16px;border-radius:8px;"># Gemini CLI config (~/.gemini/settings.json)
{
  "mcpServers": {
    "wx-agent": {
      "httpUrl": "<?php echo esc_url($rest); ?>",
      "headers": {"Authorization": "Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"}
    }
  }
}</pre>

            <h2>Cursor</h2>
            <pre style="background:#1a252f;color:#fff;padding:16px;border-radius:8px;"># Cursor config (~/.cursor/mcp.json)
{
  "mcpServers": {
    "wx-agent": {
      "url": "<?php echo esc_url($rest); ?>",
      "headers": {"Authorization": "Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"}
    }
  }
}</pre>

            <h2>Cline</h2>
            <pre style="background:#1a252f;color:#fff;padding:16px;border-radius:8px;"># Cline MCP settings
{
  "mcpServers": {
    "wx-agent": {
      "url": "<?php echo esc_url($rest); ?>",
      "headers": {"Authorization": "Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"}
    }
  }
}</pre>

            <h2>Codex</h2>
            <pre style="background:#1a252f;color:#fff;padding:16px;border-radius:8px;"># Codex uses stdio bridge via mcp-remote
codex mcp add wx-agent -- npx -y mcp-remote <?php echo esc_url($rest); ?> --header "Authorization: Basic <?php echo esc_html(base64_encode('admin:'.$token)); ?>"
</pre>

            <h2>Security</h2>
            <ul>
                <li>Rate-limit REST writes: <?php echo esc_html($rate_limit); ?>/min per IP — prevents abuse</li>
                <li>Log all MCP mutations to CPT <code>wx_agent_log</code> (actor, action, payload hash) — never expose tokens in REST responses</li>
                <li>Tokens pre-filled only here in admin (capability manage_options), never in REST</li>
                <li>Allow on non-HTTPS toggle for woodex.local: <?php echo $allow_non_https ? 'Enabled' : 'Disabled'; ?></li>
            </ul>

            <h2>Test via curl</h2>
            <pre>curl -u "admin:<?php echo esc_attr($token); ?>" <?php echo esc_url($rest); ?>inspect-site/ | jq
curl -u "admin:wrong" <?php echo esc_url($rest); ?>inspect-site/ # should 401/403
</pre>
        </div>
        <?php
    }
}
