<?php
/**
 * WX Plugins — Universal plugin layer (wx-plugins.json)
 * Declarative catalogue: {slug, source: wp.org|import|scaffold, brand_default, config}
 * TGMPA lists free wp.org only; paid as optional external links
 * Original, no WPBakery/FileBird Pro bundled
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_Plugins {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_action('admin_menu', [$this, 'add_plugins_page']);
        add_action('wp_ajax_wx_install_plugin', [$this, 'ajax_install_plugin']);
        add_action('tgmpa_register', [$this, 'tgmpa_register']);
    }

    /**
     * Load catalogue
     *
     * @return array
     */
    public function get_catalogue(): array {
        $file = WX_MASTER_DIR . '/wx-plugins.json';
        if (file_exists($file)) {
            $data = json_decode((string) file_get_contents($file), true);
            if (is_array($data)) {
                // Ensure AgentBridge + EMCP are first (Phase B)
                $priority = [
                    ['slug'=>'agentbridge','source'=>'import','brand_default'=>true,'config'=>['path'=>'inc/plugins/agentbridge.zip','tools'=>24,'note'=>'Woodex-owned MCP bridge']],
                    ['slug'=>'emcp-tools','source'=>'import','brand_default'=>true,'config'=>['path'=>'inc/plugins/elementor-mcp.zip','tools'=>200,'license'=>'GPL-2.0','url'=>'https://github.com/msrbuilds/elementor-mcp']],
                ];
                // Merge priority first, then rest, deduplicate by slug
                $existing_slugs = array_column($data, 'slug');
                $merged = $priority;
                foreach ($data as $item) {
                    if (!in_array($item['slug'] ?? '', array_column($priority,'slug'), true)) {
                        $merged[] = $item;
                    }
                }
                return $merged;
            }
        }
        // Default catalogue — free wp.org only + AgentBridge + EMCP first
        return [
            ['slug'=>'agentbridge','source'=>'import','brand_default'=>true,'config'=>['path'=>'inc/plugins/agentbridge.zip','tools'=>24]],
            ['slug'=>'emcp-tools','source'=>'import','brand_default'=>true,'config'=>['path'=>'inc/plugins/elementor-mcp.zip','tools'=>200,'license'=>'GPL-2.0']],
            ['slug'=>'elementor','source'=>'wp.org','brand_default'=>true,'config'=>[]],
            ['slug'=>'header-footer-elementor','source'=>'wp.org','brand_default'=>true,'config'=>[]],
            ['slug'=>'essential-addons-for-elementor-lite','source'=>'wp.org','brand_default'=>false,'config'=>[]],
            ['slug'=>'advanced-custom-fields','source'=>'wp.org','brand_default'=>true,'config'=>[]],
            ['slug'=>'contact-form-7','source'=>'wp.org','brand_default'=>true,'config'=>[]],
            ['slug'=>'wpforms-lite','source'=>'wp.org','brand_default'=>false,'config'=>[]],
            ['slug'=>'seo-by-rank-math','source'=>'wp.org','brand_default'=>true,'config'=>[]],
            ['slug'=>'xpro-elementor-addons','source'=>'wp.org','brand_default'=>false,'config'=>[]],
        ];
    }

    public function add_plugins_page(): void {
        add_submenu_page(
            'themes.php',
            esc_html__('WX Plugins', 'wx-master'),
            esc_html__('WX Plugins', 'wx-master'),
            'manage_options',
            'wx-plugins',
            [$this, 'render_page']
        );
    }

    public function render_page(): void {
        if (!current_user_can('manage_options')) return;
        $catalogue = $this->get_catalogue();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('WX Plugins — Universal Layer', 'wx-master'); ?></h1>
            <p><?php esc_html_e('Free wp.org plugins only. Paid plugins appear as external links. Users can add any free plugin by slug — no core edit.', 'wx-master'); ?></p>
            <table class="widefat">
                <thead><tr><th>Slug</th><th>Source</th><th>Default</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <?php foreach ($catalogue as $item): 
                    $slug = sanitize_text_field($item['slug'] ?? '');
                    $source = sanitize_text_field($item['source'] ?? 'wp.org');
                    $is_active = is_plugin_active($slug . '/' . $slug . '.php') || is_plugin_active($slug . '.php');
                    $is_installed = file_exists(WP_PLUGIN_DIR . '/' . $slug);
                ?>
                    <tr>
                        <td><?php echo esc_html($slug); ?></td>
                        <td><?php echo esc_html($source); ?></td>
                        <td><?php echo !empty($item['brand_default']) ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $is_active ? 'Active' : ($is_installed ? 'Installed' : 'Not installed'); ?></td>
                        <td>
                            <?php if (!$is_active): ?>
                            <button class="button wx-install-plugin" data-slug="<?php echo esc_attr($slug); ?>"><?php esc_html_e('Install', 'wx-master'); ?></button>
                            <?php else: ?>
                            <span style="color:green;">✓</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <h2>Paid Optional (External Links Only)</h2>
            <ul>
                <li>WPBakery Page Builder (WPBakery) — <a href="https://wpbakery.com/" target="_blank">wpbakery.com</a> — registration only, never bundled</li>
                <li>FileBird Pro — <a href="https://filebird.io/" target="_blank">filebird.io</a></li>
                <li>Impreza Theme (reference only) — <a href="https://themeforest.net/item/impreza-retina-responsive-wordpress-theme/6434280" target="_blank">ThemeForest</a></li>
            </ul>
        </div>
        <?php
    }

    public function ajax_install_plugin(): void {
        check_ajax_referer('wx-admin-nonce', 'nonce');
        if (!current_user_can('install_plugins')) wp_send_json_error('Forbidden');

        $slug = sanitize_text_field($_POST['slug'] ?? '');
        if (empty($slug)) wp_send_json_error('No slug');

        // Validate slug is in catalogue (security)
        $catalogue = $this->get_catalogue();
        $allowed = array_column($catalogue, 'slug');
        if (!in_array($slug, $allowed, true)) wp_send_json_error('Slug not allowed');

        // Use WP API to install from wp.org
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/plugin-install.php';

        $api = plugins_api('plugin_information', ['slug'=>$slug,'fields'=>['sections'=>false]]);
        if (is_wp_error($api)) wp_send_json_error($api->get_error_message());

        $upgrader = new Plugin_Upgrader(new WP_Ajax_Upgrader_Skin());
        $result = $upgrader->install($api->download_link);

        if (is_wp_error($result)) wp_send_json_error($result->get_error_message());

        // Activate
        $activate = activate_plugin(WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php');
        if (is_wp_error($activate)) {
            // Try alternative main file
            $activate = activate_plugin($slug . '/' . $slug . '.php');
        }

        wp_send_json_success('Installed and activated: ' . $slug);
    }

    public function tgmpa_register(): void {
        if (!function_exists('tgmpa')) return;

        $catalogue = $this->get_catalogue();
        $plugins = [];

        // Phase B: Bundle AgentBridge + EMCP inside theme inc/plugins/; TGMPA offers them first
        foreach ($catalogue as $item) {
            $slug = $item['slug'] ?? '';
            $source = $item['source'] ?? 'wp.org';
            if ('import' === $source) {
                // Bundled zips (owned or GPL)
                $path = WX_MASTER_DIR . '/' . ($item['config']['path'] ?? 'inc/plugins/'.$slug.'.zip');
                if (file_exists($path)) {
                    $plugins[] = [
                        'name' => $slug . ' (' . ($item['config']['tools'] ?? 0) . ' tools)',
                        'slug' => $slug,
                        'source' => $path,
                        'required' => !empty($item['brand_default']),
                        'version' => $item['config']['version'] ?? '',
                    ];
                }
            } elseif ('wp.org' === $source) {
                $plugins[] = [
                    'name' => $slug,
                    'slug' => $slug,
                    'required' => !empty($item['brand_default']),
                ];
            }
        }

        $config = [
            'id' => 'wx-master',
            'menu' => 'tgmpa-install-plugins',
            'parent_slug' => 'themes.php',
            'capability' => 'edit_theme_options',
            'has_notices' => true,
            'dismissable' => true,
            'is_automatic' => false,
            'message' => esc_html__('WX Master Phase B: AgentBridge (24 tools) + EMCP (200+ tools) bundled first, then free wp.org plugins. Paid plugins optional external links only.', 'wx-master'),
        ];

        tgmpa($plugins, $config);
    }
}
