<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
if (!class_exists('WX_cine_Widget')) {
class WX_cine_Widget extends \Elementor\Widget_Base {
    public function get_name(): string { return 'wx-cine'; }
    public function get_title(): string { return esc_html__('WX cine','wx-master'); }
    public function get_icon(): string { return 'eicon-slider-album'; }
    public function get_categories(): array { return ['wx-master']; }
    protected function register_controls(): void {
        $this->start_controls_section('content',['label'=>esc_html__('Content','wx-master')]);
        $this->add_control('title',['label'=>esc_html__('Title','wx-master'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Woodex Interior']);
        $this->end_controls_section();
    }
    protected function render(): void {
        $settings = $this->get_settings_for_display();
        echo '<div class="wx-cine"><h3>'.esc_html($settings['title']??'WX cine').'</h3><p>Original Elementor widget — Woodex tokens: navy #0c1628, wood #b8956a</p></div>';
    }
}
}
