<?php
/**
 * WX Builder Router — Multi-builder detection & registration
 * Detects: Elementor | WPBakery | Oxygen | Raw HTML+ACF
 * Registers SAME wx elements via each builder's native API
 * Original code, no third-party copy, no paid bundles
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_Builder_Router {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'detect_and_register'], 20);
    }

    /**
     * Detect active builder
     *
     * @return string elementor|wpbakery|oxygen|raw
     */
    public function detect_builder(): string {
        if (defined('ELEMENTOR_VERSION') || class_exists('\Elementor\Plugin')) return 'elementor';
        if (defined('CT_VERSION') || function_exists('oxygen_vsb_init') || class_exists('OxygenElement')) return 'oxygen';
        if (class_exists('ACF') || function_exists('get_field')) return 'raw';
        if (defined('WPB_VC_VERSION') || class_exists('Vc_Manager') || function_exists('vc_map')) return 'wpbakery';
        return 'raw';
    }

    public function detect_and_register(): void {
        $builder = $this->detect_builder();
        // Store for frontend
        update_option('wx_current_builder', $builder, false);

        switch ($builder) {
            case 'elementor':
                $this->register_elementor();
                break;
            case 'oxygen':
                $this->register_oxygen();
                break;
            case 'wpbakery':
                $this->register_wpbakery();
                break;
            case 'raw':
            default:
                $this->register_raw_acf();
                break;
        }
    }

    /**
     * Elementor: custom widgets via standard API
     */
    private function register_elementor(): void {
        add_action('elementor/widgets/register', function($manager) {
            $widgets = ['hero-slider','cine','brief-form','ticker','gates','tilt-card','lightbox'];
            foreach ($widgets as $w) {
                $file = WX_MASTER_DIR . '/inc/elementor/class-wx-' . $w . '.php';
                if (file_exists($file)) {
                    require_once $file;
                    $class = 'WX_' . str_replace('-','_', ucwords($w,'-')) . '_Widget';
                    if (class_exists($class)) $manager->register(new $class());
                }
            }
        });
        add_action('elementor/elements/categories_registered', function($elements_manager) {
            $elements_manager->add_category('wx-master', ['title'=>esc_html__('WX Master','wx-master'),'icon'=>'eicon-font']);
        });
    }

    /**
     * WPBakery: vc_map equivalents — registration only, we do NOT ship their plugin
     */
    private function register_wpbakery(): void {
        if (!function_exists('vc_map')) return;
        $elements = [
            'wx_hero_slider' => ['name'=>'WX Hero Slider','params'=>[['type'=>'textfield','heading'=>'Slides','param_name'=>'slides']]],
            'wx_cine' => ['name'=>'WX Cine Hero','params'=>[['type'=>'textfield','heading'=>'Title','param_name'=>'title']]],
            'wx_brief_form' => ['name'=>'WX Brief Form','params'=>[]],
            'wx_ticker' => ['name'=>'WX Ticker','params'=>[]],
            'wx_gates' => ['name'=>'WX Process Gates','params'=>[]],
        ];
        foreach ($elements as $base => $cfg) {
            vc_map([
                'name' => $cfg['name'],
                'base' => $base,
                'category' => 'WX Master',
                'params' => $cfg['params'],
            ]);
        }
    }

    /**
     * Oxygen: adapter bundling wp-oxygen-elements (Posts Filter, Gallery Filter) + our elements
     * GPL-3.0 attribution included
     */
    private function register_oxygen(): void {
        add_action('plugins_loaded', function() {
            if (!class_exists('OxygenElement')) return;
            // Our custom Oxygen elements
            foreach (glob(WX_MASTER_DIR . '/inc/oxygen/*.php') as $file) {
                include_once $file;
            }
            // wp-oxygen-elements GPL-3.0 — Posts Filter, Gallery Filter
            $oxygen_elements = WX_MASTER_DIR . '/assets/bundled-plugins/wp-oxygen-elements';
            if (is_dir($oxygen_elements)) {
                foreach (glob($oxygen_elements . '/elements/*/*.php') as $file) {
                    include_once $file;
                }
            }
        });
    }

    /**
     * Raw+ACF: ACF flexible-content layouts + repeaters render components server-side
     * Users can drop custom HTML/CSS/JS blocks anywhere for full control and speed
     */
    private function register_raw_acf(): void {
        if (!function_exists('acf_register_block_type')) return;
        $blocks = [
            ['name'=>'wx-hero-slider','title'=>'WX Hero Slider','template'=>'hero-slider'],
            ['name'=>'wx-cine','title'=>'WX Cine Hero','template'=>'cine'],
            ['name'=>'wx-brief-form','title'=>'WX Brief Form','template'=>'brief-form'],
            ['name'=>'wx-ticker','title'=>'WX Ticker','template'=>'ticker'],
            ['name'=>'wx-gates','title'=>'WX Gates','template'=>'gates'],
            ['name'=>'wx-custom-html','title'=>'WX Custom HTML/CSS/JS','template'=>'custom-html'],
        ];
        foreach ($blocks as $block) {
            acf_register_block_type([
                'name' => $block['name'],
                'title' => esc_html($block['title']),
                'render_template' => WX_MASTER_DIR . '/template-parts/sections/' . $block['template'] . '.php',
                'category' => 'formatting',
                'icon' => 'admin-comments',
                'keywords' => ['wx','woodex'],
                'supports' => ['align'=>true,'customClassName'=>true],
            ]);
        }
    }
}
