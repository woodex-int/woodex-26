<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
if (class_exists('OxygenElement')) {
class WX_Oxy_hero_slider extends OxygenElement {
    function name() { return 'WX hero slider'; }
    function icon() { return 'fa fa-star'; }
    function render($options,$defaults,$content) {
        echo '<div class="wx-hero-slider">WX hero-slider — Oxygen — Original</div>';
    }
    function controls() {
        $this->addOptionControl(['type'=>'textfield','name'=>'Title','slug'=>'title']);
    }
}
new WX_Oxy_hero_slider();
}
