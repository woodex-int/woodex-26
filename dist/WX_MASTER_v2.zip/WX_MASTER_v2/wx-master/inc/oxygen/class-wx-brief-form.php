<?php
declare(strict_types=1);
defined('ABSPATH') || exit;
if (class_exists('OxygenElement')) {
class WX_Oxy_brief_form extends OxygenElement {
    function name() { return 'WX brief form'; }
    function icon() { return 'fa fa-star'; }
    function render($options,$defaults,$content) {
        echo '<div class="wx-brief-form">WX brief-form — Oxygen — Original</div>';
    }
    function controls() {
        $this->addOptionControl(['type'=>'textfield','name'=>'Title','slug'=>'title']);
    }
}
new WX_Oxy_brief_form();
}
