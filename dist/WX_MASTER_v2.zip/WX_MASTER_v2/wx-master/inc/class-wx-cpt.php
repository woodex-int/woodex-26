<?php
/**
 * WX CPT — Custom Post Types for templates and portfolio
 * Original, no third-party core
 *
 * @package wx-master
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

class WX_CPT {
    private static ?self $instance = null;
    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_action('init', [$this, 'register_cpts']);
    }

    public function register_cpts(): void {
        $this->register_template_cpt();
        $this->register_portfolio_cpt();
        $this->register_services_cpt();
    }

    private function register_template_cpt(): void {
        register_post_type('wx_template', [
            'labels' => [
                'name' => esc_html__('WX Templates', 'wx-master'),
                'singular_name' => esc_html__('Template', 'wx-master'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-layout',
            'supports' => ['title','editor','thumbnail'],
            'show_in_rest' => true,
        ]);

        register_taxonomy('wx_template_type', 'wx_template', [
            'labels' => [
                'name' => esc_html__('Template Types', 'wx-master'),
            ],
            'public' => false,
            'show_ui' => true,
            'hierarchical' => true,
            'show_in_rest' => true,
        ]);

        // Seed types if not exist
        if (!term_exists('header', 'wx_template_type')) {
            wp_insert_term('Header', 'wx_template_type', ['slug'=>'header']);
            wp_insert_term('Footer', 'wx_template_type', ['slug'=>'footer']);
            wp_insert_term('Mega Menu', 'wx_template_type', ['slug'=>'mega-menu']);
            wp_insert_term('Page Block', 'wx_template_type', ['slug'=>'page-block']);
        }
    }

    private function register_portfolio_cpt(): void {
        register_post_type('wx_portfolio', [
            'labels' => [
                'name' => esc_html__('Portfolio', 'wx-master'),
                'singular_name' => esc_html__('Project', 'wx-master'),
            ],
            'public' => true,
            'has_archive' => true,
            'rewrite' => ['slug'=>'projects'],
            'supports' => ['title','editor','thumbnail','excerpt'],
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-portfolio',
        ]);
    }

    private function register_services_cpt(): void {
        register_post_type('wx_service', [
            'labels' => [
                'name' => esc_html__('Services', 'wx-master'),
                'singular_name' => esc_html__('Service', 'wx-master'),
            ],
            'public' => true,
            'has_archive' => true,
            'rewrite' => ['slug'=>'services'],
            'supports' => ['title','editor','thumbnail','excerpt'],
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-admin-tools',
        ]);
    }
}
