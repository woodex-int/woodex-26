<?php
/**
 * WX Master — Functions (Original, standalone, no parent)
 * Phase 0: Scaffold
 * Hard rules: No third-party core, no third-party loader, no parent theme header, no b64 decode, no eval
 * WP standards: index.php present, activates with no parent, PHP 8.1 strict, sanitize/escape, nonces, caps, text-domain wx-master
 * Hygiene: files <400 lines, functions <50 lines
 *
 * @package wx-master
 * @since 1.0.0
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

define('WX_MASTER_VERSION', '1.0.0');
define('WX_MASTER_DIR', get_template_directory());
define('WX_MASTER_URI', get_template_directory_uri());
define('WX_MASTER_SKINS_DIR', WX_MASTER_DIR . '/assets/skins');
define('WX_MASTER_SKINS_URI', WX_MASTER_URI . '/assets/skins');

// Load inc files (original, no third-party copy)
require_once WX_MASTER_DIR . '/inc/class-wx-setup.php';
require_once WX_MASTER_DIR . '/inc/class-wx-tokens.php';
require_once WX_MASTER_DIR . '/inc/class-wx-cpt.php';
require_once WX_MASTER_DIR . '/inc/class-wx-builder.php';
require_once WX_MASTER_DIR . '/inc/class-wx-builder-router.php';
require_once WX_MASTER_DIR . '/inc/class-wx-plugins.php';
require_once WX_MASTER_DIR . '/inc/class-wx-skins.php';
require_once WX_MASTER_DIR . '/inc/class-wx-wizard.php';
require_once WX_MASTER_DIR . '/inc/class-wx-mcp.php';

add_action('after_setup_theme', 'wx_master_setup');
/**
 * Theme setup — original code
 */
function wx_master_setup(): void {
    load_theme_textdomain('wx-master', WX_MASTER_DIR . '/languages');

    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
    add_theme_support('custom-logo', [
        'height' => 40,
        'width' => 200,
        'flex-height' => true,
        'flex-width' => true,
    ]);
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');

    register_nav_menus([
        'primary' => esc_html__('Primary Menu (WX Mega)', 'wx-master'),
        'footer' => esc_html__('Footer Menu', 'wx-master'),
    ]);

    add_action('wp_enqueue_scripts', 'wx_master_enqueue');
    add_action('admin_enqueue_scripts', 'wx_master_admin_enqueue');
    add_action('widgets_init', 'wx_master_widgets');

    // Init core (Phase A + B)
    WX_Setup::instance();
    WX_Tokens::instance();
    WX_CPT::instance();
    WX_Builder::instance();
    WX_Builder_Router::instance();
    WX_Plugins::instance();
    WX_Skins::instance();
    WX_Wizard::instance();
    WX_MCP::instance();
}

/**
 * Enqueue frontend assets — original CSS/JS, no third-party copy
 */
function wx_master_enqueue(): void {
    wp_enqueue_style('wx-global', WX_MASTER_URI . '/assets/css/wx-global.css', [], WX_MASTER_VERSION);
    wp_enqueue_style('wx-tokens', WX_MASTER_URI . '/assets/css/wx-tokens.css', ['wx-global'], WX_MASTER_VERSION);
    wp_enqueue_style('wx-base', WX_MASTER_URI . '/assets/css/wx-base.css', ['wx-global'], WX_MASTER_VERSION);
    wp_enqueue_style('wx-header', WX_MASTER_URI . '/assets/css/wx-header.css', ['wx-base'], WX_MASTER_VERSION);
    wp_enqueue_style('wx-footer', WX_MASTER_URI . '/assets/css/wx-footer.css', ['wx-base'], WX_MASTER_VERSION);
    wp_enqueue_style('wx-mega', WX_MASTER_URI . '/assets/css/wx-mega.css', ['wx-base'], WX_MASTER_VERSION);
    wp_enqueue_style('wx-components', WX_MASTER_URI . '/assets/css/wx-components.css', ['wx-base'], WX_MASTER_VERSION);

    wp_enqueue_script('wx-frontend', WX_MASTER_URI . '/assets/js/wx-frontend.js', [], WX_MASTER_VERSION, true);

    wp_localize_script('wx-frontend', 'wxData', [
        'ajax_url' => esc_url(admin_url('admin-ajax.php')),
        'nonce' => wp_create_nonce('wx-frontend-nonce'),
        'whatsapp' => esc_url('https://wa.me/923224000768'),
        'i18n' => [
            'no_results' => esc_html__('No results', 'wx-master'),
        ],
    ]);

    // Plus Jakarta Sans — locked token, Google Fonts
    wp_enqueue_style('plus-jakarta', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap', [], null);
}

/**
 * Admin assets
 */
function wx_master_admin_enqueue(string $hook): void {
    if (str_contains($hook, 'wx-') || str_contains($hook, 'wx_master')) {
        wp_enqueue_style('wx-admin', WX_MASTER_URI . '/assets/css/wx-admin.css', [], WX_MASTER_VERSION);
        wp_enqueue_script('wx-admin', WX_MASTER_URI . '/assets/js/wx-admin.js', ['jquery'], WX_MASTER_VERSION, true);
        wp_localize_script('wx-admin', 'wxAdmin', [
            'ajax_url' => esc_url(admin_url('admin-ajax.php')),
            'nonce' => wp_create_nonce('wx-admin-nonce'),
        ]);
    }
}

/**
 * Widgets
 */
function wx_master_widgets(): void {
    register_sidebar([
        'name' => esc_html__('Sidebar', 'wx-master'),
        'id' => 'sidebar-1',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ]);
    register_sidebar([
        'name' => esc_html__('Footer', 'wx-master'),
        'id' => 'footer-1',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="widget-title">',
        'after_title' => '</h4>',
    ]);
}

// Fallback for builder detection
function wx_master_is_elementor_active(): bool {
    return defined('ELEMENTOR_VERSION') || class_exists('\Elementor\Plugin');
}
function wx_master_is_oxygen_active(): bool {
    return defined('CT_VERSION') || function_exists('oxygen_vsb_init');
}
function wx_master_is_acf_active(): bool {
    return class_exists('ACF') || function_exists('get_field');
}
