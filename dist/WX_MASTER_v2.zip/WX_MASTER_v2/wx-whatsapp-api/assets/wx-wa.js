/**
 * WX WhatsApp API — Vanilla JS, no jQuery, consent + opt-out persisted, unread badge
 */
(() => {
  'use strict';
  const floatBtn = document.getElementById('wx-wa-float') || document.querySelector('.wx-float-whatsapp');
  const card = document.getElementById('wx-wa-card');
  const closeBtn = document.querySelector('.wx-wa-close');
  const consentEl = document.getElementById('wx-wa-consent');
  const consentBtn = document.getElementById('wx-wa-consent-btn');
  const optOutBtn = document.querySelector('.wx-wa-opt-out');
  const optOutNotice = document.getElementById('wx-wa-opt-out-notice');
  const optInBtn = document.getElementById('wx-wa-opt-in-btn');
  const input = document.getElementById('wx-wa-input');
  const sendBtn = document.getElementById('wx-wa-send');
  const messagesEl = document.getElementById('wx-wa-messages');
  const faqBtns = document.querySelectorAll('.wx-wa-faq-btn');

  const CONSENT_KEY = 'wx_wa_consent';
  const OPT_OUT_KEY = 'wx_wa_opt_out';

  const isOptedOut = () => localStorage.getItem(OPT_OUT_KEY) === '1';
  const setOptedOut = (val) => {
    if (val) localStorage.setItem(OPT_OUT_KEY, '1');
    else localStorage.removeItem(OPT_OUT_KEY);
  };

  const showConsentIfNeeded = () => {
    if (!localStorage.getItem(CONSENT_KEY) && consentEl) {
      consentEl.hidden = false;
    }
  };

  const checkOptOutUI = () => {
    if (isOptedOut()) {
      if (card) {
        const body = card.querySelector('.wx-chat-body');
        const inputArea = card.querySelector('.wx-chat-input');
        if (body) body.hidden = true;
        if (inputArea) inputArea.hidden = true;
      }
      if (optOutNotice) optOutNotice.hidden = false;
    } else {
      if (card) {
        const body = card.querySelector('.wx-chat-body');
        const inputArea = card.querySelector('.wx-chat-input');
        if (body) body.hidden = false;
        if (inputArea) inputArea.hidden = false;
      }
      if (optOutNotice) optOutNotice.hidden = true;
    }
  };

  floatBtn?.addEventListener('click', (e) => {
    if (isOptedOut()) {
      // If opted out, still show card with opt-in notice
      e.preventDefault();
    }
    if (card) {
      const isOpen = card.classList.contains('is-open');
      if (!isOpen) {
        if (!isOptedOut()) e.preventDefault();
        card.hidden = false;
        requestAnimationFrame(() => card.classList.add('is-open'));
        showConsentIfNeeded();
        checkOptOutUI();
      }
    }
  });

  closeBtn?.addEventListener('click', () => {
    card?.classList.remove('is-open');
    setTimeout(() => { if(card) card.hidden = true; }, 400);
  });

  consentBtn?.addEventListener('click', () => {
    localStorage.setItem(CONSENT_KEY, '1');
    if (consentEl) consentEl.hidden = true;
  });

  optOutBtn?.addEventListener('click', () => {
    if (window.confirm('Opt-out? No messages will be stored.')) {
      setOptedOut(true);
      checkOptOutUI();
      // AJAX to server
      if (window.wxWA) {
        fetch(wxWA.ajax_url, {
          method:'POST',
          headers:{'Content-Type':'application/x-www-form-urlencoded'},
          body:new URLSearchParams({action:'wx_wa_opt_out', from:'visitor', action_type:'opt_out', nonce:wxWA.nonce})
        });
      }
    }
  });

  optInBtn?.addEventListener('click', () => {
    setOptedOut(false);
    checkOptOutUI();
    if (window.wxWA) {
      fetch(wxWA.ajax_url, {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({action:'wx_wa_opt_out', from:'visitor', action_type:'opt_in', nonce:wxWA.nonce})
      });
    }
  });

  const addMessage = (text, isUser) => {
    if (!messagesEl) return;
    const div = document.createElement('div');
    div.className = 'wx-msg ' + (isUser ? 'wx-msg-user' : 'wx-msg-bot');
    const p = document.createElement('p');
    p.textContent = text;
    div.appendChild(p);
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  };

  const sendMessage = () => {
    if (!input || isOptedOut()) return;
    const text = input.value.trim();
    if (!text) return;
    if (!localStorage.getItem(CONSENT_KEY)) {
      alert('Please agree to consent first');
      return;
    }
    addMessage(text, true);
    input.value = '';
    // AJAX to REST /wx-live/v1/send
    if (window.wxWA) {
      fetch('/wp-json/wx-live/v1/send', {
        method:'POST',
        headers:{'Content-Type':'application/json','X-WP-Nonce': wxWA.nonce},
        body:JSON.stringify({to:'923224000768', message:text, thread_id:''})
      }).then(r=>r.json()).then(res=>{
        if (res.auto && res.response) {
          setTimeout(()=> addMessage(res.response, false), 800);
        }
      });
    }
  };

  sendBtn?.addEventListener('click', sendMessage);
  input?.addEventListener('keydown', (e)=>{ if(e.key==='Enter') sendMessage(); });

  faqBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.dataset.question || btn.textContent;
      if (input) {
        input.value = q;
        sendMessage();
      }
    });
  });

  // Init
  checkOptOutUI();
})();
