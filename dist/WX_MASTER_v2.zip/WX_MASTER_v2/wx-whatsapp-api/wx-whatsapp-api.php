<?php
/**
 * Plugin Name: WX WhatsApp API — Live Chat
 * Plugin URI: https://woodex.interior/wx-whatsapp-api
 * Description: Original WhatsApp float + slide-over chat card, consent notice, REST /wp-json/wx-live/v1/{send,receive,threads} → WhatsApp Business Cloud API, auto-responder, transcript storage, opt-out. No SaaS required. Part of WX Master.
 * Version: 1.0.0
 * Author: Woodex Interior
 * Author URI: https://woodex.interior
 * License: GPL-2.0-or-later
 * Text Domain: wx-whatsapp-api
 * Requires at least: 6.0
 * Requires PHP: 8.1
 */

declare(strict_types=1);
defined('ABSPATH') || exit;

define('WX_WA_VERSION','1.0.0');
define('WX_WA_DIR', plugin_dir_path(__FILE__));
define('WX_WA_URI', plugin_dir_url(__FILE__));

require_once WX_WA_DIR . 'includes/class-wx-wa-live.php';

add_action('plugins_loaded', function(){
    load_plugin_textdomain('wx-whatsapp-api', false, dirname(plugin_basename(__FILE__)).'/languages');
    WX_WA_Live::instance();
});

register_activation_hook(__FILE__, function(){ flush_rewrite_rules(); });
register_deactivation_hook(__FILE__, function(){ flush_rewrite_rules(); });
