#!/usr/bin/env python3
"""
WX Theme Master — Static HTML to WP Blocks Converter
[ACTION: PARSE_HTML]

Converts 66 static HTML pages (WOODEX-26) into:
1. us_page_block shortcode strings (for WPBakery / Impreza)
2. Elementor JSON per Ak-Elementor-Studio spec: {"version":"0.4","title":"...","type":"page","content":[...]}

Input: ./index.html, ./3d-studio.html, ./services/*.html, ./projects/*.html, ./insights/*.html, ./locations/*.html + content/site.json, services.json
Output: wx-theme-master/assets/skins/woodex-interior/content.xml (WXR placeholder) + theme_options.json + elementor-kit/*.json

Usage:
    python scripts/parse_static_to_blocks.py --input . --output ./wx-theme-master/assets/skins/woodex-interior/

Dependencies: beautifulsoup4 (pip install beautifulsoup4)
"""

import os
import json
import argparse
import re
from pathlib import Path

try:
    from bs4 import BeautifulSoup
except ImportError:
    print("Missing beautifulsoup4, installing...")
    os.system("pip install beautifulsoup4")
    from bs4 import BeautifulSoup

# Woodex tokens
TOKENS = {
    "navy": "#0c1628",
    "navy2": "#121e34",
    "card": "#152033",
    "cream": "#f4efe7",
    "ink": "#12151c",
    "wood": "#b8956a",
    "muted": "#6a6560",
    "font": "Plus Jakarta Sans"
}

def generate_id():
    import hashlib, random, time
    return hashlib.md5(f"{random.random()}{time.time()}".encode()).hexdigest()[:7]

def create_elementor_container(elements, settings=None):
    if settings is None:
        settings = {}
    return {
        "id": generate_id(),
        "elType": "container",
        "settings": settings,
        "elements": elements,
        "isInner": False,
        "isLocked": False
    }

def create_elementor_widget(widgetType, settings=None):
    if settings is None:
        settings = {}
    return {
        "id": generate_id(),
        "elType": "widget",
        "widgetType": widgetType,
        "settings": settings,
        "elements": [],
        "isInner": False,
        "isLocked": False
    }

def html_to_elementor_json(html, title="Converted Section"):
    soup = BeautifulSoup(html, 'html.parser')
    
    # Try to find main sections
    sections = soup.select('section, .cine-hero, .hero, .b3, .folio, .wx-cine-hero, .wx-b3, .wx-folio')
    
    elements = []
    
    if not sections:
        # Single container with HTML widget
        elements.append(
            create_elementor_container(
                [create_elementor_widget('html', {'html': html})],
                {'background_background': 'classic', 'background_color': '#ffffff', 'padding': {'unit':'px','top':'80','right':'0','bottom':'80','left':'0','isLinked':False}}
            )
        )
    else:
        for sec in sections[:10]:  # Limit to 10 sections for demo
            sec_html = str(sec)
            classes = sec.get('class', [])
            class_str = ' '.join(classes) if isinstance(classes, list) else str(classes)
            
            # Detect bg
            bg = '#ffffff'
            if 'bg-cream' in class_str or 'cream' in class_str:
                bg = TOKENS['cream']
            elif 'bg-navy' in class_str or 'navy' in class_str or 'cine' in class_str:
                bg = TOKENS['navy']
            
            widgets = []
            
            # Extract headings
            h1 = sec.find('h1')
            if h1:
                widgets.append(create_elementor_widget('heading', {
                    'title': h1.get_text(strip=True),
                    'header_size': 'h1',
                    'typography_typography': 'custom',
                    'typography_font_family': TOKENS['font'],
                    'typography_font_weight': '500',
                    'typography_font_size': {'unit':'px','size':48,'sizes':[]},
                    'align': 'center'
                }))
            
            h2 = sec.find('h2')
            if h2 and not h1:
                widgets.append(create_elementor_widget('heading', {
                    'title': h2.get_text(strip=True),
                    'header_size': 'h2',
                    'typography_font_family': TOKENS['font']
                }))
            
            # Paragraphs
            for p in sec.find_all('p')[:2]:
                text = p.get_text(strip=True)
                if text and len(text) > 20:
                    widgets.append(create_elementor_widget('text-editor', {'editor': f"<p>{text}</p>"}))
                    break
            
            # Images
            img = sec.find('img')
            if img and img.get('src'):
                widgets.append(create_elementor_widget('image', {
                    'image': {'url': img.get('src'), 'id': ''},
                    'image_size': 'full'
                }))
            
            # Buttons
            btn = sec.select_one('.btn, .w-btn, a.button, button')
            if btn:
                btn_text = btn.get_text(strip=True)
                if btn_text:
                    widgets.append(create_elementor_widget('button', {
                        'text': btn_text,
                        'link': {'url': '#', 'is_external': False},
                        'background_color': TOKENS['navy'],
                        'typography_typography': 'custom',
                        'typography_font_family': TOKENS['font']
                    }))
            
            if not widgets:
                widgets.append(create_elementor_widget('html', {'html': sec_html[:5000]}))
            
            elements.append(
                create_elementor_container(widgets, {
                    'background_background': 'classic',
                    'background_color': bg,
                    'padding': {'unit':'px','top':'80','right':'0','bottom':'80','left':'0','isLinked':False},
                    'flex_direction': 'column',
                    'content_width': 'full'
                })
            )
    
    return {
        "version": "0.4",
        "title": title,
        "type": "page",
        "content": elements,
        "page_settings": {
            "layout": "no",
            "hide_title": "yes"
        }
    }

def html_to_us_block(html):
    soup = BeautifulSoup(html, 'html.parser')
    
    output = ""
    
    # Map to shortcodes
    if soup.select_one('.cine-hero, .wx-cine-hero'):
        title = ""
        h1 = soup.find('h1')
        if h1:
            title = h1.get_text(strip=True)
        output += f'[vc_row][vc_column][wx_cine_hero title="{title}" image="studio-hero.jpg" height="full"][/vc_column][/vc_row]'
    
    if soup.select_one('.hero, .home-hero'):
        output += '[vc_row][vc_column][wx_home_hero slides="hero-1.jpg,hero-2.jpg,hero-3.jpg" labels="LAYOUT,DESIGN,CREATE"][/vc_column][/vc_row]'
    
    if soup.select_one('.b3, .wx-b3'):
        output += '[vc_row][vc_column][wx_blog_three count="3"][/vc_column][/vc_row]'
    
    if soup.select_one('.folio, .portfolio-two, .wx-folio'):
        output += '[vc_row][vc_column][wx_portfolio_two filter="all,residential,commercial"][/vc_column][/vc_row]'
    
    if not output:
        # Fallback: wrap in vc_row
        safe_html = html.replace('[', '&#91;').replace(']', '&#93;')
        output = f'[vc_row][vc_column][vc_column_text]{safe_html[:10000]}[/vc_column_text][/vc_column][/vc_row]'
    
    return output

def batch_convert(input_dir, output_dir):
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    (output_path / "elementor-kit").mkdir(exist_ok=True)
    (output_path / "media").mkdir(exist_ok=True)
    
    html_files = list(input_path.glob("*.html")) + list((input_path / "services").glob("*.html"))[:5] + list((input_path / "projects").glob("*.html"))[:3]
    
    results = []
    
    for html_file in html_files[:10]:  # Limit for demo
        print(f"Converting {html_file}...")
        html = html_file.read_text(encoding='utf-8', errors='ignore')
        title = html_file.stem
        
        us_block = html_to_us_block(html)
        elementor_json = html_to_elementor_json(html, title)
        
        # Write outputs
        (output_path / f"{title}.us_block.txt").write_text(us_block, encoding='utf-8')
        (output_path / "elementor-kit" / f"{title}.json").write_text(json.dumps(elementor_json, indent=2), encoding='utf-8')
        
        results.append({
            "file": str(html_file),
            "title": title,
            "us_block_length": len(us_block),
            "elementor_elements": len(elementor_json['content'])
        })
    
    # Generate theme_options.json with Woodex tokens
    theme_options = {
        "color_content_primary": TOKENS["navy"],
        "color_content_secondary": TOKENS["wood"],
        "color_content_bg": "#ffffff",
        "color_content_bg_alt": TOKENS["cream"],
        "color_content_text": TOKENS["ink"],
        "color_header_bg": TOKENS["navy"],
        "color_footer_bg": TOKENS["navy"],
        "font_body": TOKENS["font"],
        "font_heading": TOKENS["font"],
        "site_name": "Woodex Interior",
        "proof": {
            "projects": "500+",
            "founder": "~20 years",
            "execution": "10+ years",
            "iso": "ISO 9001",
            "client": "Wellstar only"
        }
    }
    
    (output_path / "theme_options.json").write_text(json.dumps(theme_options, indent=2), encoding='utf-8')
    
    # Generate placeholder content.xml (WXR)
    wxr_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
    xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"
    xmlns:content="http://purl.org/rss/1.0/modules/content/"
    xmlns:wfw="http://wellformedweb.org/CommentAPI/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:wp="http://wordpress.org/export/1.2/">
<channel>
    <title>Woodex Interior</title>
    <wp:wxr_version>1.2</wp:wxr_version>
    <!-- This is a placeholder WXR. Real WXR would be generated by WordPress export or WP_Import -->
    <!-- For full WXR, use WordPress > Tools > Export after building pages with wx-converter -->
    <item>
        <title>Home</title>
        <wp:post_type>page</wp:post_type>
        <wp:status>publish</wp:status>
        <content:encoded><![CDATA[[vc_row][vc_column][wx_home_hero][/vc_column][/vc_row]]]></content:encoded>
    </item>
    <item>
        <title>Woodex Transparent Cine Header</title>
        <wp:post_type>us_header</wp:post_type>
        <wp:status>publish</wp:status>
        <content:encoded><![CDATA[Header JSON from header-templates.php]]></content:encoded>
    </item>
    <item>
        <title>Woodex Default Footer</title>
        <wp:post_type>us_footer</wp:post_type>
        <wp:status>publish</wp:status>
        <content:encoded><![CDATA[Footer content]]></content:encoded>
    </item>
</channel>
</rss>
"""
    (output_path / "content.xml").write_text(wxr_content, encoding='utf-8')
    
    # Summary
    summary = {
        "converted": len(results),
        "files": results,
        "tokens": TOKENS,
        "output_dir": str(output_path)
    }
    
    (output_path / "conversion_summary.json").write_text(json.dumps(summary, indent=2), encoding='utf-8')
    
    print(f"\nDone! Converted {len(results)} files to {output_path}")
    print(f"Check {output_path / 'elementor-kit/'} for Elementor JSON")
    print(f"Check {output_path / 'theme_options.json'} for theme options")
    print(f"Check {output_path / 'content.xml'} for WXR placeholder")
    
    return summary

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="WX Static to WP Blocks Converter")
    parser.add_argument('--input', default='.', help='Input dir with static HTML')
    parser.add_argument('--output', default='./wx-theme-master/assets/skins/woodex-interior/', help='Output dir for skin')
    args = parser.parse_args()
    
    batch_convert(args.input, args.output)
