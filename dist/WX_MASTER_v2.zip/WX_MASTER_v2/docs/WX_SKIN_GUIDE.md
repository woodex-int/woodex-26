# WX Skin Guide — Create New Client Skin in 30 Minutes

**For:** `wx-theme-master` multi-skin system  
**Time:** 30 min per skin after Woodex canonical is done  
**Output:** New folder `assets/skins/client-name/` that auto-appears in Setup Wizard > Sites

---

## 1. Duplicate Woodex Skin

```bash
cd wp-content/themes/wx-theme-master/assets/skins/
cp -r woodex-interior/ client-name/
cd client-name/
rm -rf media/* elementor-kit/* # keep structure, delete content
```

## 2. Edit preset.json

```json
{
  "name": "Client Name — e.g., Modern Architect Studio",
  "slug": "client-name",
  "version": "1.0.0",
  "description": "Short description for wizard card — e.g., Minimalist architecture portfolio",
  "preview": "preview.jpg",
  "builder": "us-core", // or "elementor"
  "colors": {
    "navy": "#0a0a0a",
    "wood": "#d4a574",
    "cream": "#faf6f1",
    "ink": "#1a1a1a"
  },
  "fonts": {
    "primary": "Inter",
    "weights": [400,500,600]
  },
  "header": "simple_1",
  "footer": "footer_1"
}
```

## 3. Colors

Edit `color-schemes.php`:

```php
return [
  'client-name' => [
    'title' => 'Client Name — Black / Gold',
    'values' => [
      'color_content_primary' => '#0a0a0a',
      'color_content_secondary' => '#d4a574',
      // ...
    ]
  ]
];
```

Or just rely on `preset.json` colors — `class-wx-preset.php` will apply them to theme_options.

## 4. Headers/Footers

- Option A: Use existing Impreza templates (`simple_1`, `extended_1`, etc.) — just set `"header": "simple_1"` in preset.json
- Option B: Create custom header in WP Admin > Templates > Headers > Add New > build with Impreza header builder > Export > copy JSON to `header-templates.php`

For Woodex-style custom:

```php
// header-templates.php
'client-name-transparent' => [
  'title' => 'Client Transparent',
  'default' => [
    'options' => ['orientation'=>'hor','middle_height'=>'80px','transparent'=>1],
    'layout' => ['middle_left'=>['image:1'],'middle_center'=>['menu:1'],'middle_right'=>['btn:1']],
  ],
]
```

## 5. Content

### Option A: WXR (Impreza style)

1. Build site in WP Admin (pages, portfolio, headers, footers, page_blocks)
2. Tools > Export > All content > Download Export File → save as `content.xml`
3. Place in `assets/skins/client-name/content.xml`

### Option B: Elementor Kit

1. Elementor > Tools > Import/Export Kit > Export Kit (includes global styles, header, footer, pages, site settings)
2. Unzip, copy JSON files to `elementor-kit/`:
   - `global-styles.json`
   - `header.json`, `footer.json`
   - `home.json`, `about.json`, etc.
3. Ensure each JSON follows Ak-Elementor-Studio spec: `{"version":"0.4","title":"...","type":"page","content":[...]}`

### Option C: Use Static-to-WP Converter

```bash
python scripts/parse_static_to_blocks.py --input ./client-static/ --output ./wx-theme-master/assets/skins/client-name/
# Generates content.xml placeholder + theme_options.json + elementor-kit/*.json
```

Then manually refine WXR in WP Admin.

## 6. Theme Options

- Impreza: Appearance > Theme Options > Export > save as `theme_options.json`
- Elementor: Site Settings > Export

Place in skin folder.

## 7. Media

- Put client images in `media/` (or `uploads/` for WXR import)
- Or use placeholders — Impreza will replace with `us-placeholder-landscape` if fetch_attachments fails
- For Elementor Kit, media is bundled in kit zip

## 8. Preview

- Create 800x600 `preview.jpg` — screenshot of homepage
- This appears in Setup Wizard > Sites grid (like Interior Designer screenshot)
- Use same style: white bg, large heading "Modern Elegant And Luxurious Interior", small sub, Portfolio button

## 9. Test

1. Fresh WP install
2. Install `wx-theme-master` + required plugins via TGMPA
3. Appearance > Setup Wizard > Pre-Built Website > should see Client Name card
4. Select Content: All content checked > Next Step > Installation
5. Verify: Home, headers, footers, portfolio, pages imported, colors applied

## 10. AgentBridge Test (Optional)

```bash
# After install
curl -u "admin:app_password" -X POST https://client.local/wp-json/wx-agent/v1/inspect-site/
# Should return skins list including client-name

curl -u "admin:app_password" -X POST https://client.local/wp-json/wx-agent/v1/apply-preset/ \
  -H "Content-Type: application/json" \
  -d '{"skin":"client-name"}'
```

## Checklist

- [ ] `preset.json` edited (name, slug, colors, fonts, header, footer, builder)
- [ ] `preview.jpg` 800x600 created
- [ ] `content.xml` WXR present (or placeholder)
- [ ] `theme_options.json` present
- [ ] `elementor-kit/` JSONs present (if Elementor builder)
- [ ] `media/` images or placeholders
- [ ] Tested in Setup Wizard > Sites > Content > Installation
- [ ] Tested preset switcher in WX Presets admin page
- [ ] Tested AgentBridge inspect-site

Done — new skin is live for all future clients.

---

**Tips:**

- Keep Woodex as canonical reference — all new skins should follow same structure
- Use `scripts/parse_static_to_blocks.py` to bootstrap from static HTML
- For quick client demo, just change colors + fonts + preview.jpg, keep same content.xml — instant new skin
- Document skin in `assets/skins/client-name/README.md` with client-specific notes (proof facts, named clients, etc.)
