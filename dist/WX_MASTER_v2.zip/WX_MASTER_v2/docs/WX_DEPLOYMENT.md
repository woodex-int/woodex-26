# WX Deployment Guide

## Static Site (Current Live)

**Stack:** HTML5 + Tailwind CDN + css/theme.css + js/app.js  
**Deploy:** Any static host

```bash
cd WOODEX-26
python3 -m http.server 8080 --bind 0.0.0.0
```

- **Vercel:** import folder — `vercel.json` included
- **Netlify:** publish `.` — `netlify.toml` sends unknown routes to `404.html`
- **Hostinger / Apache:** `.htaccess` sets `ErrorDocument 404 /404.html`
- **Sitemap:** `https://woodex.interior/sitemap.xml`
- **Robots:** `robots.txt`

Change `https://woodex.interior` host in `sitemap.xml`, `robots.txt`, and each page's canonical / OG / JSON-LD when live domain final.

---

## WordPress — WX Theme Master (New)

### Option A: Impreza Engine (Replica, Recommended)

**Requirements:** WordPress 6.0+, PHP 8.1+, MySQL 5.7+

**Steps:**

1. **Buy licenses (legit):**
   - Impreza ThemeForest $59 (includes WPBakery + Slider Revolution)
   - FileBird Pro $39 or use Lite free
   - AgentBridge free, EMCP Tools free

2. **Install WordPress:**
   ```bash
   wp core download
   wp core install --url="https://woodex.local" --title="Woodex Interior" --admin_user=admin --admin_email=studio@woodex.interior
   ```

3. **Upload themes:**
   - `wp-content/themes/Impreza/` (clean from ThemeForest, no hack)
   - `wp-content/themes/wx-theme-master/` (this repo's `wx-theme-master/`)

4. **Activate child/master:**
   - Appearance > Themes > Activate WX Theme Master

5. **Install plugins via TGMPA:**
   - Appearance > Install Plugins > Install All: us-core, js_composer, filebird, wx-addons, agentbridge, emcp-tools, etc.
   - Activate

6. **Setup Wizard:**
   - Appearance > Setup Wizard > Pre-Built Website > Choose Woodex Interior (preview shows Modern Elegant...)
   - Content: All content checked (Pages, Portfolio, Headers, Page Templates, Reusable Blocks, Site Settings, Theme Options)
   - Next Step > Installation > Wait > Success

7. **Set homepage:**
   - Settings > Reading > Homepage displays: A static page > Home

8. **Activate license:**
   - us-theme-options > License > Enter purchase code > Activate (for updates)

### Option B: Elementor Free Base (No License Cost)

**Requirements:** Same WP, but no Impreza needed

1. **Install:**
   ```bash
   wp plugin install --activate elementor hello-elementor header-footer-elementor essential-addons-for-elementor-lite fluentform
   wp theme install --activate hello-elementor
   # Then install wx-theme-master as plugin? Or as theme that works with Hello
   wp theme install --activate ./wx-theme-master/ # WX detects no us-core, uses Elementor mode
   ```

2. **Import Kit:**
   - Elementor > Tools > Import Kit > Upload `wx-theme-master/assets/skins/woodex-interior/elementor-kit.zip` (you need to zip elementor-kit folder)
   - Or use OCDI: Plugins > One Click Demo Import > Import from `content.xml`

3. **Set header/footer:**
   - Appearance > Header Footer Builder > Import `header-transparent.json`, `footer-default.json`

### Option C: Hybrid (Your Choice)

- `wx-theme-master` auto-detects builder:
  - If `us-core` active → uses Impreza headers/footers, WPBakery shortcodes
  - If Elementor active → uses Elementor kit, Elementor widgets
  - `preset.json` has `"builder": "us-core"` field to force

---

## One-Click Installer Script

`scripts/install-woodex.sh`:

```bash
#!/bin/bash
set -e

echo "WX Theme Master — One-click installer"

# Check wp-cli
if ! command -v wp &> /dev/null; then
  echo "wp-cli not found, install from https://wp-cli.org"
  exit 1
fi

# Download WP
wp core download --locale=en_US --force

# Install
wp core install --url="http://woodex.local" --title="Woodex Interior" --admin_user=admin --admin_password=admin123 --admin_email=studio@woodex.interior --skip-email

# Install free plugins
wp plugin install --activate elementor hello-elementor header-footer-elementor essential-addons-for-elementor-lite fluentform contact-form-7 one-click-demo-import

# Install bundled plugins (place zips in inc/plugins/)
for zip in wx-theme-master/inc/plugins/*.zip; do
  if [ -f "$zip" ]; then
    wp plugin install --activate "$zip" || echo "Failed $zip, manual install needed"
  fi
done

# Activate theme
wp theme install --activate ./wx-theme-master/ || wp theme activate wx-theme-master

# Import demo if exists
if [ -f "wx-theme-master/assets/skins/woodex-interior/content.xml" ]; then
  wp import wx-theme-master/assets/skins/woodex-interior/content.xml --authors=create || echo "Import failed, use WP Admin > Tools > Import"
fi

# Set homepage
HOME_ID=$(wp post list --post_type=page --name=home --format=ids --allow-root 2>/dev/null || echo "")
if [ -n "$HOME_ID" ]; then
  wp option update show_on_front page --allow-root
  wp option update page_on_front $HOME_ID --allow-root
fi

echo "Done! Run: wp server --host=0.0.0.0 --port=8080 --allow-root"
echo "Admin: http://woodex.local/wp-admin (admin / admin123)"
echo "Setup Wizard: http://woodex.local/wp-admin/admin.php?page=us-setup-wizard"
echo "WX Presets: http://woodex.local/wp-admin/admin.php?page=wx-presets"
echo "AgentBridge: http://woodex.local/wp-admin/options-general.php?page=agentbridge"
```

Make executable: `chmod +x scripts/install-woodex.sh`

---

## AgentBridge + MCP Setup (For AI Devs)

1. **Install plugins:** AgentBridge + EMCP Tools via TGMPA or manual upload

2. **Generate token:**
   - WP Admin > Settings > AgentBridge > Generate Connect Token > Copy

3. **Connect Claude Code:**
   ```bash
   claude mcp add --transport http agentbridge https://your-site.com/wp-json/agentbridge/v1/mcp --header "Authorization: Basic YOUR_TOKEN"
   claude mcp list # should show agentbridge ✓ connected
   ```

4. **Connect Elementor MCP:**
   ```bash
   # EMCP Tools > Connection tab > Copy config for Claude Code
   # Or manual:
   claude mcp add --transport http emcp-tools https://your-site.com/wp-json/emcp/v1/mcp --header "Authorization: Basic YOUR_TOKEN"
   ```

5. **Connect WX Agent:**
   ```bash
   claude mcp add --transport http wx-agent https://your-site.com/wp-json/wx-agent/v1/mcp --header "Authorization: Basic YOUR_TOKEN"
   ```

6. **Test:**
   - Prompt: "What WordPress version is my site running?" → uses site_info
   - Prompt: "Inspect Woodex headers" → uses GET /wp-json/wx-agent/v1/inspect-site/
   - Prompt: "Create a draft page called Test via AgentBridge" → uses create_post

7. **Claude Kits:**
   - Run `bash ~/.claude/scripts/setup-elementor-mcp.sh` (from claude-elementor-kit) to write `.mcp.json`
   - Restart Claude Code in project folder, approve MCP servers

---

## Static-to-WP Converter Usage

```bash
# Install deps
pip install beautifulsoup4 --break-system-packages

# Convert static site to WP skin
python scripts/parse_static_to_blocks.py --input . --output ./wx-theme-master/assets/skins/woodex-interior/

# Output:
# - content.xml (WXR placeholder, refine in WP Admin)
# - theme_options.json (Woodex tokens)
# - elementor-kit/*.json (10 pages converted)
# - conversion_summary.json
```

Then:

1. Open WP Admin > Tools > Export > Download real WXR after manually building pages with converter output
2. Replace placeholder `content.xml` with real export
3. Zip `elementor-kit/` to `elementor-kit.zip` for Elementor > Tools > Export Kit

---

## Hosting

- **Hostinger WP:** Upload `wx-theme-master.zip` + `inc/plugins/*.zip` via File Manager, install via WP Admin
- **Vercel static:** Keep static site deployable (already)
- **Netlify static:** Same
- **LocalWP:** Create blueprint with Woodex skin pre-installed, export as `blueprint.zip` for team

---

## Security Notes

- Keep AgentBridge Unsafe mode OFF unless needed (it gates code execution, SQL writes, deletes)
- Revoke leaked tokens: Users > Profile > Application Passwords > Revoke
- Remove MCP connection: `claude mcp remove agentbridge`
- For production, restrict `/wp-json/wx-agent/v1/` to admin via `permission_callback` (already set to `manage_options` for POST)

---

**END**
