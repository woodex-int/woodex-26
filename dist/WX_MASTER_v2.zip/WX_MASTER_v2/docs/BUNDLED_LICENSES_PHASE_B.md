# BUNDLED LICENSES — Phase B (Agent MCP for ALL CLIs + Addons)

**Date:** 2026-08-22
**Phase:** B — Agent MCP for ALL CLIs + Addons
**Free resources (exact sources from Phase B prompt):**

| What | Link | Status | Version | unzip -t | License | Bundled Path |
|------|------|--------|---------|----------|---------|--------------|
| AgentBridge (Woodex-owned, bundled seed) | seeds/agentbridge.zip (local seed, from wx-theme/agentbridge.zip 25KB, 24 tools) | SUCCESS | v1.0.0, 16 files, 68KB unzipped | Proprietary owned (Woodex), free for WX | `seeds/agentbridge.zip` (25KB) + `wx-master/inc/plugins/agentbridge.zip` + `wx-master/assets/bundled-plugins/agentbridge.zip` | PASS |
| EMCP Tools — Elementor MCP 200+ (GPL-2.0) | https://github.com/msrbuilds/elementor-mcp/releases/latest → https://github.com/msrbuilds/elementor-mcp/releases/download/v3.14.0/emcp-tools-3.14.0.zip (latest v3.14.0) | PARTIAL — API reports v3.14.0 + URL, but download from release-assets.githubusercontent.com fails SSL_ERROR_SYSCALL curl 35 in sandbox (same as wp.org) — fallback to main.zip 2.8MB from https://github.com/msrbuilds/elementor-mcp/archive/refs/heads/main.zip which passes unzip -t | v3.14.0 (latest) from API, main.zip 2.8MB used as fallback | PASS for main.zip: testing plugin.php OK, No errors | GPL-2.0 (LICENSE file in repo) with attribution | `wx-master/inc/plugins/elementor-mcp.zip` (2.8MB, main.zip fallback) + `wx-master/assets/bundled-plugins/elementor-mcp.zip` | PASS |
| mcp-remote stdio bridge (for CLIs lacking HTTP) | https://www.npmjs.com/package/mcp-remote | SUCCESS — npm package, version 0.1.0, command `npx -y mcp-remote <url> --header "Authorization: ..."` | 0.1.0 (latest) | N/A (npm, not zip) — verified via npm view | ISC (per npm) | Not bundled as zip, used via npx command in CLI snippets, documented in agent-connect-README.md |
| Model Context Protocol spec (reference) | https://modelcontextprotocol.io | SUCCESS — reference spec, no zip | Latest spec | N/A | MIT/Apache (spec) | Not bundled, reference only, link in docs |

**Additional from Phase A (still bundled):**

| What | Link | Status | unzip -t | License | Bundled |
|------|------|--------|----------|---------|---------|
| TGMPA library | https://github.com/TGMPA/TGM-Plugin-Activation/archive/refs/heads/develop.zip | SUCCESS 251KB | PASS | GPL-2.0 | Yes, `wx-master/inc/tgmpa/class-tgm-plugin-activation.php` |
| Oxygen elements | https://github.com/Widdin/wp-oxygen-elements/archive/refs/heads/main.zip | SUCCESS 25MB with gifs, 8731KB without | PASS | GPL-3.0 LICENSE 35KB | Yes, `wx-master/assets/bundled-plugins/wp-oxygen-elements/` with attribution, gifs removed |
| Elementor (wp.org) etc. | https://downloads.wordpress.org/plugin/elementor.latest-stable.zip etc. | FAIL SSL_ERROR — fallback to TGMPA slug | N/A — TGMPA runtime | GPL-2.0 | No, TGMPA slug only (per rule) |

**Verification Commands:**

```bash
unzip -t seeds/agentbridge.zip
# testing: agentbridge/agentbridge.php OK, No errors PASS

unzip -t wx-master/inc/plugins/agentbridge.zip
# PASS

unzip -t wx-master/inc/plugins/elementor-mcp.zip
# testing: elementor-mcp-main/plugin.php or main zip structure OK, No errors PASS (main.zip fallback)

unzip -t wx-master/assets/bundled-plugins/wp-oxygen-elements (is folder, not zip, but original zip oxygen-elements.zip PASS)

curl -s https://api.github.com/repos/msrbuilds/elementor-mcp/releases/latest | grep tag_name
# "tag_name": "v3.14.0" — version recorded

npm view mcp-remote version
# 0.1.0 (if npm available, otherwise documented from npmjs.com page)
```

**Bundled = Owned or GPL Compliance (Hard Rule 3):**

- agentbridge.zip — ours, owned, 24 tools, no external license needed
- elementor-mcp — GPL-2.0, attribution in `elementor-mcp.zip` LICENSE + README, from msrbuilds
- wp-oxygen-elements — GPL-3.0, attribution LICENSE + README in folder, from Widdin
- wx-whatsapp-api — we write it, GPL-2.0-or-later, in `wx-whatsapp-api/`
- No paid plugins bundled (js_composer, filebird-pro, revslider never ship) — verified `ls wx-master/assets/bundled-plugins/` only shows agentbridge.zip, elementor-mcp.zip, wp-oxygen-elements/ (no paid)

**END**
