# BUNDLED LICENSES — Phase C (WhatsApp Live + Skin Import/Export)

**Date:** 2026-08-22
**Phase:** C — WhatsApp Live Client Engine + Skin Import/Export
**Free resources (exact sources from Phase C prompt):**

| What | Link | Status | License | Notes | Bundled |
|------|------|--------|---------|-------|---------|
| Meta WhatsApp Business Cloud API docs (reference) | https://developers.facebook.com/docs/whatsapp/cloud-api | Reference, no zip, docs only | Meta | Used for REST /wx-live/v1/send → https://graph.facebook.com/v19.0/{phone_id}/messages, reference for send/receive payload structure | No zip, reference only, link in plugin settings page |
| Meta webhook signature verification spec (reference) | https://developers.facebook.com/docs/graph-api/webhooks/getting-started | Reference, no zip, spec for X-Hub-Signature-256 HMAC-SHA256 | Meta | Implemented in rest_receive(): $signature = header X-Hub-Signature-256, $app_secret from encrypted option, $expected = 'sha256=' . hash_hmac('sha256', $payload, $app_secret) + hash_equals() verification, plus rest_webhook_verify() for hub_challenge | No zip, reference only, spec implemented |

No third-party SaaS, we write adapter ourselves (GPL, Author Woodex) — `wx-whatsapp-api/` original, 14KB, 655 lines (needs split but original)

**Verification:**

- Webhook signature verification logic matches Meta spec: HMAC-SHA256 + hash_equals, tested via simulated payload in /tmp/test_webhook.php — PASS (correct passes, tampered fails, wrong secret fails)
- No SaaS required — adapter writes directly to WhatsApp Cloud API via wp_remote_post, no third-party service

**Additional from Phase A/B still bundled (owned/GPL):**

- agentbridge.zip (ours, 24 tools) — owned, in inc/plugins/ + assets/bundled-plugins/, unzip -t PASS
- elementor-mcp.zip (EMCP Tools 200+ tools, GPL-2.0) — from main.zip fallback (release-assets fails SSL), unzip -t PASS, GPL-2.0 attribution
- wp-oxygen-elements (GPL-3.0) — Widdin, in assets/bundled-plugins/wp-oxygen-elements/ with LICENSE 35KB + README, gifs removed
- TGMPA library (GPL-2.0) — in inc/tgmpa/class-tgm-plugin-activation.php, unzip -t PASS

**No paid plugins bundled — PASS**

END
