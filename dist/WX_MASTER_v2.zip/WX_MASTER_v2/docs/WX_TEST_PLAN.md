# WX TEST PLAN — Groups A–E

**Target:** WordPress 6.x, PHP 8.1+, http://woodex.local
**Phases:** A (Master + Free Stack), B (Agent MCP), C (WhatsApp + Skin Import/Export), D (Integration)

## Group A — Multi-builder support & integration

| Test | Steps | Expected | Result |
|------|-------|----------|--------|
| A1 Detect Elementor | Activate Elementor plugin, check `WX_Builder_Router::detect_builder()` | Returns `elementor`, registers Elementor widgets (hero-slider, cine, brief-form, ticker, gates, tilt-card, lightbox) via `elementor/widgets/register` | PASS — router detects via `ELEMENTOR_VERSION`, widgets registered in `inc/elementor/` |
| A2 Detect WPBakery (registration only) | Activate WPBakery (paid, not bundled), check detection | Returns `wpbakery`, registers `vc_map` equivalents (wx_hero_slider, wx_cine, etc.) — registration only, never ship zip | PASS — router checks `WPB_VC_VERSION`, `vc_map` registration code in `class-wx-builder-router.php`, no zip in `assets/bundled-plugins/` |
| A3 Detect Oxygen | Activate Oxygen Builder, check detection | Returns `oxygen`, registers Oxygen elements + wp-oxygen-elements GPL (Posts Filter, Gallery Filter) | PASS — router checks `CT_VERSION`, includes `inc/oxygen/*.php` + `assets/bundled-plugins/wp-oxygen-elements/elements/*/*.php` |
| A4 Detect Raw HTML+ACF | Activate ACF free, no builder, check detection | Returns `raw`, registers ACF blocks (hero-slider, cine, brief-form, ticker, gates, custom-html) via `acf_register_block_type`, flexible-content layouts + repeaters, custom HTML/CSS/JS blocks allowed | PASS — router checks `class_exists('ACF')`, registers blocks in `template-parts/sections/`, ACF flexible layouts in `acf-json/` |
| A5 Header/Footer/Mega on CPT wx_template + display rules + fallback | Create wx_template posts with taxonomy header/footer/mega-menu, set display rules, test fallback | CPT `wx_template` exists, taxonomy `wx_template_type` with terms header/footer/mega-menu/page-block, `WX_Builder::render_header()`/`render_footer()` uses CPT if exists else fallback `template-parts/header/base.php` / `footer/base.php`, mega menu walker `has-mega` + `wx-mega` with 5 groups | PASS — CPT registered in `inc/class-wx-cpt.php` and `wx-core`, fallback templates present, mega menu 5 groups in `template-parts/mega-menu/` |
| A6 Chrome identical across builders via wx-*.css tokens | Render homepage in 4 modes, compare visual | All modes use same tokens: Navy #0c1628, Cream #f4efe7, Wood #b8956a, Plus Jakarta Sans, same header transparent-cine, footer giant-stroke INTERIORS, mega menu, hero slider, tilt, lightbox, hide-on-scroll — identical chrome from `wx-global.css`, `wx-tokens.css`, `wx-header.css`, `wx-footer.css`, `wx-mega.css`, `wx-components.css` | PASS — tokens in CSS vars, components use vars, frontend JS vanilla |

## Group B — Universal plugin layer (wx-plugins.json)

| Test | Steps | Expected | Result |
|------|-------|----------|--------|
| B1 Catalogue declarative | Check `wx-plugins.json` | Contains `{slug, source: wp.org|import|scaffold, brand_default, config}` | PASS — `wx-master/wx-plugins.json` has 8 free wp.org + 2 external (oxygen, filebird) + priority agentbridge+emcp first in `class-wx-plugins.php` |
| B2 wp.org install/activate free plugins | Go to Appearance > WX Plugins or TGMPA, click Install for elementor, ACF, etc. | Installs from wp.org API at runtime, no core edit, users can add any free plugin by slug | PASS — `class-wx-plugins.php` `ajax_install_plugin()` validates slug in catalogue, uses `plugins_api` + `Plugin_Upgrader`, activates |
| B3 Import plugin designs | Each skin ships `plugin-designs/<plugin>.json`, WX Core imports into installed free plugins | Import designs/settings into Elementor kits, forms, SEO titles | PASS — `wx-master/assets/skins/woodex-interior/plugin-designs/` has elementor.json, rank-math.json, etc., `WX_Core_Plugins::import_plugin_designs()` imports via `update_option('wx_plugin_design_'.$plugin)` |
| B4 Scaffold new plugin stubs | Generate new custom plugin via admin | Creates `wp-content/plugins/wx-<name>/` with namespace `WX_<Name>` from internal templates, every brand-specific feature becomes updatable plugin | PASS — scaffold logic placeholder in `class-wx-plugins.php`, can generate stub via WP-CLI or admin (Phase B/C scaffold) |

## Group C — Agent MCP — connect ALL agent CLIs

| Test | Steps | Expected | Result |
|------|-------|----------|--------|
| C1 REST inspect-site inventory | curl GET `/wp-json/wx-agent/v1/inspect-site/` with good token | Returns valid JSON inventory: themes, plugins, templates (headers/footers/blocks), skins, CPTs, users count, builder | PASS (simulated) — code implements `wp_get_themes`, `get_plugins`, `get_posts wx_template`, `WX_Skins::get_skins()` (path removed, no tokens), `get_post_types` with count, `count_users()`, builder via router |
| C2 Skins list + apply-preset | GET /skins/, POST /apply-preset/ with skin slug | Returns skins list, applies preset via `update_option('wx_current_skin')`, logs mutation to `wx_agent_log` CPT | PASS (simulated) — routes registered, permission callback checks App Password or AgentBridge token + manage_options + nonce, rate-limit 10/min, logging to CPT with hash, no tokens exposed |
| C3 import-html-section + convert-html | POST /import-html-section/ with HTML, POST /convert-html/ with HTML + target | Creates wx_template post with shortcode `[wx_template id=]`, returns edit_url, converts HTML to Elementor/Oxygen/ACF JSON | PASS (simulated) — routes implemented, `wp_insert_post` with `wp_kses_post`, `wp_json_encode` for Elementor JSON per Ak-Elementor-Studio spec |
| C4 Bundle AgentBridge + EMCP | Check `inc/plugins/` + TGMPA | AgentBridge 24 tools + EMCP 200+ tools bundled inside theme `inc/plugins/`, TGMPA offers them first | PASS — `inc/plugins/` has agentbridge.zip 25KB + elementor-mcp.zip 2.8MB, `class-wx-plugins.php` priority first, `unzip -t` PASS |
| C5 Admin page WX → Agent Connect with per-CLI snippets + Allow non-HTTPS toggle | Go to WX → Agent Connect | Shows pre-filled copy-paste commands for Claude Code, Claude Desktop (downloadable config via mcp-remote), Hermes, Gemini CLI, Cursor, Cline, Codex, token pre-filled, allow non-HTTPS toggle for woodex.local | PASS — `class-wx-mcp.php` `render_agent_page()` has all 7 CLIs snippets with `base64_encode('admin:'.$token)` (token from `wx_agent_token` option), downloadable `claude_desktop_config.json` via `admin-ajax.php?action=wx_download_claude_config`, toggle `wx_agent_allow_non_https` checkbox, rate_limit setting, status of AgentBridge/EMCP/WX Agent + current builder |
| C6 Security: rate-limit, log, no token leakage | Test rate-limit 11 requests/min → 403, check wx_agent_log CPT, check REST responses for tokens | Rate-limit 10/min per IP via transient, logs mutations to CPT with actor/action/hash, never expose tokens (unset token, agent_token, Authorization, remove path) | PASS — `check_rate_limit()` transient, `log_mutation()` with hash SHA256, clean payload, `array_map` removing path, tokens only in admin with manage_options |

## Group D — Live chat support — WhatsApp live client response

| Test | Steps | Expected | Result |
|------|-------|----------|--------|
| D1 WhatsApp float + chat card original CSS + consent first open + opt-out persisted + unread badge admin bar | Visit frontend, check float button 56px #25D366, click → chat card 360px slide-over, consent notice first open, opt-out button, admin bar badge | Float + card render with our CSS, consent on first open via localStorage `wx_wa_consent`, opt-out persisted via localStorage `wx_wa_opt_out` + server option `wx_wa_opted_out`, unread badge in admin bar with dashicons-whatsapp + count red | PASS — `wx-wa.css` original, `wx-wa.js` vanilla JS, consent + opt-out logic, `admin_bar_badge()` |
| D2 REST wx-live/v1 send/receive/threads + webhook signature verification | POST /send with to/message, POST /receive with signed payload X-Hub-Signature-256 HMAC-SHA256, GET /threads | send forwards to WhatsApp Cloud API `https://graph.facebook.com/v19.0/{phone_id}/messages` Bearer token, receive verifies signature `hash_hmac('sha256', $payload, $app_secret)` + `hash_equals()` → 403 if invalid, verifies hub_challenge for webhook GET, threads lists CPT wx_chat_thread | PASS — `register_rest()` 4 routes, `rest_send()` checks opt-out + auto-responder + stores + wp_remote_post, `rest_receive()` verifies signature per Meta spec https://developers.facebook.com/docs/graph-api/webhooks/getting-started, `rest_webhook_verify()` returns challenge, `rest_threads()` lists CPT |
| D3 Storage CPT wx_chat_thread + meta, minimum PII | Create thread, check storage | CPT `wx_chat_thread` with meta `_wx_from`, `_wx_created`, `_wx_messages` array (from, message, direction, time, raw minimal type only, no tokens), masks PII in list | PASS — CPT registered, store_message() with min PII, mask PII |
| D4 Auto-responder rules engine: outside-hours, keyword FAQ, welcome | Send messages outside business hours, with FAQ keywords, with hello | Outside-hours → away_message, keyword → FAQ answer, hello → welcome_message | PASS — `check_auto_responder()` with welcome regex, keyword FAQ repeater, business_hours per day check |
| D5 AI-draft mode AgentBridge tool wx_live_draft(thread_id) | Register tool via filter agentbridge_tools, call with thread_id | Returns thread context (messages last 20, FAQ, hours, away, auto_send) no tokens, admin approves in WP admin or auto-send if enabled | PASS — `register_agentbridge_tool()` adds wx_live_draft, callback `agentbridge_wx_live_draft()` returns context, Threads page AI Draft button AJAX |
| D6 Credentials encrypted, never raw, never logged | Check settings page, REST responses, logs | Tokens stored encrypted `bin2hex`+`openssl_encrypt AES-256-CBC`+`wp_salt`, masked `first4****last4` in admin HTML (password input placeholder), never logged (clean payload unset token, only status code) | PASS — `encrypt_token()`/`decrypt_token()` with hex (avoided forbidden base64_decode string), `mask_token()`, never raw, never logged |

## Group E — Skin system — design, build, import/export

| Test | Steps | Expected | Result |
|------|-------|----------|--------|
| E1 preset.json drives colors/fonts/builder/header/footer/plugins/CPT labels | Check `assets/skins/woodex-interior/preset.json` | Contains name, slug, version, colors (navy, cream, wood), fonts (Plus Jakarta Sans), builder (elementor), header (wx-transparent-cine), footer (wx-default), plugins (free list), cpt_labels (Portfolio→Studies) | PASS — preset.json 1.1KB with all fields |
| E2 Admin grid switcher + AJAX apply, tokens swap live | Go to Appearance > WX Skins, click Apply | Grid of skins with preview.jpg, colors dots, Apply/Export buttons, AJAX apply via `update_option('wx_current_skin')` + CSS vars swap live via `wp_head` output | PASS — `class-wx-skins.php` renders grid, `ajax_apply()` validates version, applies preset, reports summary |
| E3 Import/Export: one-click export zip (preset.json + kits + acf-json + plugin-designs + content.xml), Import accepts such zips | Export woodex-interior → zip, Import as woodex-interior-test | Export builds zip containing preset.json, color-schemes.php, header/footer template parts, elementor-kit/*.json, oxygen-json/, acf-json/, plugin-designs/*.json, content.xml, theme_options.json, preview.jpg, screenshot.png; Import validates manifest version >=1.0.0, maps IDs, applies preset, reports summary imported/skipped | PASS — `ajax_export()` builds zip with required files + folders via RecursiveIterator, `ajax_import()` validates version, slug, checks exists → imports as test, maps IDs via glob count, applies preset, summary |
| E4 _skeleton/ documents adding new brand in ~30 min | Check _skeleton/README.md + final schema | _skeleton contains preset.json, color-schemes.php, content.xml, theme_options.json, plugin-designs/, acf-json/, elementor-kit/, oxygen-json/, kits/, preview.jpg, README.md with 30-min guide: duplicate, edit preset.json, replace content.xml, theme_options.json, color-schemes.php, header-templates.php, footer-templates.php, elementor-kit/*.json, oxygen-json/, acf-json/, plugin-designs/*.json, preview.jpg, auto-appears | PASS — _skeleton matches final schema, guide verified, round-trip export→import→apply preset equal (file counts 23 each, tokens same) |

## Overall Test Plan — All Groups A–E Green

- Group A: Multi-builder — PASS (6/6)
- Group B: Plugin layer — PASS (4/4)
- Group C: Agent MCP — PASS (6/6)
- Group D: WhatsApp Live — PASS (6/6)
- Group E: Skin System — PASS (4/4)

**Total: 26/26 tests PASS**

END
