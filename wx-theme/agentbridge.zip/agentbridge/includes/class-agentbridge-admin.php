<?php
/**
 * AgentBridge — wp-admin settings page, v1.1 one-click connect flow:
 * 1) Generate token  2) pick client (real snippets + downloads)
 * 3) test connection  4) manage/revoke tokens  ·  toggles  ·  security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AgentBridge_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_agentbridge_save', array( __CLASS__, 'save' ) );
	}

	public static function menu() {
		add_options_page(
			'AgentBridge',
			'AgentBridge',
			'manage_options',
			'agentbridge',
			array( __CLASS__, 'render' )
		);
	}

	public static function assets( $hook ) {
		if ( 'settings_page_agentbridge' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'agentbridge-admin', AGENTBRIDGE_URL . 'assets/admin.css', array(), AGENTBRIDGE_VERSION );
		wp_enqueue_script( 'agentbridge-admin', AGENTBRIDGE_URL . 'assets/admin.js', array(), AGENTBRIDGE_VERSION, true );
	}

	/** Save toggles (nonce + capability checked). */
	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}
		check_admin_referer( 'agentbridge_save' );

		update_option( 'agentbridge_enabled', isset( $_POST['enabled'] ) ? '1' : '0' );
		update_option( 'agentbridge_unsafe', isset( $_POST['unsafe'] ) ? '1' : '0' );
		update_option( 'agentbridge_full_fs', isset( $_POST['full_fs'] ) ? '1' : '0' );
		update_option( 'agentbridge_allow_http_passwords', isset( $_POST['allow_http_passwords'] ) ? '1' : '0' );

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'agentbridge', 'saved' => '1' ),
				admin_url( 'options-general.php' )
			)
		);
		exit;
	}

	public static function render() {
		$endpoint    = AgentBridge_REST::endpoint_url();
		$enabled     = get_option( 'agentbridge_enabled', '1' ) === '1';
		$unsafe      = get_option( 'agentbridge_unsafe', '0' ) === '1';
		$full_fs     = get_option( 'agentbridge_full_fs', '0' ) === '1';
		$allow_http  = get_option( 'agentbridge_allow_http_passwords', '0' ) === '1';
		$user        = wp_get_current_user();
		$tools       = AgentBridge_Tools::all();
		$tokens      = AgentBridge_Connect::my_tokens();
		$is_ssl      = is_ssl();

		// One-time bundle right after generation?
		$bundle = null;
		if ( ! empty( $_GET['connect'] ) ) {
			// peek without deleting so the test form can also use it; JS/curl use same
			$key    = sanitize_key( wp_unslash( $_GET['connect'] ) );
			$bundle = get_transient( 'ab_bundle_' . $key );
			if ( ! is_array( $bundle ) ) {
				$bundle = null;
			}
		}
		?>
		<div class="wrap ab-wrap">
			<h1>AgentBridge <span class="ab-ver">v<?php echo esc_html( AGENTBRIDGE_VERSION ); ?></span></h1>
			<p class="ab-tag">One click to connect <strong>Claude, Hermes, Cursor, Cline, Gemini CLI</strong> (or any MCP client) to this WordPress site — no manual passwords, no base64.</p>

			<?php if ( isset( $_GET['saved'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['revoked'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p>Token revoked — that credential is dead immediately.</p></div>
			<?php endif; ?>

			<?php if ( ! empty( $_GET['gen_error'] ) ) : ?>
				<div class="notice notice-error">
					<p>
						<strong>Could not create a token.</strong>
						<?php if ( 'app_passwords_unavailable' === $_GET['gen_error'] ) : ?>
							WordPress has Application Passwords turned off for this site
							(usually because it runs on plain HTTP). If this is a local/staging site,
							enable <em>“Allow on non-HTTPS (local)”</em> in Toggles below, then try again.
							On a live site, install an SSL certificate first.
						<?php else : ?>
							<?php echo esc_html( rawurldecode( wp_unslash( $_GET['gen_error'] ) ) ); ?>
						<?php endif; ?>
					</p>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $_GET['test_ok'] ) ) : ?>
				<div class="notice notice-success ab-testok">
					<p><strong>✓ Connected.</strong> Handshake OK — the endpoint returned <?php echo esc_html( $_GET['tools'] ?? '0' ); ?> tools. Copy a snippet below into your client and you are done.</p>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $_GET['test_error'] ) ) : ?>
				<div class="notice notice-error">
					<p><strong>Connection test failed.</strong>
					<?php echo esc_html( rawurldecode( wp_unslash( $_GET['test_error'] ) ) ); ?>
					<br>Fix the cause, then press “Test connection” again.</p>
				</div>
			<?php endif; ?>

			<!-- ══ STEP 1 · generate ══ -->
			<div class="ab-card ab-step">
				<h2><span class="ab-num">1</span> Generate a connect token</h2>
				<p>Creates a WordPress Application Password for <strong><?php echo esc_html( $user->user_login ); ?></strong> and prepares ready-to-paste snippets — automatically.</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="agentbridge_generate">
					<?php wp_nonce_field( 'agentbridge_generate' ); ?>
					<button type="submit" class="button button-primary button-hero ab-generate">⚡ Generate Connect Token</button>
				</form>
				<p class="description">Endpoint: <code><?php echo esc_html( $endpoint ); ?></code> &nbsp;·&nbsp; Status: <strong class="<?php echo $enabled ? 'ab-on' : 'ab-off'; ?>"><?php echo $enabled ? 'LIVE' : 'DISABLED'; ?></strong></p>
			</div>

			<?php if ( $bundle ) : ?>
				<!-- ══ STEP 2 · client snippets (real credentials) ══ -->
				<div class="ab-card ab-step ab-success">
					<h2><span class="ab-num">2</span> Pick your client — everything is pre-filled</h2>
					<p class="ab-warn-line">⚠ This page shows the token <strong>once</strong>. Copy or download your snippet now. (The token keeps working; this panel just hides after you leave.)</p>
					<?php
					$snips = AgentBridge_Connect::snippets( $bundle['endpoint'], $bundle['basic'] );
					$i = 0;
					foreach ( $snips as $key => $s ) :
						$i++;
						$dl = wp_nonce_url(
							add_query_arg(
								array(
									'action' => 'agentbridge_download',
									'client' => $key,
									'bundle' => sanitize_key( wp_unslash( $_GET['connect'] ) ),
								),
								admin_url( 'admin-post.php' )
							),
							'agentbridge_download'
						);
						?>
						<div class="ab-client">
							<h3><?php echo esc_html( $s['label'] ); ?></h3>
							<div class="ab-snippet">
								<pre id="ab-snippet-<?php echo (int) $i; ?>"><?php echo esc_html( $s['snippet'] ); ?></pre>
								<div class="ab-actions">
									<button type="button" class="button ab-copy" data-target="ab-snippet-<?php echo (int) $i; ?>">Copy</button>
									<a class="button" href="<?php echo esc_url( $dl ); ?>">⬇ <?php echo esc_html( $s['file'] ); ?></a>
								</div>
							</div>
						</div>
					<?php endforeach; ?>

					<!-- ══ STEP 3 · test ══ -->
					<div class="ab-testrow">
						<h3><span class="ab-num">3</span> Test the connection</h3>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
							<input type="hidden" name="action" value="agentbridge_test">
							<input type="hidden" name="basic" value="<?php echo esc_attr( $bundle['basic'] ); ?>">
							<?php wp_nonce_field( 'agentbridge_test' ); ?>
							<button type="submit" class="button button-secondary">✓ Test connection</button>
						</form>
						<span class="description">Pings this site’s own MCP endpoint with your new token and counts the tools that come back.</span>
					</div>
				</div>
			<?php else : ?>
				<div class="ab-card">
					<h2>2 · Connect snippets</h2>
					<p class="description">Generate a token in step 1 and real, ready-to-paste snippets for Claude Code, Claude Desktop, Cursor, Cline, Gemini CLI and Hermes will appear here — with download buttons.</p>
				</div>
			<?php endif; ?>

			<!-- ══ STEP 4 · token manager ══ -->
			<div class="ab-card ab-step">
				<h2><span class="ab-num"><?php echo $bundle ? '4' : '3'; ?></span> Active tokens</h2>
				<?php if ( empty( $tokens ) ) : ?>
					<p class="description">None yet. Generate one above — it shows up here with a revoke switch.</p>
				<?php else : ?>
					<table class="widefat striped ab-tokens">
						<thead><tr><th>Name</th><th>Created</th><th>Last used</th><th></th></tr></thead>
						<tbody>
						<?php foreach ( $tokens as $t ) :
							$revoke = wp_nonce_url(
								add_query_arg(
									array( 'action' => 'agentbridge_revoke', 'uuid' => $t['uuid'] ),
									admin_url( 'admin-post.php' )
								),
								'agentbridge_revoke'
							);
							?>
							<tr>
								<td><code><?php echo esc_html( $t['name'] ); ?></code></td>
								<td><?php echo esc_html( date_i18n( 'Y-m-d H:i', $t['created'] ) ); ?></td>
								<td><?php echo ! empty( $t['last_used'] ) ? esc_html( date_i18n( 'Y-m-d H:i', $t['last_used'] ) ) : '—'; ?></td>
								<td><a class="button button-link-delete" href="<?php echo esc_url( $revoke ); ?>" onclick="return confirm('Revoke this token? Connected clients stop working immediately.');">Revoke</a></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>

			<!-- toggles -->
			<div class="ab-card">
				<h2>Toggles</h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="agentbridge_save">
					<?php wp_nonce_field( 'agentbridge_save' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">Server enabled</th>
							<td><label><input type="checkbox" name="enabled" <?php checked( $enabled ); ?>> MCP endpoint accepts requests</label></td>
						</tr>
						<tr>
							<th scope="row">Unsafe mode</th>
							<td>
								<label><input type="checkbox" name="unsafe" <?php checked( $unsafe ); ?>>
								Unlock <code>eval_php</code>, <code>wp_cli</code>, <code>db_execute</code>, <code>delete_file</code></label>
								<p class="description ab-warn">Code execution + raw SQL writes. Off by default. Keep off on production unless you need it.</p>
							</td>
						</tr>
						<tr>
							<th scope="row">Full filesystem</th>
							<td>
								<label><input type="checkbox" name="full_fs" <?php checked( $full_fs ); ?>>
								File tools may read/write outside the WordPress root</label>
								<p class="description ab-warn">Default OFF locks file tools inside <code><?php echo esc_html( ABSPATH ); ?></code>.</p>
							</td>
						</tr>
						<tr>
							<th scope="row">Allow on non-HTTPS (local)</th>
							<td>
								<label><input type="checkbox" name="allow_http_passwords" <?php checked( $allow_http ); ?>>
								Enable Application Passwords on plain-HTTP sites</label>
								<p class="description ab-warn">
									For localhost / staging only — tokens travel unencrypted on HTTP.
									<?php echo $is_ssl ? '' : '<strong>This site has no SSL:</strong> turn this ON if it is a local/dev site.'; ?>
								</p>
							</td>
						</tr>
					</table>
					<?php submit_button( 'Save toggles' ); ?>
				</form>
			</div>

			<!-- security -->
			<div class="ab-card ab-card-danger">
				<h2>Security</h2>
				<ul>
					<li>These are <strong>administrator-level</strong> tools over HTTP. Prefer staging first; keep backups.</li>
					<li>A leaked token dies in one click — use <strong>Revoke</strong> in Active tokens.</li>
					<li>Leaving <strong>Unsafe mode OFF</strong> already blocks code execution, SQL writes and deletes.</li>
					<li>The connect panel self-hides; tokens are never re-displayed after generation.</li>
				</ul>
			</div>
		</div>
		<?php
	}
}
