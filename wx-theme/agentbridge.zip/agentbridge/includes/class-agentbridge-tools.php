<?php
/**
 * AgentBridge — the 24 MCP tools.
 *
 * Every handler returns a plain PHP value; AgentBridge_Tools::call()
 * wraps it in the MCP content envelope. Throws AgentBridge_Tool_Error
 * for client-visible failures.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AgentBridge_Tool_Error extends Exception {}

class AgentBridge_Tools {

	/* ------------------------------------------------ tools registry */

	public static function all() {
		return array(
			/* -------- info -------- */
			'site_info'       => array(
				'description' => 'WordPress site overview: versions, URL, active theme, counts, this plugin.',
				'schema'      => self::obj( array(), array() ),
			),

			/* -------- content -------- */
			'list_posts'      => array(
				'description' => 'List posts/pages/CPTs. Args: post_type (default "any"), status (default "any"), search, limit (max 100, default 20), offset.',
				'schema'      => self::obj(
					array(
						'post_type' => array( 'type' => 'string' ),
						'status'    => array( 'type' => 'string' ),
						'search'    => array( 'type' => 'string' ),
						'limit'     => array( 'type' => 'integer' ),
						'offset'    => array( 'type' => 'integer' ),
					),
					array()
				),
			),
			'get_post'        => array(
				'description' => 'Get one post by ID — full content, meta, taxonomies.',
				'schema'      => self::obj( array( 'id' => array( 'type' => 'integer' ) ), array( 'id' ) ),
			),
			'create_post'     => array(
				'description' => 'Create a post/page/CPT item. Args: title (required), content, post_type (default "post"), status (default "draft"), slug, excerpt.',
				'schema'      => self::obj(
					array(
						'title'     => array( 'type' => 'string' ),
						'content'   => array( 'type' => 'string' ),
						'post_type' => array( 'type' => 'string' ),
						'status'    => array( 'type' => 'string' ),
						'slug'      => array( 'type' => 'string' ),
						'excerpt'   => array( 'type' => 'string' ),
					),
					array( 'title' )
				),
			),
			'update_post'     => array(
				'description' => 'Update fields of an existing post. Args: id (required) + any of title, content, status, slug, excerpt.',
				'schema'      => self::obj(
					array(
						'id'      => array( 'type' => 'integer' ),
						'title'   => array( 'type' => 'string' ),
						'content' => array( 'type' => 'string' ),
						'status'  => array( 'type' => 'string' ),
						'slug'    => array( 'type' => 'string' ),
						'excerpt' => array( 'type' => 'string' ),
					),
					array( 'id' )
				),
			),
			'delete_post'     => array(
				'description' => 'Trash or permanently delete a post. Args: id (required), force (default false = trash).',
				'schema'      => self::obj(
					array(
						'id'    => array( 'type' => 'integer' ),
						'force' => array( 'type' => 'boolean' ),
					),
					array( 'id' )
				),
			),

			/* -------- menus -------- */
			'list_menus'      => array(
				'description' => 'List navigation menus with their items and theme locations.',
				'schema'      => self::obj( array(), array() ),
			),
			'add_menu_item'   => array(
				'description' => 'Add an item to a menu. Args: menu_id (required), title (required), url OR object_id+object(post|page|category), parent_id, position.',
				'schema'      => self::obj(
					array(
						'menu_id'   => array( 'type' => 'integer' ),
						'title'     => array( 'type' => 'string' ),
						'url'       => array( 'type' => 'string' ),
						'object_id' => array( 'type' => 'integer' ),
						'object'    => array( 'type' => 'string' ),
						'parent_id' => array( 'type' => 'integer' ),
						'position'  => array( 'type' => 'integer' ),
					),
					array( 'menu_id', 'title' )
				),
			),

			/* -------- media -------- */
			'list_media'      => array(
				'description' => 'List media library items. Args: search, limit (default 20), mime (e.g. "image").',
				'schema'      => self::obj(
					array(
						'search' => array( 'type' => 'string' ),
						'limit'  => array( 'type' => 'integer' ),
						'mime'   => array( 'type' => 'string' ),
					),
					array()
				),
			),
			'upload_media'    => array(
				'description' => 'Upload a file to the media library from base64. Args: filename (required), data_base64 (required), title, alt.',
				'schema'      => self::obj(
					array(
						'filename'    => array( 'type' => 'string' ),
						'data_base64' => array( 'type' => 'string' ),
						'title'       => array( 'type' => 'string' ),
						'alt'         => array( 'type' => 'string' ),
					),
					array( 'filename', 'data_base64' )
				),
			),

			/* -------- options -------- */
			'get_option'      => array(
				'description' => 'Read a WordPress option. Args: name (required).',
				'schema'      => self::obj( array( 'name' => array( 'type' => 'string' ) ), array( 'name' ) ),
			),
			'update_option'   => array(
				'description' => 'Create or update a WordPress option (strings/numbers/bools; JSON string for arrays). Args: name (required), value (required).',
				'schema'      => self::obj(
					array(
						'name'  => array( 'type' => 'string' ),
						'value' => array( 'type' => array( 'string', 'number', 'boolean' ) ),
					),
					array( 'name', 'value' )
				),
			),

			/* -------- plugins -------- */
			'list_plugins'    => array(
				'description' => 'List installed plugins with version and active state.',
				'schema'      => self::obj( array(), array() ),
			),
			'activate_plugin' => array(
				'description' => 'Activate a plugin. Args: plugin (required) — e.g. "akismet/akismet.php".',
				'schema'      => self::obj( array( 'plugin' => array( 'type' => 'string' ) ), array( 'plugin' ) ),
			),
			'deactivate_plugin' => array(
				'description' => 'Deactivate a plugin. Args: plugin (required). AgentBridge itself cannot be deactivated this way.',
				'schema'      => self::obj( array( 'plugin' => array( 'type' => 'string' ) ), array( 'plugin' ) ),
			),

			/* -------- themes -------- */
			'list_themes'     => array(
				'description' => 'List installed themes with version and active flag.',
				'schema'      => self::obj( array(), array() ),
			),
			'switch_theme'    => array(
				'description' => 'Switch the active theme. Args: stylesheet (required) — e.g. "twentytwentyfour".',
				'schema'      => self::obj( array( 'stylesheet' => array( 'type' => 'string' ) ), array( 'stylesheet' ) ),
			),

			/* -------- files -------- */
			'read_file'       => array(
				'description' => 'Read a file inside the WordPress root (entire filesystem if "Full filesystem" is on). Args: path (required, relative to WP root or absolute), offset, length.',
				'schema'      => self::obj(
					array(
						'path'   => array( 'type' => 'string' ),
						'offset' => array( 'type' => 'integer' ),
						'length' => array( 'type' => 'integer' ),
					),
					array( 'path' )
				),
			),
			'write_file'      => array(
				'description' => 'Write a file in the WordPress root (creates dirs). Args: path (required), content (required), mode ("rewrite" default | "append").',
				'schema'      => self::obj(
					array(
						'path'    => array( 'type' => 'string' ),
						'content' => array( 'type' => 'string' ),
						'mode'    => array( 'type' => 'string' ),
					),
					array( 'path', 'content' )
				),
			),
			'delete_file'     => array(
				'description' => 'UNSAFE-MODE TOOL. Delete a file or empty directory. Args: path (required).',
				'unsafe'      => true,
				'schema'      => self::obj( array( 'path' => array( 'type' => 'string' ) ), array( 'path' ) ),
			),

			/* -------- code -------- */
			'eval_php'        => array(
				'description' => 'UNSAFE-MODE TOOL. Execute PHP in WordPress context. Args: code (required). Returns output + return value.',
				'unsafe'      => true,
				'schema'      => self::obj( array( 'code' => array( 'type' => 'string' ) ), array( 'code' ) ),
			),
			'wp_cli'          => array(
				'description' => 'UNSAFE-MODE TOOL. Run a WP-CLI command (binary must exist). Args: command (required) — e.g. "plugin list". Requires shell access enabled in PHP.',
				'unsafe'      => true,
				'schema'      => self::obj( array( 'command' => array( 'type' => 'string' ) ), array( 'command' ) ),
			),

			/* -------- database -------- */
			'db_query'        => array(
				'description' => 'Read-only SQL: SELECT / SHOW / DESCRIBE / EXPLAIN (auto LIMIT 500). Args: query (required).',
				'schema'      => self::obj( array( 'query' => array( 'type' => 'string' ) ), array( 'query' ) ),
			),
			'db_execute'      => array(
				'description' => 'UNSAFE-MODE TOOL. Run any SQL statement (INSERT/UPDATE/DELETE/DDL). Args: query (required). Returns rows affected.',
				'unsafe'      => true,
				'schema'      => self::obj( array( 'query' => array( 'type' => 'string' ) ), array( 'query' ) ),
			),
		);
	}

	/* ------------------------------------------------ dispatcher */

	public static function call( $name, $args ) {
		$tools = self::all();

		if ( ! isset( $tools[ $name ] ) ) {
			return self::wrap_error( 'Unknown tool: "' . $name . '". Use tools/list for the catalog.' );
		}

		$tool = $tools[ $name ];

		if ( ! empty( $tool['unsafe'] ) && get_option( 'agentbridge_unsafe', '0' ) !== '1' ) {
			return self::wrap_error(
				'Tool "' . $name . '" needs Unsafe mode. Enable it in wp-admin → AgentBridge → Toggles (off by default for a reason).'
			);
		}

		$missing = array();
		foreach ( $tool['schema']['required'] as $req ) {
			if ( ! array_key_exists( $req, $args ) ) {
				$missing[] = $req;
			}
		}
		if ( $missing ) {
			return self::wrap_error( 'Missing required argument(s): ' . implode( ', ', $missing ) );
		}

		try {
			$method = 'tool_' . $name;
			$data   = self::$method( $args );
			return array(
				'content' => array(
					array(
						'type' => 'text',
						'text' => is_string( $data ) ? $data : wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ),
					),
				),
			);
		} catch ( AgentBridge_Tool_Error $e ) {
			return self::wrap_error( $e->getMessage() );
		} catch ( Throwable $e ) {
			return self::wrap_error( get_class( $e ) . ': ' . $e->getMessage() );
		}
	}

	private static function wrap_error( $msg ) {
		return array(
			'content' => array( array( 'type' => 'text', 'text' => 'AgentBridge error: ' . $msg ) ),
			'isError' => true,
		);
	}

	private static function obj( $props, $required ) {
		return array(
			'type'                 => 'object',
			'properties'           => (object) $props,
			'required'             => $required,
			'additionalProperties' => false,
		);
	}

	/* ------------------------------------------------ path safety */

	/**
	 * Resolve a path against the WP root; block escapes unless Full filesystem.
	 */
	private static function safe_path( $raw ) {
		$raw = str_replace( '\\', '/', (string) $raw );
		if ( $raw === '' ) {
			throw new AgentBridge_Tool_Error( 'Empty path.' );
		}

		$root      = str_replace( '\\', '/', ABSPATH );
		$full_fs   = get_option( 'agentbridge_full_fs', '0' ) === '1';
		$is_abs    = ( strpos( $raw, '/' ) === 0 ) || preg_match( '#^[A-Za-z]:/#', $raw );
		$candidate = $is_abs ? $raw : $root . ltrim( $raw, '/' );

		// normalize . and ..
		$parts = array();
		foreach ( explode( '/', $candidate ) as $seg ) {
			if ( $seg === '' || $seg === '.' ) {
				continue;
			}
			if ( $seg === '..' ) {
				array_pop( $parts );
				continue;
			}
			$parts[] = $seg;
		}
		$resolved = ( preg_match( '#^[A-Za-z]:#', $candidate ) ? '' : '/' ) . implode( '/', $parts );

		if ( ! $full_fs && strpos( $resolved, rtrim( $root, '/' ) ) !== 0 ) {
			throw new AgentBridge_Tool_Error(
				'Path "' . $resolved . '" is outside the WordPress root. Enable "Full filesystem" in AgentBridge settings to allow it.'
			);
		}
		return $resolved;
	}

	/* ------------------------------------------------ INFO */

	protected static function tool_site_info() {
		return array(
			'site'          => get_bloginfo( 'name' ),
			'url'           => home_url(),
			'wp_version'    => get_bloginfo( 'version' ),
			'php_version'   => phpversion(),
			'multisite'     => is_multisite(),
			'active_theme'  => get_stylesheet(),
			'posts'         => (int) wp_count_posts( 'post' )->publish,
			'pages'         => (int) wp_count_posts( 'page' )->publish,
			'active_plugins'=> count( (array) get_option( 'active_plugins' ) ),
			'agentbridge'   => AGENTBRIDGE_VERSION,
			'unsafe_mode'   => get_option( 'agentbridge_unsafe', '0' ) === '1',
		);
	}

	/* ------------------------------------------------ CONTENT */

	protected static function tool_list_posts( $a ) {
		$limit = min( 100, max( 1, (int) ( $a['limit'] ?? 20 ) ) );
		$q     = new WP_Query(
			array(
				'post_type'      => $a['post_type'] ?? 'any',
				'post_status'    => $a['status'] ?? 'any',
				's'              => $a['search'] ?? '',
				'posts_per_page' => $limit,
				'offset'         => max( 0, (int) ( $a['offset'] ?? 0 ) ),
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);
		$out = array();
		foreach ( $q->posts as $p ) {
			$out[] = array(
				'id'       => $p->ID,
				'title'    => $p->post_title,
				'type'     => $p->post_type,
				'status'   => $p->post_status,
				'slug'     => $p->post_name,
				'modified' => $p->post_modified,
				'link'     => get_permalink( $p ),
			);
		}
		return array( 'count' => count( $out ), 'total_found' => (int) $q->found_posts, 'posts' => $out );
	}

	protected static function tool_get_post( $a ) {
		$p = get_post( (int) $a['id'] );
		if ( ! $p ) {
			throw new AgentBridge_Tool_Error( 'Post not found: ' . (int) $a['id'] );
		}
		return array(
			'id'         => $p->ID,
			'title'      => $p->post_title,
			'content'    => $p->post_content,
			'excerpt'    => $p->post_excerpt,
			'type'       => $p->post_type,
			'status'     => $p->post_status,
			'slug'       => $p->post_name,
			'author'     => (int) $p->post_author,
			'date'       => $p->post_date,
			'modified'   => $p->post_modified,
			'link'       => get_permalink( $p ),
			'meta'       => get_post_meta( $p->ID ),
			'taxonomies' => wp_get_post_taxonomies( $p->ID, 'names' ),
		);
	}

	protected static function tool_create_post( $a ) {
		$id = wp_insert_post(
			array(
				'post_title'   => $a['title'],
				'post_content' => $a['content'] ?? '',
				'post_type'    => $a['post_type'] ?? 'post',
				'post_status'  => $a['status'] ?? 'draft',
				'post_name'    => $a['slug'] ?? '',
				'post_excerpt' => $a['excerpt'] ?? '',
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			throw new AgentBridge_Tool_Error( $id->get_error_message() );
		}
		return array( 'id' => $id, 'link' => get_permalink( $id ), 'status' => get_post_status( $id ) );
	}

	protected static function tool_update_post( $a ) {
		$id = (int) $a['id'];
		if ( ! get_post( $id ) ) {
			throw new AgentBridge_Tool_Error( 'Post not found: ' . $id );
		}
		$fields = array( 'ID' => $id );
		$map    = array(
			'title'   => 'post_title',
			'content' => 'post_content',
			'status'  => 'post_status',
			'slug'    => 'post_name',
			'excerpt' => 'post_excerpt',
		);
		foreach ( $map as $arg => $col ) {
			if ( array_key_exists( $arg, $a ) ) {
				$fields[ $col ] = $a[ $arg ];
			}
		}
		$done = wp_update_post( $fields, true );
		if ( is_wp_error( $done ) ) {
			throw new AgentBridge_Tool_Error( $done->get_error_message() );
		}
		return array( 'id' => $id, 'updated' => array_keys( $fields ), 'link' => get_permalink( $id ) );
	}

	protected static function tool_delete_post( $a ) {
		$id = (int) $a['id'];
		if ( ! get_post( $id ) ) {
			throw new AgentBridge_Tool_Error( 'Post not found: ' . $id );
		}
		$force = ! empty( $a['force'] );
		$gone  = wp_delete_post( $id, $force );
		if ( ! $gone ) {
			throw new AgentBridge_Tool_Error( 'Delete failed for post ' . $id );
		}
		return array( 'id' => $id, 'deleted' => true, 'permanent' => $force );
	}

	/* ------------------------------------------------ MENUS */

	protected static function tool_list_menus() {
		$menus = wp_get_nav_menus();
		$out   = array();
		foreach ( $menus as $m ) {
			$items = wp_get_nav_menu_items( $m->term_id );
			$list  = array();
			if ( is_array( $items ) ) {
				foreach ( $items as $it ) {
					$list[] = array(
						'id'     => $it->ID,
						'title'  => $it->title,
						'url'    => $it->url,
						'parent' => (int) $it->menu_item_parent,
					);
				}
			}
			$out[] = array(
				'id'    => $m->term_id,
				'name'  => $m->name,
				'slug'  => $m->slug,
				'items' => $list,
			);
		}
		return array(
			'menus'     => $out,
			'locations' => get_nav_menu_locations(),
		);
	}

	protected static function tool_add_menu_item( $a ) {
		$menu = wp_get_nav_menu_object( (int) $a['menu_id'] );
		if ( ! $menu ) {
			throw new AgentBridge_Tool_Error( 'Menu not found: ' . (int) $a['menu_id'] );
		}
		$item = array(
			'menu-item-title'    => $a['title'],
			'menu-item-status'   => 'publish',
			'menu-item-parent-id'=> (int) ( $a['parent_id'] ?? 0 ),
			'menu-item-position' => (int) ( $a['position'] ?? 0 ),
		);
		if ( ! empty( $a['object_id'] ) && ! empty( $a['object'] ) ) {
			$item['menu-item-type']      = 'post_type';
			$item['menu-item-object']    = $a['object'];
			$item['menu-item-object-id'] = (int) $a['object_id'];
		} else {
			$item['menu-item-type'] = 'custom';
			$item['menu-item-url']  = $a['url'] ?? '#';
		}
		$id = wp_update_nav_menu_item( (int) $a['menu_id'], 0, $item );
		if ( is_wp_error( $id ) ) {
			throw new AgentBridge_Tool_Error( $id->get_error_message() );
		}
		return array( 'menu_item_id' => $id, 'menu' => $menu->name );
	}

	/* ------------------------------------------------ MEDIA */

	protected static function tool_list_media( $a ) {
		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => min( 100, max( 1, (int) ( $a['limit'] ?? 20 ) ) ),
			's'              => $a['search'] ?? '',
		);
		if ( ! empty( $a['mime'] ) ) {
			$args['post_mime_type'] = $a['mime'];
		}
		$q   = new WP_Query( $args );
		$out = array();
		foreach ( $q->posts as $p ) {
			$out[] = array(
				'id'    => $p->ID,
				'title' => $p->post_title,
				'mime'  => $p->post_mime_type,
				'url'   => wp_get_attachment_url( $p->ID ),
			);
		}
		return array( 'count' => count( $out ), 'media' => $out );
	}

	protected static function tool_upload_media( $a ) {
		$binary = base64_decode( $a['data_base64'], true );
		if ( false === $binary ) {
			throw new AgentBridge_Tool_Error( 'data_base64 is not valid base64.' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$upload = wp_upload_bits( sanitize_file_name( $a['filename'] ), null, $binary );
		if ( ! empty( $upload['error'] ) ) {
			throw new AgentBridge_Tool_Error( 'Upload failed: ' . $upload['error'] );
		}
		$mime = wp_check_filetype( $upload['file'] );
		$id   = wp_insert_attachment(
			array(
				'post_mime_type' => $mime['type'] ? $mime['type'] : 'application/octet-stream',
				'post_title'     => $a['title'] ?? preg_replace( '/\.[^.]+$/', '', $a['filename'] ),
				'post_status'    => 'inherit',
			),
			$upload['file']
		);
		if ( is_wp_error( $id ) || ! $id ) {
			throw new AgentBridge_Tool_Error( 'Could not create attachment.' );
		}
		wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
		if ( ! empty( $a['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', $a['alt'] );
		}
		return array( 'id' => $id, 'url' => wp_get_attachment_url( $id ) );
	}

	/* ------------------------------------------------ OPTIONS */

	protected static function tool_get_option( $a ) {
		$value = get_option( $a['name'], '__AGENTBRIDGE_MISSING__' );
		if ( '__AGENTBRIDGE_MISSING__' === $value ) {
			throw new AgentBridge_Tool_Error( 'Option does not exist: ' . $a['name'] );
		}
		if ( is_array( $value ) || is_object( $value ) ) {
			$value = wp_json_encode( $value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		}
		return array( 'name' => $a['name'], 'value' => $value );
	}

	protected static function tool_update_option( $a ) {
		$name  = $a['name'];
		$value = $a['value'];
		if ( is_string( $value ) ) {
			$trim = trim( $value );
			if ( ( strpos( $trim, '{' ) === 0 ) || ( strpos( $trim, '[' ) === 0 ) ) {
				$decoded = json_decode( $trim, true );
				if ( JSON_ERROR_NONE === json_last_error() ) {
					$value = $decoded;
				}
			}
		}
		$updated = update_option( $name, $value );
		return array(
			'name'    => $name,
			'updated' => $updated,
			'note'    => $updated ? 'Value changed.' : 'Unchanged (same value) or created.',
		);
	}

	/* ------------------------------------------------ PLUGINS */

	protected static function tool_list_plugins() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$out = array();
		foreach ( get_plugins() as $file => $data ) {
			$out[] = array(
				'plugin'  => $file,
				'name'    => $data['Name'],
				'version' => $data['Version'],
				'active'  => is_plugin_active( $file ),
			);
		}
		return array( 'count' => count( $out ), 'plugins' => $out );
	}

	protected static function tool_activate_plugin( $a ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$plugin = $a['plugin'];
		if ( is_plugin_active( $plugin ) ) {
			return array( 'plugin' => $plugin, 'active' => true, 'note' => 'Already active.' );
		}
		$result = activate_plugin( $plugin, '', false, true );
		if ( is_wp_error( $result ) ) {
			throw new AgentBridge_Tool_Error( $result->get_error_message() );
		}
		return array( 'plugin' => $plugin, 'active' => true );
	}

	protected static function tool_deactivate_plugin( $a ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$plugin = $a['plugin'];
		if ( false !== strpos( $plugin, 'agentbridge' ) ) {
			throw new AgentBridge_Tool_Error( 'Refusing to deactivate AgentBridge through AgentBridge.' );
		}
		if ( ! is_plugin_active( $plugin ) ) {
			return array( 'plugin' => $plugin, 'active' => false, 'note' => 'Already inactive.' );
		}
		deactivate_plugins( $plugin, false, false );
		return array( 'plugin' => $plugin, 'active' => false );
	}

	/* ------------------------------------------------ THEMES */

	protected static function tool_list_themes() {
		$out = array();
		foreach ( wp_get_themes() as $stylesheet => $theme ) {
			$out[] = array(
				'stylesheet' => $stylesheet,
				'name'       => $theme->get( 'Name' ),
				'version'    => $theme->get( 'Version' ),
				'active'     => ( get_stylesheet() === $stylesheet ),
			);
		}
		return array( 'count' => count( $out ), 'themes' => $out );
	}

	protected static function tool_switch_theme( $a ) {
		$stylesheet = $a['stylesheet'];
		$theme      = wp_get_theme( $stylesheet );
		if ( ! $theme->exists() ) {
			throw new AgentBridge_Tool_Error( 'Theme not installed: ' . $stylesheet );
		}
		switch_theme( $stylesheet );
		return array( 'active_theme' => get_stylesheet() );
	}

	/* ------------------------------------------------ FILES */

	protected static function tool_read_file( $a ) {
		$path = self::safe_path( $a['path'] );
		if ( ! is_file( $path ) ) {
			throw new AgentBridge_Tool_Error( 'Not a file: ' . $path );
		}
		if ( ! is_readable( $path ) ) {
			throw new AgentBridge_Tool_Error( 'Not readable: ' . $path );
		}
		$offset = max( 0, (int) ( $a['offset'] ?? 0 ) );
		$length = ( isset( $a['length'] ) ) ? max( 1, (int) $a['length'] ) : null;
		$data   = file_get_contents( $path, false, null, $offset, $length ?? PHP_INT_MAX );
		if ( false === $data ) {
			// PHP < 8 conflicts with null length; fall back.
			$data = file_get_contents( $path );
			if ( false === $data ) {
				throw new AgentBridge_Tool_Error( 'Read failed: ' . $path );
			}
			$data = substr( $data, $offset, $length ?? strlen( $data ) );
		}
		return array(
			'path' => $path,
			'size' => filesize( $path ),
			'content' => $data,
		);
	}

	protected static function tool_write_file( $a ) {
		$path = self::safe_path( $a['path'] );
		if ( is_dir( $path ) ) {
			throw new AgentBridge_Tool_Error( 'Path is a directory: ' . $path );
		}
		$dir = dirname( $path );
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			throw new AgentBridge_Tool_Error( 'Could not create directory: ' . $dir );
		}
		$mode = ( $a['mode'] ?? 'rewrite' ) === 'append' ? FILE_APPEND : 0;
		$ok   = file_put_contents( $path, $a['content'], $mode );
		if ( false === $ok ) {
			throw new AgentBridge_Tool_Error( 'Write failed (permissions?): ' . $path );
		}
		return array( 'path' => $path, 'bytes' => $ok, 'mode' => $a['mode'] ?? 'rewrite' );
	}

	protected static function tool_delete_file( $a ) {
		$path = self::safe_path( $a['path'] );
		if ( is_dir( $path ) ) {
			if ( count( (array) glob( rtrim( $path, '/' ) . '/*' ) ) > 0 || count( (array) glob( rtrim( $path, '/' ) . '/.*' ) ) > 2 ) {
				throw new AgentBridge_Tool_Error( 'Directory is not empty: ' . $path );
			}
			if ( ! rmdir( $path ) ) {
				throw new AgentBridge_Tool_Error( 'rmdir failed: ' . $path );
			}
			return array( 'path' => $path, 'deleted' => true, 'type' => 'directory' );
		}
		if ( ! is_file( $path ) ) {
			throw new AgentBridge_Tool_Error( 'Not found: ' . $path );
		}
		if ( ! unlink( $path ) ) {
			throw new AgentBridge_Tool_Error( 'Delete failed: ' . $path );
		}
		return array( 'path' => $path, 'deleted' => true, 'type' => 'file' );
	}

	/* ------------------------------------------------ CODE */

	protected static function tool_eval_php( $a ) {
		$code = (string) $a['code'];
		// strip an opening tag if the agent included one
		$code = preg_replace( '/^\s*<\?(php|=)?/i', '', $code );
		ob_start();
		$return = null;
		try {
			$return = eval( $code );
		} catch ( Throwable $e ) {
			$out = ob_get_clean();
			throw new AgentBridge_Tool_Error( get_class( $e ) . ': ' . $e->getMessage() . ( $out ? "\nPartial output:\n" . $out : '' ) );
		}
		$out = ob_get_clean();
		return array(
			'output' => $out,
			'return' => var_export( $return, true ),
		);
	}

	protected static function tool_wp_cli( $a ) {
		$disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
		if ( in_array( 'shell_exec', $disabled, true ) || ! function_exists( 'shell_exec' ) ) {
			throw new AgentBridge_Tool_Error( 'shell_exec is disabled in php.ini — wp_cli unavailable on this host.' );
		}
		$cmd = preg_replace( '/^wp\s+/', '', trim( (string) $a['command'] ) );
		if ( $cmd === '' ) {
			throw new AgentBridge_Tool_Error( 'Empty command.' );
		}
		$full = 'cd ' . escapeshellarg( ABSPATH ) . ' && wp ' . $cmd . ' --allow-root 2>&1';
		$out  = shell_exec( $full );
		if ( null === $out ) {
			throw new AgentBridge_Tool_Error( 'No output. Is the wp binary installed and on PATH?' );
		}
		return array( 'command' => 'wp ' . $cmd, 'output' => $out );
	}

	/* ------------------------------------------------ DATABASE */

	protected static function tool_db_query( $a ) {
		global $wpdb;
		$query = trim( (string) $a['query'] );
		if ( ! preg_match( '/^\s*(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN)\b/i', $query ) ) {
			throw new AgentBridge_Tool_Error( 'db_query is read-only (SELECT/SHOW/DESCRIBE/EXPLAIN). Use db_execute for writes (Unsafe mode).' );
		}
		if ( ! preg_match( '/\bLIMIT\b/i', $query ) && preg_match( '/^\s*SELECT\b/i', $query ) ) {
			$query .= ' LIMIT 500';
		}
		$rows = $wpdb->get_results( $query, ARRAY_A );
		if ( $wpdb->last_error ) {
			throw new AgentBridge_Tool_Error( 'SQL error: ' . $wpdb->last_error );
		}
		return array(
			'rows'  => $rows,
			'count' => is_array( $rows ) ? count( $rows ) : 0,
		);
	}

	protected static function tool_db_execute( $a ) {
		global $wpdb;
		$query = trim( (string) $a['query'] );
		if ( $query === '' ) {
			throw new AgentBridge_Tool_Error( 'Empty query.' );
		}
		$result = $wpdb->query( $query );
		if ( false === $result ) {
			throw new AgentBridge_Tool_Error( 'SQL error: ' . $wpdb->last_error );
		}
		return array(
			'affected' => (int) $result,
			'insert_id'=> (int) $wpdb->insert_id,
		);
	}
}
