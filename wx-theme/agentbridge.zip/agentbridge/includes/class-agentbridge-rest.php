<?php
/**
 * AgentBridge — MCP endpoint + JSON-RPC 2.0 router.
 *
 * POST /wp-json/agentbridge/v1/mcp
 * GET  /wp-json/agentbridge/v1/mcp  → JSON info card (no auth, no data leak)
 *
 * Auth: WordPress Application Passwords (HTTP Basic) + administrator role.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AgentBridge_REST {

	const ROUTE = '/agentbridge/v1/mcp';

	/** MCP protocol revision this build speaks. */
	const PROTOCOL_VERSION = '2024-11-05';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			'agentbridge/v1',
			'/mcp',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'info_card' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'handle' ),
					'permission_callback' => array( __CLASS__, 'authorize' ),
				),
			)
		);
	}

	/**
	 * Public info card — proves the server is live without exposing anything.
	 */
	public static function info_card() {
		$tools = AgentBridge_Tools::all();
		return rest_ensure_response(
			array(
				'server'           => 'AgentBridge',
				'version'          => AGENTBRIDGE_VERSION,
				'protocol'         => 'MCP (JSON-RPC 2.0 over HTTP)',
				'protocolVersion'  => self::PROTOCOL_VERSION,
				'endpoint'         => self::endpoint_url(),
				'enabled'          => get_option( 'agentbridge_enabled', '1' ) === '1',
				'tools'            => count( $tools ),
				'auth'             => 'WordPress Application Password (HTTP Basic) — administrator role required',
				'wordpress'        => get_bloginfo( 'version' ),
			)
		);
	}

	public static function endpoint_url() {
		return rest_url( trim( self::ROUTE, '/' ) );
	}

	/**
	 * Admin-only gate. Application Passwords land the request on a real user;
	 * we additionally require manage_options.
	 */
	public static function authorize( WP_REST_Request $request ) {
		if ( get_option( 'agentbridge_enabled', '1' ) !== '1' ) {
			return new WP_Error(
				'agentbridge_disabled',
				'AgentBridge is disabled in Settings → AgentBridge.',
				array( 'status' => 403 )
			);
		}
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'agentbridge_auth',
				'Authentication required. Send an Application Password via HTTP Basic auth.',
				array( 'status' => 401 )
			);
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'agentbridge_forbidden',
				'Administrator role required.',
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * JSON-RPC 2.0 entry point. Accepts single objects and batches.
	 */
	public static function handle( WP_REST_Request $request ) {
		$body = $request->get_json_params();

		if ( null === $body ) {
			$raw = $request->get_body();
			$body = json_decode( $raw, true );
		}

		if ( null === $body ) {
			return self::rpc_error( null, -32700, 'Parse error: body is not valid JSON.' );
		}

		// Batch?
		if ( array_keys( $body ) === range( 0, count( $body ) - 1 ) && count( $body ) > 0 && is_array( $body[0] ?? null ) ) {
			$out = array();
			foreach ( $body as $msg ) {
				$r = self::dispatch( $msg );
				if ( null !== $r ) {
					$out[] = $r;
				}
			}
			return rest_ensure_response( $out );
		}

		if ( ! is_array( $body ) ) {
			return self::rpc_error( null, -32600, 'Invalid Request: expected a JSON-RPC object.' );
		}

		$result = self::dispatch( $body );

		// Notifications get no JSON body — answer 202 with nothing.
		if ( null === $result ) {
			$resp = new WP_REST_Response( null, 202 );
			return $resp;
		}

		return rest_ensure_response( $result );
	}

	/**
	 * Route one JSON-RPC message. Returns response array, or null for notifications.
	 */
	private static function dispatch( $msg ) {
		$id     = $msg['id'] ?? null;
		$method = $msg['method'] ?? '';

		if ( ( $msg['jsonrpc'] ?? '' ) !== '2.0' ) {
			return self::rpc_error( $id, -32600, 'Invalid Request: "jsonrpc" must be "2.0".' );
		}

		// Notifications (no id) — accept silently.
		$is_notification = ! array_key_exists( 'id', $msg );

		switch ( $method ) {
			case 'initialize':
				return self::rpc_result(
					$id,
					array(
						'protocolVersion' => self::PROTOCOL_VERSION,
						'capabilities'    => array(
							'tools' => array( 'listChanged' => false ),
						),
						'serverInfo'      => array(
							'name'    => 'AgentBridge',
							'version' => AGENTBRIDGE_VERSION,
						),
					)
				);

			case 'ping':
				return self::rpc_result( $id, new stdClass() );

			case 'notifications/initialized':
			case 'notifications/cancelled':
				return null;

			case 'tools/list':
				$defs = array();
				foreach ( AgentBridge_Tools::all() as $name => $tool ) {
					$defs[] = array(
						'name'        => $name,
						'description' => $tool['description'],
						'inputSchema' => $tool['schema'],
					);
				}
				return self::rpc_result( $id, array( 'tools' => $defs ) );

			case 'tools/call':
				if ( $is_notification ) {
					return null;
				}
				$params = $msg['params'] ?? array();
				$name   = $params['name'] ?? '';
				$args   = $params['arguments'] ?? array();
				if ( ! is_array( $args ) ) {
					$args = array();
				}
				return self::rpc_result( $id, AgentBridge_Tools::call( $name, $args ) );

			default:
				if ( $is_notification ) {
					return null;
				}
				return self::rpc_error( $id, -32601, 'Method not found: ' . $method );
		}
	}

	private static function rpc_result( $id, $result ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'result'  => $result,
		);
	}

	private static function rpc_error( $id, $code, $message ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'error'   => array(
				'code'    => $code,
				'message' => $message,
			),
		);
	}
}
