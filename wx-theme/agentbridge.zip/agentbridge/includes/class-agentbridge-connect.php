<?php
/**
 * AgentBridge Connect — one-click token engine.
 *
 * Generate mints a real WordPress Application Password for the current
 * administrator, computes the Basic token server-side, and parks the
 * whole bundle in a 10-minute transient so the admin page can render
 * every client snippet with REAL credentials (no placeholders, no base64 math).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AgentBridge_Connect {

	const BUNDLE_TTL  = 600; // 10 minutes
	const NAME_PREFIX = 'agentbridge-';

	public static function init() {
		add_action( 'admin_post_agentbridge_generate', array( __CLASS__, 'handle_generate' ) );
		add_action( 'admin_post_agentbridge_revoke', array( __CLASS__, 'handle_revoke' ) );
		add_action( 'admin_post_agentbridge_test', array( __CLASS__, 'handle_test' ) );
		add_action( 'admin_post_agentbridge_download', array( __CLASS__, 'handle_download' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_allow_app_passwords' ) );
	}

	/** Optional escape hatch for local/non-SSL sites: honor the stored toggle. */
	public static function maybe_allow_app_passwords() {
		if ( get_option( 'agentbridge_allow_http_passwords', '0' ) === '1' ) {
			add_filter( 'wp_is_application_passwords_available', '__return_true', 999 );
		}
	}

	/* -------------------------------------------------- helpers */

	private static function admin_url( $args = array() ) {
		return add_query_arg(
			array_merge( array( 'page' => 'agentbridge' ), $args ),
			admin_url( 'options-general.php' )
		);
	}

	private static function guard( $nonce_action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}
		check_admin_referer( $nonce_action );
	}

	/** Fetch + delete the one-time bundle created by handle_generate(). */
	public static function pop_bundle( $key ) {
		$key    = sanitize_key( $key );
		$bundle = get_transient( 'ab_bundle_' . $key );
		if ( is_array( $bundle ) && ! empty( $bundle['basic'] ) ) {
			delete_transient( 'ab_bundle_' . $key );
			return $bundle;
		}
		return null;
	}

	/** All client snippets, fully pre-filled with real credentials. */
	public static function snippets( $endpoint, $basic ) {
		return array(
			'claude-code' => array(
				'label'   => 'Claude Code (CLI)',
				'snippet' => 'claude mcp add --transport http agentbridge ' . $endpoint
					. ' --header "Authorization: Basic ' . $basic . '"',
				'file'    => 'claude-code-command.sh',
			),
			'claude-desktop' => array(
				'label'   => 'Claude Desktop',
				'snippet' => wp_json_encode(
					array(
						'mcpServers' => array(
							'agentbridge' => array(
								'command' => 'npx',
								'args'    => array(
									'-y', 'mcp-remote', $endpoint,
									'--header', 'Authorization: Basic ' . $basic,
								),
							),
						),
					),
					JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
				),
				'file'    => 'claude_desktop_config.json',
			),
			'cursor' => array(
				'label'   => 'Cursor',
				'snippet' => wp_json_encode(
					array(
						'mcpServers' => array(
							'agentbridge' => array(
								'type'    => 'streamable-http',
								'url'     => $endpoint,
								'headers' => array( 'Authorization' => 'Basic ' . $basic ),
							),
						),
					),
					JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
				),
				'file'    => 'cursor-mcp.json',
			),
			'cline' => array(
				'label'   => 'Cline',
				'snippet' => wp_json_encode(
					array(
						'mcpServers' => array(
							'agentbridge' => array(
								'type'    => 'streamableHttp',
								'url'     => $endpoint,
								'headers' => array( 'Authorization' => 'Basic ' . $basic ),
							),
						),
					),
					JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
				),
				'file'    => 'cline_mcp_settings.json',
			),
			'gemini' => array(
				'label'   => 'Gemini CLI',
				'snippet' => wp_json_encode(
					array(
						'mcpServers' => array(
							'agentbridge' => array(
								'httpUrl' => $endpoint,
								'headers' => array( 'Authorization' => 'Basic ' . $basic ),
							),
						),
					),
					JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
				),
				'file'    => 'gemini-settings.json',
			),
			'hermes' => array(
				'label'   => 'Hermes / any MCP client',
				'snippet' => "url = " . $endpoint
					. "\nheader = Authorization: Basic " . $basic
					. "\ntransport = streamable-http (POST, JSON-RPC 2.0)",
				'file'    => 'hermes-mcp.txt',
			),
		);
	}

	/* -------------------------------------------------- generate */

	public static function handle_generate() {
		self::guard( 'agentbridge_generate' );

		$user = wp_get_current_user();
		require_once ABSPATH . 'wp-admin/includes/user.php';

		if ( ! wp_is_application_passwords_available_for_user( $user ) ) {
			wp_safe_redirect(
				self::admin_url( array( 'gen_error' => 'app_passwords_unavailable' ) )
			);
			exit;
		}

		$name  = self::NAME_PREFIX . gmdate( 'Ymd-His' );
		$found = WP_Application_Passwords::create_new_application_password(
			$user->ID,
			array( 'name' => $name )
		);

		if ( is_wp_error( $found ) ) {
			wp_safe_redirect(
				self::admin_url( array( 'gen_error' => rawurlencode( $found->get_error_message() ) ) )
			);
			exit;
		}

		list( $new_password ) = $found;

		$basic  = base64_encode( $user->user_login . ':' . $new_password );
		$bundle = array(
			'user'      => $user->user_login,
			'name'      => $name,
			'endpoint'  => AgentBridge_REST::endpoint_url(),
			'basic'     => $basic,
			'created'   => time(),
		);

		$key = wp_generate_password( 20, false, false );
		set_transient( 'ab_bundle_' . $key, $bundle, self::BUNDLE_TTL );

		wp_safe_redirect( self::admin_url( array( 'connect' => $key, 'generated' => '1' ) ) );
		exit;
	}

	/* -------------------------------------------------- revoke */

	public static function handle_revoke() {
		self::guard( 'agentbridge_revoke' );

		$uuid = isset( $_GET['uuid'] ) ? sanitize_text_field( wp_unslash( $_GET['uuid'] ) ) : '';
		if ( $uuid ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			WP_Application_Passwords::delete_application_password(
				get_current_user_id(),
				$uuid
			);
		}
		wp_safe_redirect( self::admin_url( array( 'revoked' => '1' ) ) );
		exit;
	}

	/** Tokens minted by AgentBridge for the current user (for the manager table). */
	public static function my_tokens() {
		require_once ABSPATH . 'wp-admin/includes/user.php';
		$all  = WP_Application_Passwords::get_user_application_passwords( get_current_user_id() );
		$mine = array();
		foreach ( (array) $all as $item ) {
			if ( strpos( $item['name'], self::NAME_PREFIX ) === 0 ) {
				$mine[] = $item;
			}
		}
		return $mine;
	}

	/* -------------------------------------------------- test */

	public static function handle_test() {
		self::guard( 'agentbridge_test' );

		$endpoint = AgentBridge_REST::endpoint_url();
		$basic    = isset( $_POST['basic'] ) ? sanitize_text_field( wp_unslash( $_POST['basic'] ) ) : '';

		if ( ! $basic ) {
			wp_safe_redirect( self::admin_url( array( 'test_error' => 'no_token' ) ) );
			exit;
		}

		$headers = array(
			'Authorization' => 'Basic ' . $basic,
			'Content-Type'  => 'application/json',
		);

		// 1 · handshake
		$init = wp_remote_post(
			$endpoint,
			array(
				'headers' => $headers,
				'body'    => '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}',
				'timeout' => 15,
			)
		);
		if ( is_wp_error( $init ) ) {
			wp_safe_redirect( self::admin_url( array( 'test_error' => rawurlencode( $init->get_error_message() ) ) ) );
			exit;
		}
		$code = wp_remote_retrieve_response_code( $init );
		if ( 200 !== $code ) {
			$body = wp_remote_retrieve_body( $init );
			$short = substr( trim( wp_strip_all_tags( $body ) ), 0, 180 );
			wp_safe_redirect(
				self::admin_url( array( 'test_error' => rawurlencode( 'HTTP ' . $code . ' — ' . $short ) ) )
			);
			exit;
		}

		// 2 · catalog
		$list = wp_remote_post(
			$endpoint,
			array(
				'headers' => $headers,
				'body'    => '{"jsonrpc":"2.0","id":2,"method":"tools/list"}',
				'timeout' => 15,
			)
		);
		$count = 0;
		if ( ! is_wp_error( $list ) ) {
			$data = json_decode( wp_remote_retrieve_body( $list ), true );
			if ( isset( $data['result']['tools'] ) && is_array( $data['result']['tools'] ) ) {
				$count = count( $data['result']['tools'] );
			}
		}

		wp_safe_redirect(
			self::admin_url( array( 'test_ok' => '1', 'tools' => (string) $count ) )
		);
		exit;
	}

	/* -------------------------------------------------- download */

	public static function handle_download() {
		self::guard( 'agentbridge_download' );

		// read-only: the panel must stay usable for other clients within the bundle TTL
		$key    = isset( $_GET['bundle'] ) ? sanitize_key( wp_unslash( $_GET['bundle'] ) ) : '';
		$bundle = $key ? get_transient( 'ab_bundle_' . $key ) : null;
		$bundle = is_array( $bundle ) ? $bundle : null;
		$which  = isset( $_GET['client'] ) ? sanitize_key( $_GET['client'] ) : '';

		if ( ! $bundle ) {
			wp_die( 'Token bundle expired — generate a new one.' );
		}
		$snips = self::snippets( $bundle['endpoint'], $bundle['basic'] );
		if ( ! isset( $snips[ $which ] ) ) {
			wp_die( 'Unknown client.' );
		}

		$file = $snips[ $which ]['file'];
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $file . '"' );
		echo $snips[ $which ]['snippet']; // phpcs:ignore
		exit;
	}
}
