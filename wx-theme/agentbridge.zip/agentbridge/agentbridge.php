<?php
/**
 * Plugin Name:       AgentBridge
 * Plugin URI:        https://woodex.pk/agentbridge
 * Description:       MCP server for WordPress — connect any AI agent (Claude Code, Hermes, Cursor, Cline, Gemini CLI) with full WordPress access.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Woodex
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       agentbridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // no direct access
}

define( 'AGENTBRIDGE_VERSION', '1.1.0' );
define( 'AGENTBRIDGE_FILE', __FILE__ );
define( 'AGENTBRIDGE_PATH', plugin_dir_path( __FILE__ ) );
define( 'AGENTBRIDGE_URL', plugin_dir_url( __FILE__ ) );

require_once AGENTBRIDGE_PATH . 'includes/class-agentbridge-tools.php';
require_once AGENTBRIDGE_PATH . 'includes/class-agentbridge-rest.php';
require_once AGENTBRIDGE_PATH . 'includes/class-agentbridge-connect.php';
require_once AGENTBRIDGE_PATH . 'includes/class-agentbridge-admin.php';

/**
 * Defaults on activation — safe out of the box:
 * endpoint ON, unsafe tools OFF, filesystem locked to the WP root.
 */
function agentbridge_activate() {
	add_option( 'agentbridge_enabled', '1' );
	add_option( 'agentbridge_unsafe', '0' );
	add_option( 'agentbridge_full_fs', '0' );
	add_option( 'agentbridge_allow_http_passwords', '0' );
}
register_activation_hook( __FILE__, 'agentbridge_activate' );

AgentBridge_REST::init();
AgentBridge_Connect::init();
AgentBridge_Admin::init();
