/* AgentBridge — copy-to-clipboard for snippets */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('.ab-copy');
  if (!btn) return;
  const el = document.getElementById(btn.dataset.target);
  if (!el) return;
  const text = el.textContent;
  const done = () => {
    btn.classList.add('copied');
    const old = btn.textContent;
    btn.textContent = 'Copied ✓';
    setTimeout(() => { btn.classList.remove('copied'); btn.textContent = old; }, 1600);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(done);
  } else {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (err) {}
    ta.remove();
    done();
  }
});
