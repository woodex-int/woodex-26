<?php
// AgentBridge — clean removal: delete our three options.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'agentbridge_enabled' );
delete_option( 'agentbridge_unsafe' );
delete_option( 'agentbridge_full_fs' );
