# Connect Claude to WordPress via AgentBridge
**One-time setup · works on localhost and live sites**

> Goal: after this, you type *"list my latest posts"* or *"activate the plugin"*
> in Claude and it does it on your WordPress site through AgentBridge's 24 MCP tools.

---

## ⚡ The 30-second way (v1.1)

1. WordPress admin → **Plugins → Add New → Upload Plugin** → `agentbridge.zip` → **Activate**.
2. **Settings → AgentBridge** → press **⚡ Generate Connect Token**.
   *(The plugin mints the Application Password itself — no Users→Profile trip, no base64.)*
3. On the **Claude Code** or **Claude Desktop** card → press **Copy**.
4. Press **✓ Test connection** → `✓ Connected` = token works.

> Local site without HTTPS and generation fails? Toggles → **Allow on non-HTTPS (local)** → Save → generate again.

### Claude Code — paste & go

The copied command already contains your real endpoint and token:

```bash
claude mcp add --transport http agentbridge \
  YOUR-ENDPOINT-ALREADY-FILLED \
  --header "Authorization: Basic TOKEN-ALREADY-FILLED"
```

Verify: `claude mcp list` → `agentbridge … ✓ connected`

### Claude Desktop

Use the **⬇ claude_desktop_config.json** download button on the Claude Desktop card —
the file is pre-filled. Merge it into:

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

Restart Claude Desktop → the 🔌 icon shows 24 tools.
(Desktop speaks stdio, so the config bridges through `mcp-remote` — included automatically.)

## Step 5 — Prove it works

Ask Claude:

- *"What WordPress version is my site running?"* → uses `site_info`
- *"Create a draft post called Test via AgentBridge"* → uses `create_post`
- *"Show the active plugins"* → uses `list_plugins`

Check wp-admin — the draft is really there.

---

## Something failed? Match the error

| You see | Meaning | Fix |
|---|---|---|
| Generate says “app passwords unavailable” | WP blocks app passwords on plain HTTP | Local site: Toggles → **Allow on non-HTTPS (local)** → retry. Live site: install SSL first. |
| `✗ failed to connect` | Wrong URL / server off | Open the URL in a browser — no JSON card = fix permalinks or re-enable in Settings → AgentBridge |
| `401` | Bad credentials | Re-do Step 3 — token must be `username:app_password` base64, exactly one `:` |
| `403 agentbridge_forbidden` | Not an admin | Use an Administrator account's app password |
| `403 agentbridge_disabled` | Master toggle off | Settings → AgentBridge → **Server enabled** ✓ |
| `tools/list` empty in Claude | Stale config | `claude mcp remove agentbridge` then re-add; restart Claude Desktop after config edits |
| `rest_no_route` 404 | Pretty permalinks off | Settings → Permalinks → pick anything but "Plain", or use `?rest_route=/agentbridge/v1/mcp` as the URL |
| `wp_cli` / `eval_php` tool errors | Unsafe mode off (by design) | Settings → AgentBridge → **Unsafe mode** ✓ — only when you need it |

---

## Daily safety rules

- **Unsafe mode OFF** when not actively needed — it alone unlocks code execution, SQL writes, file deletes.
- Password leaked? **Users → Profile → Application Passwords → Revoke** takes 10 seconds and kills access instantly.
- Remove the connection: `claude mcp remove agentbridge` (or delete the block in the Desktop config).

---
*Part of the AgentBridge plugin v1.0.0 — other clients (Cursor, Cline, Gemini CLI, Hermes): see `docs/CLIENTS.md`.*
