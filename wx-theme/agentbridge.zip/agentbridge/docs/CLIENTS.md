# AgentBridge — Connect Any AI Agent to WordPress
Works with **Claude Code, Claude Desktop, Hermes, Cursor, Cline, Gemini CLI**, or any MCP
client that speaks **streamable HTTP**. Same flow for **local** (XAMPP/LocalWP/Docker)
and **live** sites.

---

## ⚡ The 30-second way (v1.1 — do this)

1. **Plugins → Add New → Upload** `agentbridge.zip` → **Activate**.
2. **Settings → AgentBridge** → press **⚡ Generate Connect Token**.
   The plugin creates the Application Password for you and computes everything.
3. Pick your client card → **Copy** (or **⬇ Download** the config file).
   The snippet already contains your real token — nothing to fill in.
4. Press **✓ Test connection**. `✓ Connected — 24 tools` means done.
5. Paste the snippet into your client. Start asking.

> Local site on plain HTTP? If step 2 fails, turn on **Allow on non-HTTPS (local)**
> under Toggles, save, and generate again.

### What the client cards give you

| Client | You get | Paste into |
|---|---|---|
| Claude Code | ready `claude mcp add …` command | terminal |
| Claude Desktop | `claude_desktop_config.json` (mcp-remote bridge) | the app’s config file, then restart app |
| Cursor | `cursor-mcp.json` | `~/.cursor/mcp.json` |
| Cline | `cline_mcp_settings.json` | Cline → MCP settings |
| Gemini CLI | `gemini-settings.json` | `~/.gemini/settings.json` |
| Hermes / any | URL + header + transport line | the client’s MCP server config |

---

## 🔧 The manual way (fallback / reference)

Only needed if you skipped the generator.

1. **Users → Profile → Application Passwords** → name it → copy the password.
2. Build the header: `echo -n 'username:xxxx xxxx xxxx xxxx' | base64`
3. Endpoint: `https://YOUR-SITE/wp-json/agentbridge/v1/mcp`
4. Configure your client with URL + `Authorization: Basic <base64>`.

Claude Code:
```bash
claude mcp add --transport http agentbridge \
  https://YOUR-SITE/wp-json/agentbridge/v1/mcp \
  --header "Authorization: Basic YOUR_BASE64_TOKEN"
```

## Verify from a terminal (any OS)

```bash
curl -u "username:app_password" \
  -X POST https://YOUR-SITE/wp-json/agentbridge/v1/mcp \
  -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```
→ JSON list of 24 tools = healthy.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Generate button errors “app passwords unavailable” | Live site without HTTPS → add SSL. Local site → Toggles → **Allow on non-HTTPS (local)** → retry. |
| `401` | Token revoked/expired bundle — generate a fresh token; re-paste the new snippet. |
| `403 agentbridge_forbidden` | The account isn’t an Administrator. |
| `403 agentbridge_disabled` | Toggles → **Server enabled** ✓. |
| 404 / `rest_no_route` | Permalinks on “Plain” → Settings → Permalinks → choose “Post name” (or use `?rest_route=/agentbridge/v1/mcp`). Check security plugins blocking REST. |
| Client says connected but no tools | Re-run Settings → AgentBridge → **Test connection**; it reports the exact HTTP failure. |
| `wp_cli` tool errors | Host blocked `shell_exec` or no `wp` binary — skip that tool. |

## Security notes

- Admin-level tools by design — staging first, backups on.
- Revoke leaked tokens instantly from **Active tokens** (or Users → Profile → Revoke).
- Keep **Unsafe mode OFF** unless needed; it gates code execution, SQL writes, deletes.
