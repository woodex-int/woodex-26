=== AgentBridge ===
Contributors: woodex
Tags: mcp, ai, agent, claude, cursor, automation
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

MCP server for WordPress — connect any AI agent (Claude Code, Hermes, Cursor, Cline, Gemini CLI) with full WordPress access.

== Description ==

AgentBridge exposes a Model Context Protocol (MCP) endpoint on your WordPress
site so any MCP-compatible agent can operate it directly: execute PHP, run
WP-CLI, manage posts/pages, plugins, themes, options, menus, media, files and
the database.

= Features =

* Standard MCP (JSON-RPC 2.0) over HTTP — works with any MCP client.
* 24 tools covering content, code, files, plugins, themes, menus, media, SQL.
* ONE-CLICK connect: the plugin mints the Application Password for you and
  renders ready-to-paste snippets for every client — no manual base64.
* Built-in connection self-test and token revoke manager.
* Authenticated by WordPress Application Passwords; admin-only.
* Built-in "Unsafe mode" / "Full filesystem" toggles.
* Admin panel with per-client connection config snippets + downloads.

= Security =

This plugin grants administrator-level tools over HTTP. Use it on staging or
protected production sites, with backups. Rotate the Application Password if it
is ever exposed.

== Changelog ==

= 1.1.0 =
* One-click connect: generate token button, pre-filled snippets per client, config-file downloads, connection self-test, token revoke manager, non-HTTPS (local) allowance toggle.

= 1.0.0 =
* Initial release.
